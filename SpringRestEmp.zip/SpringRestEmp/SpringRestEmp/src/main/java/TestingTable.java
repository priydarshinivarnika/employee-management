import org.hibernate.Session;

import com.ust.model.EmployeeEntity;
import com.ust.model.SkillEntity;
import com.ust.services.EmployeeServices;
import com.ust.services.EmployeeServicesImpl;
import com.ust.utility.HibernateUtil;

public class TestingTable {
	public static void main(String[] args)

	{

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();

		// --------------------learning code---

		SkillEntity skill1 = new SkillEntity("Java");
		SkillEntity skill2 = new SkillEntity("SQL");

		session.persist(skill1);
		session.persist(skill2);

		EmployeeServices emp = new EmployeeServicesImpl();
		// Add few employee records in database
		Integer empID1 = emp.addEmployee("abc@mail.com", "Varnika", "Priydarshini", "Dev");
		Integer empID2 = emp.addEmployee("def@mail.com", "Varnika", "Priydarshini", "Dev");
		Integer empID3 = emp.addEmployee("ghi@mail.com", "Varnika", "Priydarshini", "Dev");

		// List down all the employees
		emp.listEmployees();

		// Update employee's records
		emp.updateEmployee(empID1, "Physics");

		// Delete an employee from the database
		// emp.deleteEmployee(empID2);

		// List down new list of the employees
		// emp.listEmployees();

		// Fetch the employee by its id
		// emp.fetchEmployeeById(2);

		// Fetch the employee by its department
		// emp.fetchEmployeeByDepartment("Physics");

		/* Method to print total number of records */
		emp.countEmployee();

		session.getTransaction().commit();
		

	}

}