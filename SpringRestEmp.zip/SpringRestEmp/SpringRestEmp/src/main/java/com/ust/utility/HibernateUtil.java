package com.ust.utility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.ust.model.*;

public class HibernateUtil {

	private SessionFactory sessionFactory;
	
	private void initSession() {
		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();

		} catch (Throwable ex) {
			System.err.println("Session Factory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	
	}
	public SessionFactory getSessionFactory() {
		if(sessionFactory != null) {
		return sessionFactory;
	}
		else {
			initSession();
		return getSessionFactory();
		}
	}
	public void shutdown() {

		getSessionFactory().close();
	}
}
