package com.ust.services;

public interface EmployeeServices {

	/* Method to CREATE an employee in the database */
	Integer addEmployee(String email, String firstName, String lastName, String department);

	/* Method to READ all the employees */
	void listEmployees();

	// Method to READ the employee by id
	void fetchEmployeeById(Integer employeeID);

	// Method to READ the employee by department
	void fetchEmployeeByDepartment(String department);

	/* Method to UPDATE department for an employee */
	void updateEmployee(Integer employeeID, String department);

	/* Method to DELETE an employee from the records */
	void deleteEmployee(Integer employeeID);
	
	/* Method to print total number of records */
	void countEmployee();

}