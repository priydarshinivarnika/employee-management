package com.ust.model;

public interface SkillService {

}
