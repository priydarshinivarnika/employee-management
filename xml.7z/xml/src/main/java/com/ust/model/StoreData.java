package com.ust.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreData {

	public static void main(String[] args) {

		System.out.println("Hibernate Many to Many (XML mapping)");
		Session session = HibernateUtil.getSessionFactory().openSession();

		session.beginTransaction();

		for (int i = 1; i <= 10; i++) {
			EmployeeData emp1 = new EmployeeData();
			emp1.setFirstName("First" + i);
			emp1.setLastName("Name");
			emp1.setDepartment("Development");
			emp1.getSkillDatas().add(new SkillData("Java"));
			emp1.getSkillDatas().add(new SkillData("Sql"));
			session.persist(emp1);

		}

		EmployeeData emp2 = new EmployeeData();
		emp2.setFirstName("Second");
		emp2.setLastName("Name");
		emp2.setDepartment("Support");
		emp2.getSkillDatas().add(new SkillData("Excel"));
		session.persist(emp2);

		EmployeeData emp3 = new EmployeeData();
		emp3.setFirstName("Third");
		emp3.setLastName("Name");
		emp3.setDepartment("Management");
		emp3.getSkillDatas().add(new SkillData("Excel"));

		session.persist(emp3);// persisting the object

		session.getTransaction().commit();
		System.out.println("successfully saved all the table");

		session.close();
		HibernateUtil.getSessionFactory().close();
	}

}
