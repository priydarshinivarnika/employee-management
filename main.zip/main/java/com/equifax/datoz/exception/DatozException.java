package com.equifax.datoz.exception;

public class DatozException extends RuntimeException{

  /**
   * 
   */
  public DatozException() {
    super();
  }


  /**
   * @param arg0
   */
  public DatozException(String arg0) {
    super(arg0);
  }

  /**
   * @param arg0
   */
  public DatozException(Throwable arg0) {
    super(arg0);
  }

}
