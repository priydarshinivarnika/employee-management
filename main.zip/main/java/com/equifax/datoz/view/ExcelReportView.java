package com.equifax.datoz.view;

import java.util.*;
import javax.servlet.http.*;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.domain.RequestData;
import com.equifax.datoz.handler.Model;

public class ExcelReportView extends AbstractExcelView {

  /**
   * Method to create excel
   */
  @Override
  protected void buildExcelDocument(Map<String, Object> modelMap, HSSFWorkbook workbook, HttpServletRequest request,
    HttpServletResponse response) throws Exception {
    response.setHeader("Content-Disposition", "attachment;filename=\"TestData.xls\"");
    HSSFSheet sheet = workbook.createSheet("Test Data");
    createHeaderRow(sheet);
    int rowCount = 1;
    Model model = null;

    Set<RequestData> requestDataSet = (Set<RequestData>) modelMap.get("requestDataList");
    for (RequestData requestData : requestDataSet) {
      int i = 0;
      Row row = sheet.createRow(++rowCount);
      if (null != requestData.getModelObject()) {

        model = requestData.getModelObject();
        Cell cell = row.createCell(i);
        cell.setCellValue(model.getFirstName());

        cell = row.createCell(i++);
        cell.setCellValue(model.getLastName());

        cell = row.createCell(i++);
        cell.setCellValue(model.getMiddleName());

        cell = row.createCell(i++);
        cell.setCellValue(model.getSocialSecurityNumber());

        cell = row.createCell(i++);
        cell.setCellValue(model.getHouseNumber());

        cell = row.createCell(i++);
        cell.setCellValue(model.getStreetName());

        cell = row.createCell(i++);
        cell.setCellValue(model.getStreetType());

        cell = row.createCell(i++);
        cell.setCellValue(model.getCity());

        cell = row.createCell(i++);
        cell.setCellValue(model.getState());

        cell = row.createCell(i++);
        cell.setCellValue(model.getZip());
      }
    }
  }

  /**
   * Method to create excel column header
   * @param sheet
   */
  private void createHeaderRow(Sheet sheet) {
    int i = 0;
    CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
    Font font = sheet.getWorkbook().createFont();

    font.setFontHeightInPoints(Constants.SIXTEEN);
    cellStyle.setFont(font);

    Row row = sheet.createRow(i);
    Cell cell = row.createCell(i);

    cell.setCellStyle(cellStyle);
    cell.setCellValue("First Name");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("Last Name");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("Middle Name");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("SSN");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("House Number");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("Street Name");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("Street Type");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("City");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("State");

    cell = row.createCell(i++);
    cell.setCellStyle(cellStyle);
    cell.setCellValue("Zip");
  }

}
