package com.equifax.datoz.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Class to initialize DatozProperties
 *
 */
@Component
public class DatozProperties {

    @Value("${JFIRSTNAME}")
    private String jfirstName;

    @Value("${JLASTNAME}")
    private String jlastName;

    @Value("${JMIDDLENAME}")
    private String jmiddleName;

    @Value("${JSSN}")
    private String jssn;

    @Value("${JHOUSENUM}")
    private String jhouseNum;

    @Value("${JSTREETNAME}")
    private String jstreetName;

    @Value("${JSTREETTYPE}")
    private String jstreetType;

    @Value("${JCITY}")
    private String jcity;

    @Value("${JSTATE}")
    private String jstate;

    @Value("${JZIP}")
    private String jzip;

    @Value("${XUSERID}")
    private String userId;

    @Value("${XPASSWORD}")
    private String password;

    @Value("${XFIRSTNAME}")
    private String xfirstName;

    @Value("${XLASTNAME}")
    private String xlastName;

    @Value("${XSSN}")
    private String xssn;

    @Value("${XADDRESSLINE}")
    private String addressLine;

    @Value("${XCITY}")
    private String xcity;

    @Value("${XSTATE}")
    private String xstate;

    @Value("${XPOSTALCODE}")
    private String xpostalCode;

    @Value("${XSTREETNUMBER}")
    private String xstreetNumber;

    @Value("${XSTREETNAME}")
    private String xstreetName;

    @Value("${XSTREETTYPE}")
    private String xstreetType;

    @Value("${STREETNUMBERVALUE}")
    private String streetNumValue;

    @Value("${HOUSENUMVALUE}")
    private String houseNumValue;

    @Value("${STREETNAMEVALUE}")
    private String streetNameValue;

    @Value("${STREETTYPEVALUE}")
    private String streetTypeValue;

    @Value("${ZIPVALUE}")
    private String zipValue;

    @Value("${USERIDVALUE}")
    private String userIdValue;

    @Value("${PASSWORDVALUE}")
    private String passwordValue;

    @Value("${ADDRESSLINEVALUE}")
    private String addressLineValue;

    @Value("${POSTALCODEVALUE}")
    private String postalCodeValue;

    @Value("${FIRSTNAMEVALUE}")
    private String firstNameValue;

    @Value("${LASTNAMEVALUE}")
    private String lastNameValue;

    @Value("${MIDDLENAMEVALUE}")
    private String middleNameValue;

    @Value("${SSNVALUE}")
    private String ssnValue;

    @Value("${CITYVALUE}")
    private String cityValue;

    @Value("${STATEVALUE}")
    private String stateValue;

    @Value("${XCSTATEPROVINCE}")
    private String stateProvince;

    @Value("${STATEPROVINCEVALUE}")
    private String stateProvinceValue;

    @Value("${XCBUSINESSNAME}")
    private String businessName;

    @Value("${BUSINESSNAMEVALUE}")
    private String businessNameValue;

    @Value("${XCFEDERALTAXID}")
    private String federalTaxId;

    @Value("${FEDERALTAXIDVALUE}")
    private String federalTaxIdValue;

    @Value("${XCPRIMARYADDRESS}")
    private String primaryAddress;

    @Value("${PRIMARYADDRESSVALUE}")
    private String primaryAddressValue;

    @Value("${COMUSERID}")
    private String comUserId;

    @Value("${COMUSERIDALUE}")
    private String comUserIdValue;

    public String getJfirstName() {
        return jfirstName;
    }

    public String getJlastName() {
        return jlastName;
    }

    public String getJmiddleName() {
        return jmiddleName;
    }

    public String getJssn() {
        return jssn;
    }

    public String getJhouseNum() {
        return jhouseNum;
    }

    public String getJstreetName() {
        return jstreetName;
    }

    public String getJstreetType() {
        return jstreetType;
    }

    public String getJcity() {
        return jcity;
    }

    public String getJstate() {
        return jstate;
    }

    public String getJzip() {
        return jzip;
    }

    public String getUserId() {
        return userId;
    }

    public String getPassword() {
        return password;
    }

    public String getXfirstName() {
        return xfirstName;
    }

    public String getXlastName() {
        return xlastName;
    }

    public String getXssn() {
        return xssn;
    }

    public String getAddressLine() {
        return addressLine;
    }

    public String getXcity() {
        return xcity;
    }

    public String getXstate() {
        return xstate;
    }

    public String getXpostalCode() {
        return xpostalCode;
    }

    public String getHouseNumValue() {
        return houseNumValue;
    }

    public String getStreetNameValue() {
        return streetNameValue;
    }

    public String getStreetTypeValue() {
        return streetTypeValue;
    }

    public String getZipValue() {
        return zipValue;
    }

    public String getUserIdValue() {
        return userIdValue;
    }

    public String getPasswordValue() {
        return passwordValue;
    }

    public String getAddressLineValue() {
        return addressLineValue;
    }

    public String getPostalCodeValue() {
        return postalCodeValue;
    }

    public String getFirstNameValue() {
        return firstNameValue;
    }

    public String getLastNameValue() {
        return lastNameValue;
    }

    public String getMiddleNameValue() {
        return middleNameValue;
    }

    public String getSsnValue() {
        return ssnValue;
    }

    public String getCityValue() {
        return cityValue;
    }

    public String getStateValue() {
        return stateValue;
    }

    public String getXstreetNumber() {
        return xstreetNumber;
    }

    public String getXstreetName() {
        return xstreetName;
    }

    public String getXstreetType() {
        return xstreetType;
    }

    public String getStreetNumValue() {
        return streetNumValue;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public String getStateProvinceValue() {
        return stateProvinceValue;
    }

    public String getBusinessName() {
        return businessName;
    }

    public String getBusinessNameValue() {
        return businessNameValue;
    }

    public String getFederalTaxId() {
        return federalTaxId;
    }

    public String getFederalTaxIdValue() {
        return federalTaxIdValue;
    }

    public String getPrimaryAddress() {
        return primaryAddress;
    }

    public String getPrimaryAddressValue() {
        return primaryAddressValue;
    }

    public String getComUserId() {
        return comUserId;
    }

    public String getComUserIdValue() {
        return comUserIdValue;
    }

}
