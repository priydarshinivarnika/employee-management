package com.equifax.datoz.util;

import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.equifax.datoz.constants.Constants;

/**
 * Class to parse FFF response data and match with scenario
 * @author UST Global
 *
 */
public class FFFParserUtil {
  private static final Logger LOGGER = Logger.getLogger(FFFParserUtil.class);

  /**
   * Default constructor
   */
  private FFFParserUtil() {
  }

  /**
   * Method to match scenario and response data
   * @param scenario
   * @param responseFFF
   * @param responseSchema
   * @return
   */
  public static boolean isScenarioMappingWithResponse(String scenario, String responseFFF, String responseSchema) {
    boolean status = Boolean.FALSE;

    JSONObject scenarioJson = getJsonObject(scenario);
    Set<String> keys = scenarioJson.keySet();
    for (String keystring : keys) {
      if (null != scenarioJson.get(keystring)) {
        status = isResponseMatchingToScenario(keystring, responseSchema, responseFFF, scenarioJson.get(keystring).toString());
        if (status == Boolean.FALSE) {
          break;
        }
      }
    }
    return status;
  }

  /**
   * Method to split the scenario and compare with response data field
   * @param fieldName
   * @param responseSchema
   * @param responseFFF
   * @param fieldValue
   * @return
   */
  private static boolean isResponseMatchingToScenario(String fieldName, String responseSchema, String responseFFF, String fieldValue) {
   
    boolean responseStatus=Boolean.FALSE;
    String responseValue=null;
    if (null != responseSchema && !responseSchema.isEmpty()) {
      JSONObject schemaFields = getJsonObject(responseSchema);
      Set<String> keys = schemaFields.keySet();
      for (String key : keys) {
        if (fieldName.equals(key)) {
          String field = ((String) schemaFields.get(key)).replaceAll("\\(", "").replaceAll("\\)", "");
          int startIndex = Integer.parseInt(field.split(",")[0]);
          int length = Integer.parseInt(field.split(",")[1].trim());
          int endIndex = startIndex + length;
           responseValue = responseFFF.substring(startIndex, endIndex);
           responseStatus=getResponse(fieldValue, responseValue);
        }
      }
    }
    return responseStatus;
  }
        
  /**
   * Method to get Response
   * @param fieldValue
   * @param responseValue
   * @return
   */
 
 private static boolean getResponse(String fieldValue, String responseValue){     
     boolean status = Boolean.FALSE;
          if (fieldValue.trim().equals(responseValue.trim())) {
            status = Boolean.TRUE;
          } else if ( fieldValue.startsWith(">")) {
            Long ruleValue = Long.valueOf(fieldValue.replaceFirst(">", "").trim());
            if (Long.valueOf(responseValue).compareTo(Long.valueOf(ruleValue)) > 0) {
              status = Boolean.TRUE;
            }
          } else if (null != responseValue && fieldValue.startsWith("<")) {
            Long ruleValue = Long.valueOf(fieldValue.replaceFirst("<", "").trim());
            if (Long.valueOf(responseValue).compareTo(Long.valueOf(ruleValue)) < 0) {
              status = Boolean.TRUE;
            }
          } else if (null != responseValue && fieldValue.equalsIgnoreCase(Constants.EXISTS)) {
            status = Boolean.TRUE;
          }
        
      

    return status;
  }

  /**
   * Method to convert response string to JSON object
   * @param jsonString
   * @return
   */
  private static JSONObject getJsonObject(String jsonString) {
    JSONParser parser = new JSONParser();
    Object obj = null;
    try {
      obj = parser.parse(jsonString);
    } catch (ParseException parseException) {
      LOGGER.error(parseException);
    }
    return (JSONObject) obj;
  }

 
}
