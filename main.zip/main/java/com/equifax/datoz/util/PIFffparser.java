package com.equifax.datoz.util;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
/**
 * Class to parse FFF PI
 *
 */
public class PIFffparser {
    private static final Logger LOGGER = Logger.getLogger(PIFffparser.class);
    
    /**
     * Method to get FFF PI
     * @param personalinfoschema
     * @param requestfff
     * @return
     */
    public String getFffPI(String personalinfoschema, String requestfff){

        String piSchema = null;
        JSONObject schema = getJsonObject(personalinfoschema);
        Map responseObject = new HashMap();
        Set<String> keys = schema.keySet();
        for (String key : keys) {
            String value = (String) schema.get(key);
            value = value.replaceAll("\\)", "").replaceAll("\\(", "");
            int startIndex = Integer.parseInt(value.split(",")[0]);
            int length = Integer.parseInt(value.split(",")[1].trim());
            int endIndex = startIndex + length;
            String fieldValue = requestfff.substring(startIndex, endIndex);
            responseObject.put(key, fieldValue);
        }
        piSchema = new Gson().toJson(responseObject);
        return piSchema;

    }
    /**
     * Method to get JSON object
     * @param personalinfoschema
     * @return
     */
    public JSONObject getJsonObject(String personalinfoschema) {
        JSONParser parser = new JSONParser();
        Object obj = null;
        try {
            obj = parser.parse(personalinfoschema);
        } catch (ParseException e) {
            LOGGER.info(e);
        }
        return (JSONObject) obj;
    }
       
    /**
     * Method to get FFF additional details
     * @param addFieldPath
     * @param requestfff
     * @return
     */
    public String getFffadditional(String addFieldPath, String requestfff){

        JSONObject schema = getJsonObject(addFieldPath);
        JSONObject responseObject = new JSONObject();
        Set<String> keys = schema.keySet();
        for (String key : keys) {
            String value = (String) schema.get(key);
            value = value.replaceAll("\\)", "").replaceAll("\\(", "");
            int startIndex = Integer.parseInt(value.split(",")[0]);
            int length = Integer.parseInt(value.split(",")[1].trim());
            int endIndex = startIndex + length;
            String fieldValue = requestfff.substring(startIndex, endIndex);
            responseObject.put(key, fieldValue);
        }

        return responseObject.toJSONString();

    }
    /**
     * Method to get FFF additional details map
     * @param additionalDetail
     * @param responseString
     * @return
     */
    public Map<String, String> getAdditionalDetailsMapForFff(String additionalDetail, String responseString) {

        Map<String, String> addDetailMap = null;
        if (additionalDetail != null && !additionalDetail.isEmpty()) {

            addDetailMap = new Gson().fromJson(additionalDetail, new TypeToken<Map<String, String>>() {
            }.getType());

        }
        Map<String, String> additionalDetailsMap = new HashMap<String, String>();
        if (addDetailMap != null) {
            Iterator addIterator = addDetailMap.entrySet().iterator();
            while (addIterator.hasNext()) {
                Map.Entry pair = (Map.Entry) addIterator.next();
                String addFieldKey = (String) pair.getKey();
                String addFieldPath = (String) pair.getValue();
                addFieldPath = addFieldPath.replaceAll("\\)", "").replaceAll("\\(", "");
                int startIndex = Integer.parseInt(addFieldPath.split(",")[0]);
                int length = Integer.parseInt(addFieldPath.split(",")[1].trim());
                int endIndex = startIndex + length;
                String fieldValue = responseString.substring(startIndex, endIndex);

                if (fieldValue != null) {
                    additionalDetailsMap.put(addFieldKey, fieldValue);
                } else {
                    additionalDetailsMap.put(addFieldKey, "");
                }

            }
        }
        return additionalDetailsMap;

    }
}
