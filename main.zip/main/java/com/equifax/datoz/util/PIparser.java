package com.equifax.datoz.util;

import java.util.*;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.equifax.datoz.constants.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 *Class to parse JSON PI
 */
public class PIparser {
    private static final Logger LOGGER = Logger.getLogger(PIparser.class);

    /**Method to get JSON PI
    * @param fieldname
    * @param json
    * @return
    */
    public String getJsonPI(String fieldname, String json) {
        JSONObject responseJson = getJsonObject(json);
        String jsonValue = "";

        JSONObject jsonObject1 = getJsonObjectByField(fieldname, responseJson);
        if (null == jsonObject1) {
            return jsonValue;
        }
        if (null != fieldname.substring(fieldname.lastIndexOf(".") + 1) && null != jsonObject1.get(fieldname.substring(fieldname.lastIndexOf(".") + 1))) {
            jsonValue = jsonObject1.get(fieldname.substring(fieldname.lastIndexOf(".") + 1)).toString();
        }
        return jsonValue;

    }

    /**Method to get JSON Object
    * @param jsonString
    * @return
    */
    public static JSONObject getJsonObject(String jsonString) {
        JSONParser parser = new JSONParser();
        Object obj = null;
        try {
            obj = parser.parse(getJsonResponse(jsonString));
        } catch (ParseException e) {
            LOGGER.error(e);
        }
        return (JSONObject) obj;
    }

    /**Method to get JSON Response
    * @param jsonString
    * @return
    */
    private static String getJsonResponse(String jsonString) {
        return jsonString;
    }

    /**Method to get JSON Object by field
    * @param fieldName
    * @param jsonObject
    * @return
    */
    private static JSONObject getJsonObjectByField(String fieldName, JSONObject jsonObject) {

        JSONObject jsonObject1 = null;
        JSONArray jsonArray;
        if (null == jsonObject) {
            return null;
        }
        if (!fieldName.contains(".")) {
            return jsonObject;
        } else {
            if (jsonObject.get(fieldName.substring(0, fieldName.indexOf("."))) instanceof JSONObject) {
                jsonObject1 = (JSONObject) jsonObject.get(fieldName.substring(0, fieldName.indexOf(".")));
            } else if (jsonObject.get(fieldName.substring(0, fieldName.indexOf("."))) instanceof JSONArray) {
                jsonArray = (JSONArray) jsonObject.get(fieldName.substring(0, fieldName.indexOf(".")));
                if (!jsonArray.isEmpty()) {
                    jsonObject1 = (JSONObject) jsonArray.get(0);
                }
            }
            return getJsonObjectByField(fieldName.substring(fieldName.indexOf(".") + 1), jsonObject1);
        }
    }
    /**Method to get JSON Personal Information
     * @param personalinfoschema
     * @param responseString
     * @return
     */
    public String getPersonalInfoJson(String personalinfoschema, String responseString) {
        Map<String, String> piMap = new Gson().fromJson(personalinfoschema, new TypeToken<Map<String, String>>() {
        }.getType());
        Map<String, String> responsePersonalInfoMap = new HashMap<String, String>();
        String resValue = null;
        String personalInfo = null;
        Iterator iterator = piMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry) iterator.next();

            String key = (String) pair.getKey();
            String fieldName = (String) pair.getValue();
            resValue = getJsonPI(fieldName, responseString);
            if (resValue != null) {
                responsePersonalInfoMap.put(key, resValue);
            } else {
                responsePersonalInfoMap.put(key, Constants.EMPTY);
            }
        }
        JSONObject responsePI = new JSONObject(responsePersonalInfoMap);
        personalInfo = responsePI.toString();
        return personalInfo;
    }
    /**Method to get Additional Details Map
     * @param additionalDetail
     * @param responseString
     * @return
     */
    public Map<String, String> getAdditionalDetailsMapForJson(String additionalDetail, String responseString) {
        Map<String, String> addDetailMap = null;
        if (additionalDetail != null && !additionalDetail.isEmpty()) {
            addDetailMap = new Gson().fromJson(additionalDetail, new TypeToken<Map<String, String>>() {
            }.getType());
        }
        String reqValue = null;
        Map<String, String> additionalDetailsMap = new HashMap<String, String>();
        if (addDetailMap != null) {
            Iterator addIterator = addDetailMap.entrySet().iterator();
            while (addIterator.hasNext()) {
                Map.Entry pair = (Map.Entry) addIterator.next();
                String addFieldKey = (String) pair.getKey();
                String addFieldPath = (String) pair.getValue();
                reqValue = getJsonPI(addFieldPath, responseString);
                if (reqValue != null) {
                    additionalDetailsMap.put(addFieldKey, reqValue);
                } else {
                    additionalDetailsMap.put(addFieldKey, "");
                }
            }
        }
        return additionalDetailsMap;
    }
}
