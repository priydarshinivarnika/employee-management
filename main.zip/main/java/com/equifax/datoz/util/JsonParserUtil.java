package com.equifax.datoz.util;


import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.equifax.datoz.constants.Constants;
/**
 * Class to parse JSON response data and match with scenario
 * 
 */

public class JsonParserUtil {
  private static final Logger LOGGER = Logger.getLogger(JsonParserUtil.class);
  
  /**
   * Default constructor
   */
  private JsonParserUtil() {

  }

  /**
   * Method to match scenario and response data
   * @param scenario
   * @param response
   * @return
   */
  public static boolean isScenarioMappingWithResponse(String scenario, String response) {
    boolean status = Boolean.FALSE;
    JSONObject scenarioJson = getJsonObject(scenario);
    JSONObject responseJson = getJsonObject(response);
    Set<String> keys = scenarioJson.keySet();
    for (String keystring : keys) {
      if (null != scenarioJson.get(keystring)) {
        status =  isResponseMatchingToScenario(keystring, responseJson,  scenarioJson.get(keystring).toString());
        if (status == Boolean.FALSE) {
          break;
        }
      }
    }

    return status;

  }

  /** Method to get Json Object
   * @param jsonString
   * @return
   */
  public static JSONObject getJsonObject(String jsonString) {
    JSONParser parser = new JSONParser();
    Object obj = null;
    try {
      obj = parser.parse(getJsonResponse(jsonString));
    } catch (ParseException e) {
      LOGGER.info(e);
    }
    return (JSONObject) obj;
  }

  /** Method to get Json Response
   * @param jsonString
   * @return
   */
  private static String getJsonResponse(String jsonString) {

    return jsonString;
  }

  /** Method to check whether field value is same to json value
   * @param fieldName
   * @param fieldValue
   * @param status
   * @param jsonObject1
   * @return
   */
  private static boolean checkFieldvalueSame(String fieldName, String fieldValue,JSONObject jsonObject1) {
    boolean status = Boolean.FALSE;
    String jsonValue = null;
    if( fieldName.contains(Constants.DOT)  && jsonObject1.containsKey(fieldName.substring(fieldName.lastIndexOf(".") + 1))) {
      jsonValue=jsonObject1.get(fieldName.substring(fieldName.lastIndexOf(".") + 1)).toString();
    }else  if( !fieldName.contains(Constants.DOT)  && jsonObject1.containsKey(fieldName)) {
      jsonValue =jsonObject1.get(fieldName).toString();
    }   
    if (isValueNotEmpty(jsonValue) && isValueNotEmpty(fieldValue)) {
      status = compareValues(fieldValue, jsonValue);
    }
    return status;
  }

  /** Method to check whether json value is empty
   * @param jsonValue
   * @return
   */
  private static boolean isValueNotEmpty(String jsonValue) {
    return null != jsonValue && !jsonValue.trim().isEmpty();
  }

  /** comparing field value to json value
   * @param fieldValue
   * @param status
   * @param jsonValue
   * @return
   */
  private static boolean compareValues(String fieldValue,  String jsonValue) {
    boolean status= Boolean.FALSE;
    if ( isStringEqual(fieldValue, jsonValue)) {
      status = Boolean.TRUE;
    } else if ( fieldValue.startsWith(">")) {
      Long ruleValue = Long.valueOf(fieldValue.replaceFirst(">", "").trim());
      if (Long.valueOf(jsonValue).compareTo(Long.valueOf(ruleValue)) > 0) {
        status = Boolean.TRUE;
      }
    } else if (null != jsonValue && fieldValue.startsWith("<")) {
      Long ruleValue = Long.valueOf(fieldValue.replaceFirst("<", "").trim());
      if (Long.valueOf(jsonValue).compareTo(Long.valueOf(ruleValue)) < 0) {
        status = Boolean.TRUE;
      }
    } else if (null != jsonValue && fieldValue.equalsIgnoreCase(Constants.EXISTS)) {
      status = Boolean.TRUE;
    }
    return status;
  }

  /** Checking whether strings are equal
   * @param fieldValue
   * @param jsonValue
   * @return
   */
  private static boolean isStringEqual(String fieldValue, String jsonValue) {
    return !fieldValue.startsWith(">") && !fieldValue.startsWith("<")
      && jsonValue.trim().equalsIgnoreCase(fieldValue);
  }


  
  /** Method to match response to scenario
   * @param fieldName
   * @param jsonObject
   * @param fieldValue
   * @return
   */
  private static boolean isResponseMatchingToScenario(String fieldName, 
    JSONObject jsonObject,String fieldValue) {
    JSONObject jsonObjectnew = jsonObject;
    JSONArray jsonArray;
    String fieldNameString =null;
    String[] fieldArray =null;
   
    String remainingFields = fieldName;
    boolean status= Boolean.FALSE;
    if (null == jsonObject) {
      status=Boolean.FALSE;
    }
    if (!fieldName.contains(Constants.DOT)) {
      status = checkFieldvalueSame(fieldNameString, fieldValue, jsonObject);
    } else {
      fieldNameString = fieldName.replace(Constants.DOT, Constants.COMMA);
       fieldArray =fieldNameString.split( Constants.COMMA);
       
       for(String key: fieldArray) {
         remainingFields =remainingFields.substring(remainingFields.indexOf(Constants.DOT)+ 1);
         if (jsonObjectnew.get(key) instanceof JSONObject) {
           jsonObjectnew = (JSONObject) jsonObjectnew.get(key);
           if(!remainingFields.contains(Constants.DOT)) {
             status = checkFieldvalueSame(remainingFields, fieldValue, jsonObjectnew);
            if(status) {
              break;
            }
           }
         } else if (jsonObjectnew.get(key) instanceof JSONArray) {
           jsonArray = (JSONArray) jsonObjectnew.get(key);
           if(!remainingFields.contains(Constants.DOT)) {
             for(int i =0;i<jsonArray.size();i++) {
               status = checkFieldvalueSame(remainingFields, fieldValue,  (JSONObject)jsonArray.get(i));
               if(status) {
                 break;
               }
             }
             }else {
               status= processJsonArray(remainingFields,jsonArray,fieldValue);
               if(status) {
                 break;
               }
             }
           
         }
       }
      
    }

    return status;
  }

  /** Method to process Json Array
   * @param fieldName
   * @param jsonArray
   * @param fieldValue
   * @return
   */
  private static boolean processJsonArray(String fieldName, JSONArray jsonArray, String fieldValue) {  
    boolean status= Boolean.FALSE;
    for(int i =0;i<jsonArray.size();i++) {
      status=isResponseMatchingToScenario(fieldName, (JSONObject)jsonArray.get(i),fieldValue);
      if(status) {
        break;
      }
    }
    return status;
  }
  /** Method to replace the value with code
   * @param obj
   * @param keyMain
   * @param newValue
   * @return
   */
  public static JSONObject replaceValueWithCode(JSONObject obj, String keyMain, String newValue) {
    
      Iterator iterator = obj.keySet().iterator();
      String key = null;
      while (iterator.hasNext()) {
        key = (String) iterator.next();

        if (key.equals(keyMain)) {
          obj.put(key, newValue);
          return obj;
        }
        if(!("driversLicense".equalsIgnoreCase(key))){
          if (obj.get(key) instanceof JSONObject) {
            replaceValueWithCode((JSONObject) obj.get(key), keyMain, newValue);
          }

          if (obj.get(key) instanceof JSONArray) {
            JSONArray jArray = (JSONArray) obj.get(key);
            for (int i = 0; i < jArray.size(); i++) {
              replaceValueWithCode((JSONObject) jArray.get(i), keyMain, newValue);
            }
          }
        }

      }
      return obj;
  }

}
