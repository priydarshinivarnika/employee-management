package com.equifax.datoz.util;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

@Component
public class ReplaceRequestSchema {
    private static final Logger LOGGER = Logger.getLogger(ReplaceRequestSchema.class);

    @Autowired
    private DatozProperties datozProperties;

    /**Method to replace request schema for json
    * @param requestSchema
    * @return
    */
    public String replaceRequestSchemaForJson(String requestSchema) {

        String replacedSchema = null;
        JSONObject replacedJsonObject = null;

        JSONObject jsonObjectnew = JsonParserUtil.getJsonObject(requestSchema);
        try {
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJfirstName(), datozProperties.getFirstNameValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJlastName(), datozProperties.getLastNameValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJmiddleName(), datozProperties.getMiddleNameValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJssn(), datozProperties.getSsnValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJhouseNum(), datozProperties.getHouseNumValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJstreetName(), datozProperties.getStreetNameValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJstreetType(), datozProperties.getStreetTypeValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJcity(), datozProperties.getCityValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJstate(), datozProperties.getStateValue());
            replacedJsonObject = JsonParserUtil.replaceValueWithCode(jsonObjectnew, datozProperties.getJzip(), datozProperties.getZipValue());

        } catch (Exception e) {

            LOGGER.error(e);
        }
        if (null != replacedJsonObject && !replacedJsonObject.isEmpty()) {
            replacedSchema = replacedJsonObject.toString();
        }
        return replacedSchema;

    }

    /**Method to replace request schema for xml
     * @param requestSchema
     * @param headerMap
     * @return
     */
    public String replaceRequestSchemaForXml(String requestSchema, Map<String, String> headerMap) {

        String replacedString = null;
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e2) {
            LOGGER.error(e2);
        }
        Document doc = null;
        try {
            doc = XmlParserUtil.generateXmLFromString(dBuilder, requestSchema);
        } catch (Exception e) {
            LOGGER.error(e);
        }

        if (doc.hasChildNodes()) {

            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getUserId(), datozProperties.getUserIdValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getPassword(), datozProperties.getPasswordValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXfirstName(), datozProperties.getFirstNameValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXlastName(), datozProperties.getLastNameValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXssn(), datozProperties.getSsnValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getAddressLine(), datozProperties.getAddressLineValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXcity(), datozProperties.getCityValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXstate(), datozProperties.getStateValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXpostalCode(), datozProperties.getPostalCodeValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXstreetName(), datozProperties.getStreetNameValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXstreetNumber(), datozProperties.getStreetNumValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getXstreetType(), datozProperties.getStreetTypeValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getBusinessName(), datozProperties.getBusinessNameValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getFederalTaxId(), datozProperties.getFederalTaxIdValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getPrimaryAddress(), datozProperties.getPrimaryAddressValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getStateProvince(), datozProperties.getStateProvinceValue());
            XmlParserUtil.traverseNode(doc.getChildNodes(), datozProperties.getComUserId(), datozProperties.getComUserIdValue());

            if (headerMap != null) {
                Iterator headIterator = headerMap.entrySet().iterator();
                while (headIterator.hasNext()) {
                    Map.Entry pair = (Map.Entry) headIterator.next();
                    String headFieldKey = (String) pair.getKey();
                    String headFieldValue = "$$" + headFieldKey + "$$";
                    XmlParserUtil.traverseHeaders(doc.getChildNodes(), headFieldKey, headFieldValue);
                }

            }

            try {

                replacedString = XmlParserUtil.toXmlString(doc);

            } catch (TransformerException e) {

                LOGGER.error(e);
            }

        }

        return replacedString;

    }

}
