package com.equifax.datoz.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.equifax.datoz.constants.Constants;

import org.w3c.dom.Node;
/**
 * Class to parse XML response data and match with scenario
 *
 */
public class XmlParserUtil {
  private static final Logger LOGGER = Logger.getLogger(XmlParserUtil.class);

/**
 * Default constructor
 */
  private XmlParserUtil() {
  }

/**
 * Method to match scenario and response data
 * @param scenarioJson
 * @param responseXml
 * @return
 */
  public static boolean isScenarioMappingWithResponse(String scenarioJson, String responseXml) {
    boolean status = Boolean.FALSE;
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    try {
      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
      Document doc = generateXmLFromString(dBuilder, responseXml);
      JSONObject scenario = JsonParserUtil.getJsonObject(scenarioJson);
      Set<String> keys = scenario.keySet();
      for (String keystring : keys) {
        if (doc.hasChildNodes()) {
          status = isFieldValueSame(keystring, scenario.get(keystring).toString(), doc);
          if (status == Boolean.FALSE) {
            break;
          }
        }

      }

    } catch (ParserConfigurationException e) {
      LOGGER.error(e);
    }
    return status;

  }

/**
 * Method to check whether field value and xml values are same
 * @param fieldName
 * @param fieldValue
 * @param doc
 * @return
 */
  private static boolean isFieldValueSame(String fieldName, String fieldValue, Document doc) {
    String nodeValue = null;
    boolean status = Boolean.FALSE;
    if (doc.hasChildNodes()) {
      nodeValue = traverseNode(doc, fieldName);
    }
    if (null != nodeValue && null != fieldValue) {
      if (isStringEqual(fieldValue, nodeValue)) {
        status = Boolean.TRUE;
      } else if (fieldValue.startsWith(">")) {
        Long ruleValue = Long.valueOf(fieldValue.replaceFirst(">", ""));
        if (Long.valueOf(nodeValue).compareTo(Long.valueOf(ruleValue)) > 0) {
          status = Boolean.TRUE;
        }
      } else if (fieldValue.startsWith("<")) {
        Long ruleValue = Long.valueOf(fieldValue.replaceFirst("<", ""));
        if (Long.valueOf(nodeValue).compareTo(Long.valueOf(ruleValue)) < 0) {
          status = Boolean.TRUE;
        }
      } else if (fieldValue.equalsIgnoreCase(Constants.EXISTS)) {
        status = Boolean.TRUE;
      }
    }
    return status;
  }

 /**Method to get field value
* @param fieldValue
* @param nodeValue
* @return
*/
  private static boolean isStringEqual(String fieldValue, String nodeValue) {
    return !fieldValue.startsWith(">") && !fieldValue.startsWith("<")
      && nodeValue.trim().equalsIgnoreCase(fieldValue);
  }
/**Method to traverse Node
* @param doc
* @param fieldName
* @return
*/
  private static String traverseNode(Document doc, String fieldName) {
    String fieldValue = null;
    String fieldNameString = "/" + fieldName.replace(".", "/");
    Node node;
    XPath xPath = XPathFactory.newInstance().newXPath();
    try {
      node = (Node) xPath.evaluate(fieldNameString, doc, XPathConstants.NODE);

      if (null != node) {
        fieldValue = node.getTextContent();
      }
    } catch (XPathExpressionException e) {
      LOGGER.error(e);
    }

    return fieldValue;
  }

  /**
  * Method kept for future use 
  * @param dBuilder
  * @param responseFile
  * @return
  * @throws SAXException
  * @throws IOException
  */
  /**private static Document generateXmLFromFile(DocumentBuilder dBuilder, String responseFile) throws SAXException, IOException {
   File fXmlFile = new File(responseFile);
   return dBuilder.parse(fXmlFile);
  }*/

  /** Method to generate XML from String
  * @param dBuilder
  * @param responseXml
  * @return
  */
  public static Document generateXmLFromString(final DocumentBuilder dBuilder, final String responseXml) {
    InputSource is = new InputSource();
    is.setCharacterStream(new StringReader(responseXml));
    try {
      return dBuilder.parse(is);
    } catch (Exception e) {

      LOGGER.error(e);

      return null;
    }
  }
/**Method to traverse Node
* @param nodeList
* @param fieldName
* @param value
* @return
*/
  public static String traverseNode(NodeList nodeList,
    String fieldName, String value) {
    String fieldValue = null;

    for (int count = 0; count < nodeList.getLength(); count++) {
      Node tempNode = nodeList.item(count);

      if (tempNode.getNodeType() == Node.ELEMENT_NODE) {
        if (fieldName.contains(tempNode.getNodeName())) {
          String field = fieldName.substring(fieldName.indexOf(".") + 1);
          if (field.equalsIgnoreCase(tempNode.getNodeName())) {
            field = null;
            if (isNodeHavingChild(tempNode)) {
              for (int childNode = 0; childNode < tempNode.getChildNodes().getLength(); childNode++) {
                Node internelNodes = tempNode.getChildNodes().item(childNode);
                if (internelNodes.getNodeType() == Node.ELEMENT_NODE) {
                  internelNodes.setTextContent(value);
                }

              }

            } else {
              tempNode.setTextContent(value);
            }

            fieldValue = tempNode.getTextContent();
            break;
          }

        }
        if (isTraverseRequired(fieldName, tempNode)) {
          traverseNode(tempNode.getChildNodes(), fieldName, value);
        }
      }

    }

    return fieldValue;
  }
/**Method to traverse Headers
* @param nodeList
* @param fieldName
* @param value
* @return
*/
  public static String traverseHeaders(NodeList nodeList, String fieldName, String value) {
    String fieldValue = null;
    for (int count = 0; count < nodeList.getLength(); count++) {
      Node tempNode = nodeList.item(count);

      if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

        if (isFieldNameMatchAndHavingChildNodes(fieldName, tempNode)) {

          String field = tempNode.getNodeName();
          if (field.equalsIgnoreCase(tempNode.getNodeName())) {
            field = null;
            if (isNodeHavingChild(tempNode)) {
              for (int childNode = 0; childNode < tempNode.getChildNodes().getLength(); childNode++) {
                Node internelNodes = tempNode.getChildNodes().item(childNode);
                if (internelNodes.getNodeType() == Node.ELEMENT_NODE) {
                  internelNodes.setTextContent(value);
                  return value;
                }
              }
            } else {
              tempNode.setTextContent(value);
            }
            fieldValue = tempNode.getTextContent();
            break;
          }
        }
        if (isTraverseRequired(fieldName, tempNode)) {
          traverseHeaders(tempNode.getChildNodes(), fieldName, value);
        }
      }
    }
    return fieldValue;
  }

  /**
   * Method to check the field name match and having child nodes
   * @param fieldName
   * @param tempNode
   * @return
   */
  private static boolean isFieldNameMatchAndHavingChildNodes(String fieldName, Node tempNode) {
    return fieldName.toLowerCase().contains(tempNode.getNodeName().toLowerCase()) && tempNode.getChildNodes().getLength() > 1;
  }

  /**
   * method to check whether need to traverse to child node to get the value 
   * @param fieldName
   * @param tempNode
   * @return
   */
  private static boolean isTraverseRequired(String fieldName, Node tempNode) {
    return !fieldName.isEmpty() && tempNode.hasChildNodes();
  }

  /**
   * method to check the node having child nodes
   * @param tempNode
   * @return
   */
  private static boolean isNodeHavingChild(Node tempNode) {
    return tempNode.hasChildNodes() && tempNode.getChildNodes().getLength() > 1;
  }
/**Method to convert to XML string
* @param document
* @return
*/
  public static String toXmlString(Document document) throws TransformerException {
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    DOMSource source = new DOMSource(document);
    StringWriter strWriter = new StringWriter();
    StreamResult result = new StreamResult(strWriter);

    transformer.transform(source, result);

    return strWriter.getBuffer().toString();

  }

}
