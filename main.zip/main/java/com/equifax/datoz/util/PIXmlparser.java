package com.equifax.datoz.util;


import java.io.*;
import java.util.*;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.equifax.datoz.constants.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
/**
 * Class to parse XML PI
 *
 */
public class PIXmlparser {
  private static final Logger LOGGER = Logger.getLogger(PIXmlparser.class);
  
  /**
   * Method to get XML PI
   * @param field
   * @param xml
   * @return
   */

  public String getXmlPI(String field, String xml) {

    String nodeText = null;
    Node node;
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    try {
      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
      Document doc;

      doc = dBuilder.parse(new InputSource(new StringReader(xml)));
      XPath xPath = XPathFactory.newInstance().newXPath();
      node = (Node) xPath.evaluate(field, doc, XPathConstants.NODE);
      if (node != null) {
        nodeText = node.getTextContent();
      }

    } catch (SAXException | IOException | XPathExpressionException | ParserConfigurationException e) {

      LOGGER.error(e);

    }

    return nodeText;

  }
  /**
   * Method to get XML Personal Information
   * @param personalinfoschema
   * @param responseString
   * @return
   */

  public String getPersonalInfoXml(String personalinfoschema ,String responseString){
      Map<String, String> piMap =null;
      String personalInfo  = null;
      if(personalinfoschema !=null && !personalinfoschema.isEmpty()){
         piMap   = new Gson().fromJson(personalinfoschema, new TypeToken<Map<String, String>>() {
      }.getType());
      Map<String, String> responsePersonalInfoMap = new HashMap<String, String>();
      String resValue = null;
      
      Iterator iterator = piMap.entrySet().iterator();
      while (iterator.hasNext()) {
          Map.Entry pair = (Map.Entry) iterator.next();

          String key = (String) pair.getKey();
          String fieldName = (String) pair.getValue();
          resValue =getXmlPI(fieldName, responseString);
          if (resValue != null) {
              responsePersonalInfoMap.put(key, resValue);
          } else {
              responsePersonalInfoMap.put(key, Constants.EMPTY);
          }
      }
      
      
      JSONObject responsePI = new JSONObject(responsePersonalInfoMap);
      
      personalInfo  =responsePI.toString();  
      
      
  }
      return personalInfo;
  }
  
  /**
   * Method to get XML Additional Details
   * @param additionalDetail
   * @param responseString
   * @return
   */

  public Map<String, String> getAdditionalDetailsMapForXml(String additionalDetail, String responseString) {

      Map<String, String> addDetailMap = null;
      if (additionalDetail != null && !additionalDetail.isEmpty()) {

          addDetailMap = new Gson().fromJson(additionalDetail, new TypeToken<Map<String, String>>() {
          }.getType());

      }

      String reqValue = null;
      Map<String, String> additionalDetailsMap = new HashMap<String, String>();


      if (addDetailMap != null) {
          Iterator addIterator = addDetailMap.entrySet().iterator();
          while (addIterator.hasNext()) {
              Map.Entry pair = (Map.Entry) addIterator.next();
              String addFieldKey = (String) pair.getKey();
              String addFieldPath = (String) pair.getValue();
              reqValue = getXmlPI(addFieldPath, responseString);

              if (reqValue != null) {
                  additionalDetailsMap.put(addFieldKey, reqValue);
              } else {
                  additionalDetailsMap.put(addFieldKey, "");
              }

          }
      }
      return additionalDetailsMap;

  }
  /**
   * Method to replace XML angular brackets
   * @param xmlString
   * @return
   */
  public String replaceXml(String xmlString){
      String xmlValue;
      xmlValue = xmlString.replaceAll("<", "&lt;");
      xmlValue = xmlString.replaceAll(">", "&gt;");
      xmlValue = xmlString.replaceAll("\"", "&quot;");
      
      return xmlValue;
  }

}
