package com.equifax.datoz.converter;

import org.modelmapper.ModelMapper;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.domain.*;
import com.equifax.datoz.entity.*;

public class EntityToDomainConverter {

  private static ModelMapper modelMapper = new ModelMapper();
  

  /**
   * Default constructor
   */
  private EntityToDomainConverter() {
    super();
  }
  

  /**
   * Method to convert DataSourceRequestDataVO to RequestData
   * @param dsRequestData
   * @return
   */
  public static RequestData convertDSRequestData(DataSourceRequestDataVO dsRequestData) {
    return modelMapper.map(dsRequestData, RequestData.class);
  }

  /**
   * Method to convert CustomerRequestDataVO to RequestData
   * @param custRequestData
   * @return
   */
  public static RequestData convertCustRequestData(CustomerRequestDataVO custRequestData) {
    return modelMapper.map(custRequestData, RequestData.class);
  }

  /**
   * Method to convert DataSourceScenarioVO to Scenario
   * @param dsScenarioVO
   * @return
   */
  public static Scenario convertDSScenario(DataSourceScenarioVO dsScenarioVO) {
    Scenario scenario = new Scenario();
    scenario.setScenarioId(dsScenarioVO.getScenarioId());
    scenario.setScenarioName(dsScenarioVO.getScenarioName());
    scenario.setScenarioData(dsScenarioVO.getScenarioData());
    scenario.setDescription(dsScenarioVO.getDescription());
    if (null !=scenario && null != dsScenarioVO.getDataSourceVO()) {
      scenario.setSourceId(dsScenarioVO.getDataSourceVO().getSourceId());
      scenario.setDataSourceName(dsScenarioVO.getDataSourceVO().getName());
      scenario.setInfoSchema(dsScenarioVO.getDataSourceVO().getPersonalInfoSchema());
      scenario.setFormat(dsScenarioVO.getDataSourceVO().getFormat());
      scenario.setResponseSchema(dsScenarioVO.getDataSourceVO().getResponseSchema());
    }
    scenario.setSourceType(Constants.DATASOURCE_TYPE);
    return scenario;

  }

  /**
   * Method to convert CustomerScenarioVO to Scenario
   * @param custScenario
   * @return
   */
  public static Scenario convertCustScenario(CustomerScenarioVO custScenario) {
    Scenario scenario = new Scenario();
    scenario.setScenarioId(custScenario.getScenarioId());
    scenario.setScenarioName(custScenario.getScenarioName());
    scenario.setScenarioData(custScenario.getScenarioData());
    scenario.setDescription(custScenario.getDescription());
    scenario.setSourceType(Constants.CUSTOMER_TYPE);
    if (null != custScenario.getCustomersVO() && null != scenario) {
      scenario.setSourceId(custScenario.getCustomersVO().getCustomerid());
      scenario.setCustomerName(custScenario.getCustomersVO().getName());
      scenario.setInfoSchema(custScenario.getCustomersVO().getPersonalInfoSchema());
      scenario.setResponseSchema(custScenario.getCustomersVO().getResponseSchema());
      scenario.setFormat(custScenario.getCustomersVO().getFormat());
      if (null != custScenario.getCustomersVO().getDataSourceVO()) {
        scenario.setDataSourceName(custScenario.getCustomersVO().getDataSourceVO().getName());
      }
    }
    return scenario;
  }
  
  /**
   * Method to convert CustomersVO to Customers
   * @param customersVO
   * @return
   */
  public static Customers convertCustomer(CustomersVO customersVO) {
    Customers customers = modelMapper.map(customersVO, Customers.class);
    if (null != customersVO.getDataSourceVO()) {
      if (null == customers.getRequestSchema()) {
        customers.setRequestSchema(customersVO.getDataSourceVO().getRequestSchema());
      }
      if (null == customers.getResponseSchema()) {
        customers.setResponseSchema(customersVO.getDataSourceVO().getRequestSchema());
      }
      if (null == customers.getPersonalInfoSchema()) {
        customers.setPersonalInfoSchema(customersVO.getDataSourceVO().getPersonalInfoSchema());
      }
      if (null == customers.getFormat()) {
        customers.setFormat(customersVO.getDataSourceVO().getFormat());
      }
    }
   return customers;
  }
}
