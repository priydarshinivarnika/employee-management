package com.equifax.datoz.converter;

import java.util.HashSet;
import java.util.Set;

import org.modelmapper.ModelMapper;

import com.equifax.datoz.domain.*;
import com.equifax.datoz.entity.*;

public class DomainToEntityConverter {
  
  private static ModelMapper modelMapper = new ModelMapper();
  

  /**
   * Default constructor
   */
  private DomainToEntityConverter() {
    super();
  }

  /**
   * Method to convert RequestData to DataSourceRequestDataVO
   * @param requestData
   * @return
   */
  public static DataSourceRequestDataVO convertToDsRequestData(RequestData requestData) {
    return modelMapper.map(requestData, DataSourceRequestDataVO.class);
  }
  
  /**
   * Method to convert RequestData to CustomerRequestDataVO
   * @param requestData
   * @return
   */
  public static CustomerRequestDataVO convertToCustRequestData(RequestData requestData) {
    return modelMapper.map(requestData, CustomerRequestDataVO.class);
  }
  
  /**
   * Method to convert Scenario to DataSourceScenarioVO
   * @param scenario
   * @return
   */
  public static DataSourceScenarioVO convertToDsScenario(Scenario scenario) {
    DataSourceScenarioVO dsScenarioVO = modelMapper.map(scenario, DataSourceScenarioVO.class);
    if (null != dsScenarioVO && null != scenario.getSourceId()) {
      DataSourceVO dataSourceVO = new DataSourceVO();
      dataSourceVO.setSourceId(scenario.getSourceId());
      dsScenarioVO.setDataSourceVO(dataSourceVO);
    }
    if (null != scenario.getRequestDataSet()) {
      Set<DataSourceRequestDataVO> dsRequestDatas = new HashSet<DataSourceRequestDataVO>();
      for (RequestData requestData : scenario.getRequestDataSet()) {
        dsRequestDatas.add(convertToDsRequestData(requestData));
        
      }
      dsScenarioVO.setDsRequestDataSet(dsRequestDatas);
    }
    return dsScenarioVO;
  }
  
  /**
   * Method to convert Scenario to CustomerScenarioVO
   * @param scenario
   * @return
   */
  public static CustomerScenarioVO convertToCustScenario(Scenario scenario) {
    CustomerScenarioVO customerScenarioVO = modelMapper.map(scenario, CustomerScenarioVO.class);
    if (null != customerScenarioVO && null != scenario.getSourceId()) {
      CustomersVO customersVO = new CustomersVO();
      customersVO.setCustomerid(scenario.getSourceId());
      customerScenarioVO.setCustomersVO(customersVO);
    }
    if (null != scenario.getRequestDataSet()) {
      Set<CustomerRequestDataVO> requestDatas = new HashSet<CustomerRequestDataVO>();
      for (RequestData requestData : scenario.getRequestDataSet()) {
        requestDatas.add(convertToCustRequestData(requestData));
        
      }
      customerScenarioVO.setCustRequestDataSet(requestDatas);
    }
    return customerScenarioVO;
  }
  
  /**
   * Method to convert Customers to CustomersVO
   * @param customer
   * @return
   */
  public static CustomersVO convertToCustomer(Customers customer) {
    CustomersVO  customersVO = modelMapper.map(customer, CustomersVO.class);
    if (null != customer.getSourceId()) {
      DataSourceVO dataSourceVO = new DataSourceVO();
      dataSourceVO.setSourceId(customer.getSourceId());
      customersVO.setDataSourceVO(dataSourceVO);
    }
    return customersVO;
  }

}
