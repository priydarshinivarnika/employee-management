package com.equifax.datoz.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "cust_scenario")
public class CustomerScenarioVO implements Serializable {

  private static final long serialVersionUID = 1L;
  private Long scenarioId;
  private String scenarioName;
  private String description;
  private Long status;
  private String scenarioData;
  private CustomersVO customersVO;
  private Set<CustomerRequestDataVO> custRequestDataSet;

  /**
   * @return the scenarioId
   */
  @Id
  @SequenceGenerator(name = "seq_cust_scenario_id", sequenceName = "seq_cust_scenario_id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cust_scenario_id")
  @Column(name = "scenario_id")
  public Long getScenarioId() {
    return scenarioId;
  }

  /**
   * @param scenarioId
   *            the scenarioId to set
   */
  public void setScenarioId(Long scenarioId) {
    this.scenarioId = scenarioId;
  }

  /**
   * @return the scenarioName
   */
  @Column(name = "scenario_name")
  public String getScenarioName() {
    return scenarioName;
  }

  /**
   * @param scenarioName
   *            the scenarioName to set
   */
  public void setScenarioName(String scenarioName) {
    this.scenarioName = scenarioName;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description
   *            the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the status
   */
  public Long getStatus() {
    return status;
  }

  /**
   * @param status
   *            the status to set
   */
  public void setStatus(Long status) {
    this.status = status;
  }

  /**
   * @return the scenarioData
   */
  @Column(name = "scenario_data")
  public String getScenarioData() {
    return scenarioData;
  }

  /**
   * @param scenarioData
   *            the scenarioData to set
   */
  public void setScenarioData(String scenarioData) {
    this.scenarioData = scenarioData;
  }

  /**
    * @return the customersVO
    */
  @OneToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "customer_id")
  public CustomersVO getCustomersVO() {
    return customersVO;
  }

  /**
   * @param customersVO the customersVO to set
   */
  public void setCustomersVO(CustomersVO customersVO) {
    this.customersVO = customersVO;
  }

  /**
     * @return the custRequestDataSet
     */
  @ManyToMany(fetch = FetchType.LAZY)
  @JoinTable(name = "cust_scenario_request_mapping", joinColumns = {
    @JoinColumn(name = "scenario_id")}, inverseJoinColumns = {@JoinColumn(name = "request_id")})
  public Set<CustomerRequestDataVO> getCustRequestDataSet() {
    return custRequestDataSet;
  }

  /**
   * @param custRequestDataSet the custRequestDataSet to set
   */
  public void setCustRequestDataSet(Set<CustomerRequestDataVO> custRequestDataSet) {
    this.custRequestDataSet = custRequestDataSet;
  }

}
