package com.equifax.datoz.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "basic_info")
public class BasicInfoVO extends BasicVO{
  Long infoId;
  String firstName;
  String lastName;
  String middleName;
  String socialSecurityNumber;
  String houseNumber;
  String streetName;
  String streetType;
  String city;
  String state;
  String country;
  String zip;
  Long status;
  private Long sourceId;
  

  @Id
  @SequenceGenerator(name = "seq_info_id", sequenceName = "seq_info_id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_info_id")
  @Column(name = "info_id")
  public Long getInfoId() {
    return infoId;
  }

  public void setInfoId(Long infoId) {
    this.infoId = infoId;
  }

  @Column(name = "SSN")
  public String getSocialSecurityNumber() {
    return socialSecurityNumber;
  }

  public void setSocialSecurityNumber(String socialSecurityNumber) {
    this.socialSecurityNumber = socialSecurityNumber;
  }

  @Column(name = "house_number")
  public String getHouseNumber() {
    return houseNumber;
  }

  public void setHouseNumber(String houseNumber) {
    this.houseNumber = houseNumber;
  }

  @Column(name = "street_name")
  public String getStreetName() {
    return streetName;
  }

  public void setStreetName(String streetName) {
    this.streetName = streetName;
  }

  @Column(name = "street_type")
  public String getStreetType() {
    return streetType;
  }

  public void setStreetType(String streetType) {
    this.streetType = streetType;
  }

  @Column(name = "city")
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  @Column(name = "state")
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  @Column(name = "zip")
  public String getZip() {
    return zip;
  }

  public void setZip(String zip) {
    this.zip = zip;
  }

  @Column(name = "middle_name")
  public String getMiddleName() {
    return middleName;
  }

  public void setMiddleName(String middleName) {
    this.middleName = middleName;
  }

  @Column(name = "first_name")
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  @Column(name = "last_name")
  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  @Column(name = "status")
  public Long getStatus() {
    return status;
  }

  public void setStatus(Long status) {
    this.status = status;
  }

  @Override
  public String toString() {
    return firstName + lastName + middleName + socialSecurityNumber + houseNumber + status + streetName + streetType + city + state + state + zip + infoId;
  }
  
  @Column(name = "source_id")
  public Long getSourceId() {
    return sourceId;
  }

  /**
    * @param sourceId the sourceId to set
    */
  public void setSourceId(Long sourceId) {
    this.sourceId = sourceId;
  }

}
