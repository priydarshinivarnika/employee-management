package com.equifax.datoz.entity;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "data_source_details")
public class DataSourceDetailsVO implements Serializable {

  private static final long serialVersionUID = 1L;
  private Long id;
  private String headerName;
  private String headerValue;
  private DataSourceVO dataSource;

  /**
   * @return the id
   */
  @Id
  @SequenceGenerator(name = "seq_datasourcedetails_id", sequenceName = "seq_datasourcedetails_id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_datasourcedetails_id")
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *            the id to set
   */
  public void setId(Long id) {
    this.id = id;
  }

  /**
   * @return the header_name
   */
  @Column(name = "header_name")
  public String getHeaderName() {
    return headerName;
  }

  /**
   * @param headerName
   *            the headerName to set
   */
  public void setHeaderName(String headerName) {
    this.headerName = headerName;
  }

  /**
   * @return the headerValue
   */
  @Column(name = "header_value")
  public String getHeaderValue() {
    return headerValue;
  }

  /**
   * @param headerValue
   *            the headerValue to set
   */
  public void setHeaderValue(String headerValue) {
    this.headerValue = headerValue;
  }

  /**
   * @return the dataSource
   */
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "source_id", nullable = false)
  public DataSourceVO getDataSource() {
    return dataSource;
  }

  /**
   * @param dataSource
   *            the dataSource to set
   */
  public void setDataSource(DataSourceVO dataSource) {
    this.dataSource = dataSource;
  }

}
