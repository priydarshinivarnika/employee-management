package com.equifax.datoz.entity;

import java.util.List;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpHeaders;

public class TaskLetDomain  {

  private String url;
  private String format;
  private int priority;
  /** request object list customer request or datasource request*/
  private List<Object> request;
  private long recordLimit;
  private int sourceId;
  /** Data source or customer Object*/
  private Object object;
  private HttpHeaders httpHeaders;
  private boolean scenarioMappingRequired;

  public TaskLetDomain(long recordLimit, Object object, List<Object> request) {
    super();

    this.recordLimit = recordLimit;
    this.object = object;
    this.request = request;
    this.scenarioMappingRequired = Boolean.FALSE;
    prepareHttpHeaderAndUrl();

  }

  public String getUrl() {
    return url;

  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public int getPriority() {
    return priority;
  }

  public void setPriority(int priority) {
    this.priority = priority;
  }

  public List<Object> getRequest() {
    return request;
  }

  public void setRequest(List<Object> request) {
    this.request = request;
  }

  public long getRecordLimit() {
    return recordLimit;
  }

  public void setRecordLimit(long recordLimit) {
    this.recordLimit = recordLimit;
  }

  /**
   * @return the sourceId
   */
  public int getSourceId() {
    return sourceId;
  }

  /**
   * @param sourceId the sourceId to set
   */
  public void setSourceId(int sourceId) {
    this.sourceId = sourceId;
  }

 
  /**
   * @return the object
   */
  public Object getObject() {
    return object;
  }

  /**
   * @param object the object to set
   */
  public void setObject(Object object) {
    this.object = object;
  }

  /**
   * method to create authentication headers
   */
  private void prepareHttpHeaderAndUrl() {
    String plainCredentials = null;
    String base64Credentials = null;
    this.httpHeaders = new HttpHeaders();

    if (null != this.object) {
      if (this.object instanceof DataSourceVO) {

        DataSourceVO dataSource = (DataSourceVO) this.object;
        this.url = dataSource.getUrl();
        this.format = dataSource.getFormat();
        plainCredentials = dataSource.getUsername().trim() + ":" + dataSource.getPassword().trim();
        base64Credentials = new String(Base64.encodeBase64(plainCredentials.getBytes()));
        this.httpHeaders.add("Authorization", "Basic " + base64Credentials);
        addHttpHeadersForDatasource(dataSource);
      } else {
        CustomersVO customer = (CustomersVO) this.object;
        this.url = customer.getUrl();
        this.format = customer.getFormat();
        plainCredentials = customer.getUsername().trim() + ":" + customer.getPassword().trim();
        base64Credentials = new String(Base64.encodeBase64(plainCredentials.getBytes()));
        this.httpHeaders.add("Authorization", "Basic " + base64Credentials);
        addHttpHeadersForCustomers(customer);
      }
    }

  }

  /**
   * @param customer
   */
  private void addHttpHeadersForCustomers(CustomersVO customer) {
    for (CustomerDetailsVO customerDetails : customer.getCustomerDetails()) {
      if (null != customerDetails.getHeaderName() && null != customerDetails.getHeaderValue()) {
        this.httpHeaders.add(customerDetails.getHeaderName(), customerDetails.getHeaderValue());
      }

    }
  }

  /**
   * @param dataSource
   */
  private void addHttpHeadersForDatasource(DataSourceVO dataSource) {
    for (DataSourceDetailsVO dataSourceDetails : dataSource.getDataSourceDetails()) {
      if (null != dataSourceDetails.getHeaderName() && null != dataSourceDetails.getHeaderValue()) {
        this.httpHeaders.add(dataSourceDetails.getHeaderName(), dataSourceDetails.getHeaderValue());
      }

    }
  }

  /**
   * @return the httpHeaders
   */
  public HttpHeaders getHttpHeaders() {
    return httpHeaders;
  }

  /**
   * @param httpHeaders the httpHeaders to set
   */
  public void setHttpHeaders(HttpHeaders httpHeaders) {
    this.httpHeaders = httpHeaders;
  }

  /**
   * @return the scenarioMappingRequired
   */
  public boolean isScenarioMappingRequired() {
    return scenarioMappingRequired;
  }

  /**
   * @param scenarioMappingRequired the scenarioMappingRequired to set
   */
  public void setScenarioMappingRequired(boolean scenarioMappingRequired) {
    this.scenarioMappingRequired = scenarioMappingRequired;
  }

}
