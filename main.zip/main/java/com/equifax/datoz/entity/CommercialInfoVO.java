package com.equifax.datoz.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "commercial_info")
public class CommercialInfoVO extends BasicVO{

    Long commercialInfoId;
    String businessName;
    String taxId;
    String houseNumber;
    String addressLine;
    String streetName;
    String streetType;
    String city;
    String state;
    String country;
    String zip;
    Long status;
    private Long sourceId;
    
    

    @Id
    @SequenceGenerator(name = "seq_commercial_info_id", sequenceName = "seq_commercial_info_id ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_commercial_info_id")
    @Column(name = "commercial_info_id")
    public Long getCommercialInfoId() {
        return commercialInfoId;
    }
    public void setCommercialInfoId(Long commercialInfoId) {
        this.commercialInfoId = commercialInfoId;
    }
    
    @Column(name = " business_name")
    public String getBusinessName() {
        return businessName;
    }
    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }
    
    @Column(name = "tax_id")
    public String getTaxId() {
        return taxId;
    }
    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }
    
    @Column(name = "house_number")
    public String getHouseNumber() {
        return houseNumber;
    }
    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }
    
    @Column(name = "address_line")
    public String getAddressLine() {
        return addressLine;
    }
    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }
    
    @Column(name = "street_name")
    public String getStreetName() {
        return streetName;
    }
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }
    
    @Column(name = "street_type")
    public String getStreetType() {
        return streetType;
    }
    public void setStreetType(String streetType) {
        this.streetType = streetType;
    }
    
    @Column(name = "city")
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    
    @Column(name = "state")
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    
    @Column(name = "country")
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    
    @Column(name = "zip")
    public String getZip() {
        return zip;
    }
    public void setZip(String zip) {
        this.zip = zip;
    }
    
    @Column(name = "status")
    public Long getStatus() {
        return status;
    }
    public void setStatus(Long status) {
        this.status = status;
    }
    
    @Column(name = "source_id")
    public Long getSourceId() {
        return sourceId;
    }
    

    /**
      * @param sourceId the sourceId to set
      */
    public void setSourceId(Long sourceId) {
        this.sourceId = sourceId;
    }
    
    
    @Override
    public String toString() {
      return  businessName + taxId;
    }
    
}
