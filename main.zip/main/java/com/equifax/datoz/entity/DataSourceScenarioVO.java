package com.equifax.datoz.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "ds_scenario")
public class DataSourceScenarioVO implements Serializable {

  private static final long serialVersionUID = 1L;
  private Long scenarioId;
  private String scenarioName;
  private String description;
  private Long status;
  private String scenarioData;
  private DataSourceVO dataSourceVO;
  private Set<DataSourceRequestDataVO> dsRequestDataSet;

  /**
   * @return the scenarioId
   */
  @Id
  @SequenceGenerator(name = "seq_scenario_id", sequenceName = "seq_scenario_id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_scenario_id")
  @Column(name = "scenario_id")
  public Long getScenarioId() {
    return scenarioId;
  }

  /**
   * @param scenarioId
   *            the scenarioId to set
   */
  public void setScenarioId(Long scenarioId) {
    this.scenarioId = scenarioId;
  }

  /**
   * @return the scenarioName
   */
  @Column(name = "scenario_name")
  public String getScenarioName() {
    return scenarioName;
  }

  /**
   * @param scenarioName
   *            the scenarioName to set
   */
  public void setScenarioName(String scenarioName) {
    this.scenarioName = scenarioName;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description
   *            the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the status
   */
  public Long getStatus() {
    return status;
  }

  /**
   * @param status
   *            the status to set
   */
  public void setStatus(Long status) {
    this.status = status;
  }

  /**
   * @return the scenarioData
   */
  @Column(name = "scenario_data")
  public String getScenarioData() {
    return scenarioData;
  }

  /**
   * @param scenarioData
   *            the scenarioData to set
   */
  public void setScenarioData(String scenarioData) {
    this.scenarioData = scenarioData;
  }

  /**
   * @return the dataSourceVO
   */
  @OneToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "source_id")
  public DataSourceVO getDataSourceVO() {
    return dataSourceVO;
  }

  /**
   * @param dataSourceVO the dataSourceVO to set
   */
  public void setDataSourceVO(DataSourceVO dataSourceVO) {
    this.dataSourceVO = dataSourceVO;
  }

  /**
   * @return the dsRequestDataSet
   */
  @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @JoinTable(name = "ds_scenario_request_mapping", joinColumns = {
    @JoinColumn(name = "scenario_id")}, inverseJoinColumns = {@JoinColumn(name = "request_id")})
  public Set<DataSourceRequestDataVO> getDsRequestDataSet() {
    return dsRequestDataSet;
  }

  /**
   * @param dsRequestDataSet the dsRequestDataSet to set
   */
  public void setDsRequestDataSet(Set<DataSourceRequestDataVO> dsRequestDataSet) {
    this.dsRequestDataSet = dsRequestDataSet;
  }

}
