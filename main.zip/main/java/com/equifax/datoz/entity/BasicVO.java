package com.equifax.datoz.entity;

public class BasicVO {

}
