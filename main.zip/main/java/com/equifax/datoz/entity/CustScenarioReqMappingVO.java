package com.equifax.datoz.entity;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cust_scenario_request_mapping")
public class CustScenarioReqMappingVO {

  private MappingGroup mapping;

  /**
   * @return the mapping
   */
  @EmbeddedId
  public MappingGroup getMapping() {
    return mapping;
  }

  /**
   * @param mapping the mapping to set
   */
  public void setMapping(MappingGroup mapping) {
    this.mapping = mapping;
  }

}
