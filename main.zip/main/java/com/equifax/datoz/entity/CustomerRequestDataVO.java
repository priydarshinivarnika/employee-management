package com.equifax.datoz.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "cust_request_data")
public class CustomerRequestDataVO implements Serializable {

  private static final long serialVersionUID = 1L;
  private String requestDataValue;
  private String responseData;
  private Date createdDate;
  private Date updatedDate;
  private Date resUpdatedDate;
  private Long requestId;
  private Long status;
  private Long customerId;
  private Long reqSendStatus;
  
  /**
   * 
   */
  public CustomerRequestDataVO() {
    super();
  }
  /**
   * @param requestDataValue
   */
  public CustomerRequestDataVO(String requestDataValue) {
    super();
    this.requestDataValue = requestDataValue;
  }


  /**
   * @return the requestData
   */
  @Column(name = "request_data")
  public String getRequestDataValue() {
    return requestDataValue;
  }

  /**
   * @param requestData
   *            the requestData to set
   */
  public void setRequestDataValue(String requestDataValue) {
    this.requestDataValue = requestDataValue;
  }

  /**
   * @return the responseData
   */
  @Column(name = "response_data")
  public String getResponseData() {
    return responseData;
  }

  /**
   * @param responseData the responseData to set
   */
  public void setResponseData(String responseData) {
    this.responseData = responseData;
  }

  /**
   * @return the createdDate
   */
  @Column(name = "created_date")
  public Date getCreatedDate() {
    return createdDate;
  }

  /**
   * @param createdDate
   *            the createdDate to set
   */
  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  /**
   * @return the updatedDate
   */
  @Column(name = "updated_date")
  public Date getUpdatedDate() {
    return updatedDate;
  }

  /**
   * @param updatedDate
   *            the updatedDate to set
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * @return the res_updated_date
   */
  @Column(name = "res_updated_date")
  public Date getResUpdatedDate() {
    return resUpdatedDate;
  }

  /**
   * @param res_updated_date the res_updated_date to set
   */
  public void setResUpdatedDate(Date resUpdatedDate) {
    this.resUpdatedDate = resUpdatedDate;
  }

  /**
   * @return the requestId
   */
  @Id
  @SequenceGenerator(name = "seq_cust_requestdata_id", sequenceName = "seq_cust_requestdata_id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cust_requestdata_id")
  @Column(name = "request_id")
  public Long getRequestId() {
    return requestId;
  }

  /**
   * @param requestId
   *            the requestId to set
   */
  public void setRequestId(Long requestId) {
    this.requestId = requestId;
  }

  /**
   * @return the status
   */
  @Column(name = "status")
  public Long getStatus() {
    return status;
  }

  /**
   * @param status
   *            the status to set
   */
  public void setStatus(Long status) {
    this.status = status;
  }

  /**
   * @return the customerId
   */
  @Column(name = "customer_id")
  public Long getCustomerId() {
    return customerId;
  }

  /**
   * @param customerId
   *            the customerId to set
   */
  public void setCustomerId(Long customerId) {
    this.customerId = customerId;
  }

  /**
   * @return the reqSendStatus
   */
  @Column(name = "req_send_status")
  public Long getReqSendStatus() {
    return reqSendStatus;
  }

  /**
   * @param reqSendStatus the reqSendStatus to set
   */
  public void setReqSendStatus(Long reqSendStatus) {
    this.reqSendStatus = reqSendStatus;
  }

  

}
