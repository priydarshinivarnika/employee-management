package com.equifax.datoz.entity;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "user_roles")
public class UserRolesVO implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  private Long userRoleId;
  private String role;
  private UserDetailsVO userDetails;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_user_role_id")
  @SequenceGenerator(name = "seq_user_role_id", sequenceName = "seq_user_role_id", allocationSize = 1)
  @Column(name = "user_role_id ")
  public Long getUserRoleId() {
    return userRoleId;
  }

  public void setUserRoleId(Long userRoleId) {
    this.userRoleId = userRoleId;
  }

  @Column(name = "role ")
  public String getRole() {
    return role;
  }

  public void setRole(String role) {
    this.role = role;
  }

  @OneToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "user_name", nullable = false, referencedColumnName = "user_name")
  public UserDetailsVO getUserDetails() {
    return userDetails;
  }

  public void setUserDetails(UserDetailsVO userDetails) {
    this.userDetails = userDetails;
  }

}
