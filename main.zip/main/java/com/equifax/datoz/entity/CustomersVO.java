package com.equifax.datoz.entity;

import java.io.Serializable;
import java.util.*;

import javax.persistence.*;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "customers")
public class CustomersVO implements Serializable {

  private static final long serialVersionUID = 1L;
  private Long customerid;
  private String name;
  private String description;
  private String url;
  private String format;
  private String username;
  private String password;
  private Long timeout;
  private Long maxRequestPerDay;
  private String requestSchema;
  private String responseSchema;
  private String personalInfoSchema;
  private String additionalDetails;
  private DataSourceVO dataSourceVO;
  private Set<CustomerDetailsVO> customerDetails = new HashSet<CustomerDetailsVO>();
  private String sslDetails;

  public CustomersVO() {
    super();
  }
  @Column(name = "ssl_details")
  public String getSslDetails() {
    return sslDetails;
  }

  public void setSslDetails(String sslDetails) {
    this.sslDetails = sslDetails;
  }

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_customer_id")
  @SequenceGenerator(name = "seq_customer_id", sequenceName = "seq_customer_id", allocationSize = 1)
  @Column(name = "customer_id")
  public Long getCustomerid() {
    return customerid;
  }

  public void setCustomerid(Long customerid) {
    this.customerid = customerid;
  }

  @Column(name = "customer_name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public Long getTimeout() {
    return timeout;
  }

  public void setTimeout(Long timeout) {
    this.timeout = timeout;
  }

  @Column(name = "max_request_per_day")
  public Long getMaxRequestPerDay() {
    return maxRequestPerDay;
  }

  public void setMaxRequestPerDay(Long maxRequestPerDay) {
    this.maxRequestPerDay = maxRequestPerDay;
  }

  @Column(name = "request_schema")
  public String getRequestSchema() {
    return requestSchema;
  }

  public void setRequestSchema(String requestSchema) {
    this.requestSchema = requestSchema;
  }

  @Column(name = "response_schema")
  public String getResponseSchema() {
    return responseSchema;
  }

  public void setResponseSchema(String responseSchema) {
    this.responseSchema = responseSchema;
  }

  @Column(name = "personal_info_schema")
  public String getPersonalInfoSchema() {
    return personalInfoSchema;
  }

  public void setPersonalInfoSchema(String personalInfoSchema) {
    this.personalInfoSchema = personalInfoSchema;
  }

  @Column(name = "additional_details")
  public String getAdditionalDetails() {
    return additionalDetails;
  }

  public void setAdditionalDetails(String additionalDetails) {
    this.additionalDetails = additionalDetails;
  }

  /**
   * @return the dataSourceVO
   */
  @OneToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "source_id")
  public DataSourceVO getDataSourceVO() {
    return dataSourceVO;
  }

  /**
   * @param dataSourceVO the dataSourceVO to set
   */
  public void setDataSourceVO(DataSourceVO dataSourceVO) {
    this.dataSourceVO = dataSourceVO;
  }

  @OneToMany(fetch = FetchType.EAGER, mappedBy = "customers")
  @Cascade({CascadeType.ALL})
  public Set<CustomerDetailsVO> getCustomerDetails() {
    return customerDetails;
  }

  public void setCustomerDetails(Set<CustomerDetailsVO> customerDetails) {
    this.customerDetails = customerDetails;
  }


}
