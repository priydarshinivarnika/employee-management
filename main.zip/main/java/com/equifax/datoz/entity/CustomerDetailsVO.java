package com.equifax.datoz.entity;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "customer_details")

public class CustomerDetailsVO implements Serializable {

  private static final long serialVersionUID = 1L;
  private Long id;
  private String headerName;
  private String headerValue;
  private CustomersVO customers;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_customerdetails_id")
  @SequenceGenerator(name = "seq_customerdetails_id", sequenceName = "seq_customerdetails_id", allocationSize = 1)

  @Column(name = "id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  @Column(name = "header_name")
  public String getHeaderName() {
    return headerName;
  }

  public void setHeaderName(String headerName) {
    this.headerName = headerName;
  }

  @Column(name = "header_value")
  public String getHeaderValue() {
    return headerValue;
  }

  public void setHeaderValue(String headerValue) {
    this.headerValue = headerValue;
  }

  @ManyToOne(fetch = FetchType.EAGER)
  @Cascade({CascadeType.ALL})
  @JoinColumn(name = "customer_id", nullable = false)
  public CustomersVO getCustomers() {
    return customers;
  }

  public void setCustomers(CustomersVO customers) {
    this.customers = customers;
  }

}
