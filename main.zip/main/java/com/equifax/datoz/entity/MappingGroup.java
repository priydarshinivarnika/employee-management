package com.equifax.datoz.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MappingGroup implements Serializable {

  private Long scenarioId;

  private Long requestId;

  /**
   * @return the scenarioId
   */
  @Column(name = "scenario_id")
  public Long getScenarioId() {
    return scenarioId;
  }

  /**
   * @param scenarioId the scenarioId to set
   */
  public void setScenarioId(Long scenarioId) {
    this.scenarioId = scenarioId;
  }

  /**
   * @return the requestId
   */
  @Column(name = "request_id")
  public Long getRequestId() {
    return requestId;
  }

  /**
   * @param requestId the requestId to set
   */
  public void setRequestId(Long requestId) {
    this.requestId = requestId;
  }

}
