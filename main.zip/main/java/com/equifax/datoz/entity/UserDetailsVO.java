package com.equifax.datoz.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "user_details")
public class UserDetailsVO implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  private Long userId;
  private String name;
  private String userName;
  private String password;
  private Long status;
  private Date expiryDate;
  private Long passwordRetryCount;
  private UserRolesVO userRoles;
  private Set<AuditLogVO> auditLogs = new HashSet<AuditLogVO>(0);
  
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_user_id")
  @SequenceGenerator(name = "seq_user_id", sequenceName = "seq_user_id", allocationSize = 1)
  @Column(name = "user_id")
  public Long getUserId() {
    return userId;
  }

  public void setUserId(Long userId) {
    this.userId = userId;
  }

  @Column(name = "name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Column(name = "user_name")
  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  @Column(name = "password")
  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  @Column(name = "status")
  public Long getStatus() {
    return status;
  }

  public void setStatus(Long status) {
    this.status = status;
  }

  @Column(name = "expiry_date")
  public Date getExpiryDate() {
    return expiryDate;
  }

  public void setExpiryDate(Date expiryDate) {
    this.expiryDate = expiryDate;
  }

  @Column(name = "pwd_retry_count")
  public Long getPasswordRetryCount() {
    return passwordRetryCount;
  }

  public void setPasswordRetryCount(Long passwordRetryCount) {
    this.passwordRetryCount = passwordRetryCount;
  }

  @OneToOne(fetch = FetchType.EAGER, mappedBy = "userDetails")
  @Cascade({CascadeType.ALL})
  public UserRolesVO getUserRoles() {
    return userRoles;
  }

  public void setUserRoles(UserRolesVO userRoles) {
    this.userRoles = userRoles;
  }
  
  @OneToMany(fetch = FetchType.EAGER, mappedBy = "userDetailsVO")
  @Cascade({CascadeType.ALL})
  public Set<AuditLogVO> getAuditLogs() {
	return auditLogs;
  }

  public void setAuditLogs(Set<AuditLogVO> auditLogs) {
	this.auditLogs = auditLogs;
  }

}
