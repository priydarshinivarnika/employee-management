package com.equifax.datoz.handler;

public class Model{
	
String firstName;
String lastName;
String middleName;
String socialSecurityNumber;
String houseNumber;
String streetName;
String streetType;
String city;
String state;
String zip;
	
public Model() {
super();
}
public String getSocialSecurityNumber(){
return socialSecurityNumber;
}
public void setSocialSecurityNumber(String socialSecurityNumber){
this.socialSecurityNumber = socialSecurityNumber;
}
public String getHouseNumber(){
return houseNumber;
}
public void setHouseNumber(String houseNumber){
this.houseNumber = houseNumber;
}
public String getStreetName(){
return streetName;
}
public void setStreetName(String streetName){
this.streetName = streetName;
}
public String getStreetType(){
return streetType;
}
public void setStreetType(String streetType){
this.streetType = streetType;
}
public String getCity(){
return city;
}
public void setCity(String city){
this.city = city;
}
public String getState(){
return state;
}
public void setState(String state){
this.state = state;
}
public String getZip(){
return zip;
}
public void setZip(String zip){
this.zip = zip;
}
public String getMiddleName(){
return middleName;
}
public void setMiddleName(String middleName){
this.middleName = middleName;
}
public String getFirstName(){
return firstName;
}
public void setFirstName(String firstName){
this.firstName = firstName;
}
public String getLastName(){
return lastName;
}
public void setLastName(String lastName){
this.lastName = lastName;
}
}
