package com.equifax.datoz.handler;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;

import com.equifax.datoz.util.PIFffparser;
import com.google.gson.Gson;

public class AdditionalDetailsHandler {

    Map<String, String> additionalFieldMap = new HashMap<String, String>();
    String additionalDetails = null;
    Gson gson = new Gson();
/*
 * additional detail string for json
 */
    public String getAdditionalDetailForJson(String[] fields, String[] fieldPath) {
        for (int index = 0; index < fields.length; index++) {
            additionalFieldMap.put(fields[index], fieldPath[index]);
        }

        additionalDetails = getAdditionalDetailString(additionalFieldMap);
        return additionalDetails;
    }
    
    /*
     * for XML
     */

    public String getAdditionalDetailForXml(String[] fields, String[] fieldPath) {

        for (int index = 0; index < fields.length; index++) {

            if (fieldPath[index].contains("/")) {

                additionalFieldMap.put(fields[index], fieldPath[index]);

            } else {

                String field = fieldPath[index].replace(".", "/");

                String fieldPathString = "/" + field;

                additionalFieldMap.put(fields[index], fieldPathString);

            }
        }

        additionalDetails = getAdditionalDetailString(additionalFieldMap);
        return additionalDetails;
    }

    
    /*
     * for FFF
     */
    public String getAdditionalDetailForFff(String[] fields, String[] fieldPath, String resSchema) {
        for (int index = 0; index < fields.length; index++) {
            PIFffparser ffparser = new PIFffparser();

            JSONObject responseSchema = ffparser.getJsonObject(resSchema);
            String fieldValue = (String) responseSchema.get(fieldPath[index]);
            additionalFieldMap.put(fields[index], fieldValue);
        }

        additionalDetails = getAdditionalDetailString(additionalFieldMap);
        return additionalDetails;
    }

    /*
     * converting additional detail map to string
     */
    private String getAdditionalDetailString(Map<String, String> additionalFieldMap) {
        Gson gson = new Gson();
        String addDetails = null;
        if (null != additionalFieldMap && !additionalFieldMap.isEmpty()) {
            addDetails = gson.toJson(additionalFieldMap);
        }
        return addDetails;

    }
}
