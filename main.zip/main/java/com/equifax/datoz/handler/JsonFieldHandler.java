package com.equifax.datoz.handler;


import java.util.*;


import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonFieldHandler {
  private static final Logger LOGGER = Logger.getLogger(JsonFieldHandler.class);

  /**
   * Method to get all fields
   * @param json
   * @return 
   */
  public Set<String> getAllFieldNames(String json) {
    JSONObject jsonObject = null;
    Set<String> keys = null;
    try {
      jsonObject = new JSONObject(json);
      keys = getAllKeys("", jsonObject);
    } catch (JSONException e) {
      LOGGER.error(e);
      throw e;
    }
   
    return keys;
  }
  /**
   * Method to get all keys from object
   * @param prefix
   * @param object
   */

  private Set<String> getAllKeys(String prefix, JSONObject object) {
      return getAllKeys(prefix, object, new TreeSet<>());
    }
  /**
   * Method to get all keys from array
   * @param prefix
   * @param array
   */
    private Set<String> getAllKeys(String prefix, JSONArray array) {
      return getAllKeys(prefix, array, new TreeSet<>());
    }

    private Set<String> getAllKeys(String prefix, JSONArray array, Set<String> keys) {
      for (int i = 0; i < array.length(); i++) {
        Object object = array.get(i);
        if (object instanceof JSONObject){
          keys.addAll(getAllKeys(prefix, array.getJSONObject(i)));
        }
        if (object instanceof JSONArray){
          keys.addAll(getAllKeys(prefix, array.getJSONArray(i)));
        }
      }

      return keys;
    }
    /**
     * Method to iterate all keys and add prefix
     * @param prefix
     * @param json
     * @param keys
     */
    private Set<String> getAllKeys(String prefix, JSONObject json, Set<String> keys) {
      for (Object keyObject : json.keySet()) {
        String key = (String) keyObject;
        Object object = json.get(key);
        if (object instanceof JSONObject) {
          
          prefix = key;
          Set<String> all = getAllKeys(prefix, json.getJSONObject(key));
          
          for (String akey : all) {
            keys.add(prefix + "." + akey);
          }
        }
        if (object instanceof JSONArray) {
          prefix = key;
          Set<String> all = getAllKeys(prefix, json.getJSONArray(key));
          for (String akey : all) {
            keys.add(prefix + "." + akey);
          }
        }
      }
      
      keys.addAll(json.keySet());
      return keys;
    }
  
  
}
