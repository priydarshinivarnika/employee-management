package com.equifax.datoz.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class RulesHandler {
  private static final Logger LOGGER = Logger.getLogger(RulesHandler.class);
  
  /**
   * Method to divide a rule
   * @param scenarioRule
   * @return
   */
  public List<String> divideRule(String scenarioRule) {
    String key = null;
    String value = null;
    String dbScenarioRule = null;
    List<String> rulesList = new ArrayList<String>();
    Map<String, String> dbRuleMap = new HashMap<String, String>();
    String[] multipleRules = scenarioRule.split("\\sOR\\s");
    if (null != multipleRules) {
      for (String stringRule : multipleRules) {

        String[] rules = stringRule.split("\\sAND\\s");
        if (null != rules) {
          for (String string : rules) {

            String[] words = string.split("\\sis\\s");

            for (String w : words) {

              if (w.contains("$")) {
                key = w;
                key = key.replaceAll("\\{", "");
                key = key.replaceAll("\\}", "");
                key = key.replaceAll("\\$", "");

              } else if (w.contains("'")) {
                value = w;

                value = value.replaceAll("\'", "");

              }

            }

            if (null != key && null != value) {
              dbRuleMap.put(key, value);

            }
          }
          dbScenarioRule = getDbScenarioRule( dbRuleMap);

        }
        rulesList.add(dbScenarioRule);
      }

    }
    return rulesList;

  }

  /** Method to get Database Scenario Rule
   * @param dbScenarioRule
   * @param dbRuleMap
   * @return
   */
  private String getDbScenarioRule( Map<String, String> dbRuleMap) {
    ObjectMapper objectMapper = new ObjectMapper();
    String dbScenarioRule = null;
    try {
      dbScenarioRule = objectMapper.writeValueAsString(dbRuleMap);
    } catch (JsonGenerationException | JsonMappingException e) {
      LOGGER.error(e);
    } catch (IOException e) {
      LOGGER.error(e);
    }
    return dbScenarioRule;
  }
}
