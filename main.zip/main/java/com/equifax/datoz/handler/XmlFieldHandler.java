package com.equifax.datoz.handler;

import java.io.IOException;
import java.io.StringReader;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XmlFieldHandler {
  private static final Logger LOGGER = Logger.getLogger(XmlFieldHandler.class);
  private static final String NEWROOT = "newRoot";

  
  /**
   * Method to parse xml
   * @param resschema
   * @return
   */
  public Set<String> getXml(String resschema)  {

    Set<String> keys = new TreeSet<String>();
    try {
      DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
      Document document = docBuilder.parse(new InputSource(new StringReader(resschema)));
      Element root = document.getDocumentElement();
      Element newRoot = document.createElement(NEWROOT);
      newRoot.appendChild(root);

      keys = getAllKeys(newRoot, keys);

    } catch (ParserConfigurationException|SAXException| IOException e) {
      LOGGER.error(e);
    }
    return keys;

  }
  /**
   * Method to get all keys from xml
   * @param node
   * @param keys
   * @return
   */
  public static Set<String> getAllKeys(Node node,
    Set<String> keys) {
    if (node.getNodeType() == Node.ELEMENT_NODE) {
      NodeList nodeList = node.getChildNodes();
      int nodeLength = nodeList.getLength();
      for (int i = 0; i < nodeLength; i++) {
        Node childNode = nodeList.item(i);
        String key = childNode.getNodeName();

        Set<String> all = getAllKeys(nodeList.item(i),
          new TreeSet<>());
        for (String aKey : all) {
          keys.add(key + "." + aKey);

        }
      }
      keys.addAll(getKeySet(node));
    }
    return keys;
  }
  /**
   * Method to iterate all nodes
   * @param node
   * @return
   */
  public static Set<String> getKeySet(Node node) {

    Set<String> keys = new TreeSet<String>();
    NodeList list = node.getChildNodes();
    int listSize = list.getLength();
    for (int i = 0; i < listSize; i++) {
      if (list.item(i).getNodeType() == Node.ELEMENT_NODE) {

        String nodeName = list.item(i).getNodeName();
        keys.add(nodeName);
      }

    }
    return keys;
  }
}
