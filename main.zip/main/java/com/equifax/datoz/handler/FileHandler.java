package com.equifax.datoz.handler;

import org.apache.log4j.Logger;
import org.springframework.web.multipart.MultipartFile;





  public class FileHandler {

      private static final Logger LOGGER = Logger.getLogger(FileHandler.class);

      /**
       * Method to convert file to string
       * @param file
       * @return
       */
    public String fileToString(MultipartFile file) {

       String schema = null;
      if (file != null) {

        try {
          
          byte dataArray[];
          int fileSize;
          fileSize = file.getInputStream().available();
          dataArray = new byte[fileSize];
          file.getInputStream().read(dataArray);
          schema =  new String(dataArray);
        }catch (Exception e) {
          
            LOGGER.info("FileHandler -> FileToString() exception while converting file content to string " + e.getMessage(), e);
          
        }

      }
      return schema;
    }

  }


