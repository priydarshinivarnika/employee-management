package com.equifax.datoz.handler;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.entity.BasicInfoVO;
import com.equifax.datoz.entity.CommercialInfoVO;
import com.google.gson.Gson;

@Component
public class ExcelReader {

  private static final Logger LOGGER = Logger.getLogger(ExcelReader.class);

    public List<Object> convertExcelTOListOfObjects(MultipartFile testDatafile, Long dataSourceId, String datasourceType) {
        List<Map> basicInfoMap = null;
        basicInfoMap = readExcelFile(testDatafile);
        List<Object> basicInfoList = null;
        basicInfoList = cellReader(basicInfoMap, dataSourceId, datasourceType);
        return basicInfoList;
    }

  private String getFileExtension(String fileName) {
    String extension = "";
    int mid = fileName.lastIndexOf(".");
    extension = fileName.substring(mid + 1, fileName.length());
    return extension;
  }

	/**
	 * Method to convert excel to dataList
	 * 
	 * @param requestSchema
	 */
	private List<Map> readExcelFile(MultipartFile testDatafile) {
		Properties properties = getHeaderMappingProps();
		List<Map> dataList = new ArrayList<Map>();

		int sheets = getNumberOfSheets(testDatafile);

		for (int index = 0; index < sheets; index++) {
			Sheet sheet = getExcelSheet(testDatafile, index);
			Map fieldMap = new HashMap();
			Iterator<Row> rows = sheet.rowIterator();
			while (rows.hasNext()) {
				fieldMap = new HashMap();
				Row row = rows.next();
				if (row.getRowNum() < 1) {
					continue;
				}
				Iterator<Cell> cells = row.cellIterator();
				while (cells.hasNext()) {
					Cell cell = cells.next();
					String fieldName = null;
					if (Cell.CELL_TYPE_STRING == sheet.getRow(0).getCell(cell.getColumnIndex()).getCellType()) {
						fieldName = sheet.getRow(0).getCell(cell.getColumnIndex()).getStringCellValue();
						fieldName = fieldName.replaceAll(" ", "");
						fieldName = fieldName.replaceAll("#", "");
					}
					cell.setCellType(Cell.CELL_TYPE_STRING);
					if (null != fieldName) {
						switch (cell.getCellType()) {
						case Cell.CELL_TYPE_NUMERIC:
							fieldMap.put(properties.getProperty(fieldName), cell.getNumericCellValue());
							break;
						case Cell.CELL_TYPE_STRING:
							fieldMap.put(properties.getProperty(fieldName), cell.getStringCellValue());
							break;
						default:
							break;
						}
					}
					System.out.println("\n");
				}
				
				if (!fieldMap.isEmpty()) {
					dataList.add(fieldMap);
				}
			}
		}

		return dataList;
	}
  
	/**
	 * Gets the number of sheets in the uploaded excel file.
	 * @param file
	 * @return number of sheets
	 */
	private int getNumberOfSheets(MultipartFile file) {
		String fileName = file.getOriginalFilename();
		int sheets = 0;
		try {
			Workbook workBook = getWorkBook(fileName, file.getInputStream());
			sheets = workBook.getNumberOfSheets();
		} catch (IOException e) {
			LOGGER.error(e);
		}

		return sheets;
	}

/**
   * Method to get Header Mapping Properties
   * 
   */
  private Properties getHeaderMappingProps() {
    Properties properties = new Properties();
    InputStream propertFile = null;
    propertFile = ExcelReader.class.getClassLoader().getResourceAsStream("HeaderMapping.properties");
    try {
      properties.load(propertFile);
    } catch (IOException e) {
      LOGGER.error(e);
    }
    return properties;
  }

  
	/**
	 * Method to get Excel Sheet
	 * 
	 * @param requestSchema
	 */
	private Sheet getExcelSheet(MultipartFile uploadedTestData, int sheetIndex) {
		Sheet sheet = null;
		String fileName = uploadedTestData.getOriginalFilename();
		InputStream stream;
		try {
			stream = uploadedTestData.getInputStream();
			Workbook workBook = getWorkBook(fileName, stream);
			sheet = workBook.getSheetAt(sheetIndex);
		} catch (IOException e) {
			LOGGER.error(e);
		}
		return sheet;
	}

	/**
	 * Returns the workbook.
	 *  
	 * @param fileName
	 * @param stream
	 * @return the workbook
	 */
	private Workbook getWorkBook(String fileName, InputStream stream) {
		Workbook workBook = null;
		String fileType = getFileExtension(fileName);
		try {
			if ("xls".equalsIgnoreCase(fileType)) {
				workBook = new HSSFWorkbook(stream);
			} else if ("xlsx".equalsIgnoreCase(fileType)) {
				workBook = new XSSFWorkbook(stream);
			}
		} catch (IOException e) {
			LOGGER.error(e);
		}
		return workBook;
	}
  
    /**
     * Method to get basic info list
     *  @param dataList
     *  @param dataSourceId
     */
    private List<Object> cellReader(List<Map> dataList, Long dataSourceId, String datasourceType) {
        List<Object> infoList = new ArrayList<Object>();

        if (datasourceType.equals(Constants.CONSUMER)) {
            for (Map map : dataList) {

                String jsonString = new Gson().toJson(map);

                BasicInfoVO basicInfo = new Gson().fromJson(jsonString, BasicInfoVO.class);
                basicInfo.setStatus(0L);
                basicInfo.setSourceId(dataSourceId);
                if (!basicInfo.toString().isEmpty()) {

                    infoList.add(basicInfo);

                }

            }
        } else if (datasourceType.equals(Constants.COMMERCIAL)) {
            for (Map map : dataList) {

                String jsonString = new Gson().toJson(map);

                CommercialInfoVO commercialInfo = new Gson().fromJson(jsonString, CommercialInfoVO.class);
                commercialInfo.setStatus(0L);
                commercialInfo.setSourceId(dataSourceId);
                if (!commercialInfo.toString().isEmpty()) {

                    infoList.add(commercialInfo);

                }

            }
        }
        return infoList;
    }
}

