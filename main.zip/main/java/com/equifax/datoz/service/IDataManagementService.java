package com.equifax.datoz.service;

import java.util.List;
import java.util.Set;

import com.equifax.datoz.domain.AuditLog;
import com.equifax.datoz.domain.Customers;
import com.equifax.datoz.domain.DataSource;
import com.equifax.datoz.domain.RequestData;
import com.equifax.datoz.domain.Scenario;
import com.equifax.datoz.entity.BasicInfoVO;
import com.equifax.datoz.entity.CommercialInfoVO;
import com.equifax.datoz.entity.CustomerRequestDataVO;
import com.equifax.datoz.entity.CustomerScenarioVO;
import com.equifax.datoz.entity.CustomersVO;
import com.equifax.datoz.entity.DataSourceRequestDataVO;
import com.equifax.datoz.entity.DataSourceScenarioVO;
import com.equifax.datoz.entity.DataSourceVO;

public interface IDataManagementService {

  void saveRequest(final RequestData requestData);





  List<DataSource> getAllDataSource();

  List<Customers> getAllCustomer();

  List<Customers> getAllCustomerBySource(Long id);

  /**
   * Method to save data source
   * 
   * @param dataSource
   */
  void saveDataSource(final DataSource dataSource);

  /**
   * Method to save customer
   * 
   * @param customer
   */
  void saveCustomer(final Customers customer);

  /**
   * Method to save scenario
   * 
   * @param scenario
   */
  void saveScenario(final Scenario scenario);

  /**
   * Method to get all scenario from db
   * 
   * @return
   */
  List<Scenario> getAllScenario();

  /**
   * Method to get valid request data for a particular scenario
   * 
   * @param scenario
   * @return
   */
  Set<RequestData> getDataForScenario(final Long scenarioId, final Long sourceId, final String sourceType);
  Set<RequestData> getDataPagination(final Long scenarioId, final Long sourceId, final String sourceType, final Long count, int pageSize);

  /**
   * Method to search request data based on form fields
   * 
   * @param field
   * @return
   */
  List<RequestData> searchRequestData(final String field, final Long dataSourceId, final String format, final String sourceType);

  /**
   * Method to get the data source by id
   * 
   * @param dataSourceId
   * @return
   */
  DataSource getDataSourceById(final Long dataSourceId);

  /**
   * Method to get the customer by id
   * 
   * @param customerId
   * @return
   */
  Customers getCustomerById(final Long customerId);

  /**
   * Method to get request data based on form fields
   * 
   * @param long1
   * @param status 
   * @param reocrdCount 
   * @return
   */
 

  Set<RequestData> setModel(Set<RequestData> testDataList, String personalInfoSchema, String formatOfDatasource,String additionalDetails);

  /**
   * Method to update scenario
   * @param scenario
   */
  void updateScenario(Scenario scenario, String sourceType);

  void deleteHeaders(final Long dataSourceId);

  void deleteCusHeaders(final Long customerId);

  Scenario getScenarioById(final Long scenarioId, final String sourceType);

  List<Scenario> getAllFilteredScenario(String scenario, Long dataSourceId, final String sourceType);
  List<Scenario> getFilteredScenario(String scenario, Long dataSourceId, final String sourceType, final Long count);
  
  Set processScenario(final Scenario scenario);

  List<DataSourceVO> getAllDataSourceVo();

  List<CustomersVO> getAllCustomerBySourceId(Long sourceId);

  long getDataSourceRequestCount(Long sourceId);

  List<CustomersVO> getNoRequestCustomers(Long sourceId);

  List<BasicInfoVO> getBasicInfoList(Long sourceId, Long maxrequestperDay, Long status);
  
  List<CommercialInfoVO> getCommercialInfoList(Long sourceId, Long maxrequestperDay, Long status);

  void insertDataSourceRequest(List<Object> request, List basicInfoList);

  void insertCustomerRequest(List<Object> request, List basicInfoList);

  List<DataSourceScenarioVO> getAllScenarioVo(Long sourceId);

  void updateDataSourceScenario(DataSourceScenarioVO scenario);

  List<CustomerScenarioVO> getCustomerScenario(Long customerid);

  void updateCustomerScenario(CustomerScenarioVO scenario);

  void insertDataSourceSenarioResponseMapping(Long scenarioId, Long requestId);

  void insertCustomerSenarioResponseMapping(Long scenarioId, Long requestId);

  void updateBasicInfo(List<BasicInfoVO> basicInfos);

  List<DataSourceRequestDataVO> getRequestDataBySourceId(DataSourceVO dataSource, Long maxrequestperDay);

  List<CustomerRequestDataVO> getCustomerRequestDataByCustomerId(CustomersVO customer, Long maxrequestperDay);

  List<Scenario> getFilteredScenarioByScenario(String scenario, String customerType);
  
  void saveScenarioMapping(Scenario scenario, Set<RequestData> requestData);
  List<Scenario> getFilteredScenarioByPage(String scenario, String customerType, Long count);
  Long getResultCountForResponses(final Long scenarioId, final String sourceType);


Long getFilteredCountForScenario(String scenario, Long dataSourceId, String sourceType);





Set<RequestData> getEntriesForScenario(int pageSize, Long scenarioId, Long sourceId, String sourceType);
void bulkInsertOfBasicInfo(List<Object> entities);
DataSourceVO getDataSourceVOById(final Long sourceId);
CustomersVO getCustomerVOById(final Long customerId);

	/**
	 * Method to save audit log
	 * 
	 * @param auditlog
	 */
	void saveAuditLog(final AuditLog auditlog);

	Number getAuditLogVOCount();

	List<String[]> getAuditLogList(int days);
}
