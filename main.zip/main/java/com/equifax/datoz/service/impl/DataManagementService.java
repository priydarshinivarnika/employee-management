package com.equifax.datoz.service.impl;

import java.io.IOException;
import java.util.*;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.converter.DomainToEntityConverter;
import com.equifax.datoz.converter.EntityToDomainConverter;
import com.equifax.datoz.dao.IDataManagementDAO;
import com.equifax.datoz.domain.*;
import com.equifax.datoz.entity.*;
import com.equifax.datoz.handler.Model;
import com.equifax.datoz.handler.RulesHandler;
import com.equifax.datoz.service.IDataManagementService;
import com.equifax.datoz.solr.service.ISolrManagementService;
import com.equifax.datoz.util.*;
import com.google.gson.Gson;

@Transactional(readOnly = false)
public class DataManagementService implements IDataManagementService {
  private static final Logger LOGGER = Logger.getLogger(DataManagementService.class);
  @Autowired
  private IDataManagementDAO dataManagementDAO;

  @Autowired
  private ISolrManagementService solrService;

  private ModelMapper modelMapper = new ModelMapper();

  private String isSolrEnabled;

  /**
   * @return the isSolrEnabled
   */
  public String getIsSolrEnabled() {
    return isSolrEnabled;
  }

  /**
   * @param isSolrEnabled the isSolrEnabled to set
   */
  public void setIsSolrEnabled(String isSolrEnabled) {
    this.isSolrEnabled = isSolrEnabled;
  }

  @Override
  public void saveRequest(final RequestData requestData) {
    dataManagementDAO.saveRequest(requestData);
  }

  /**
   * Method to save data source
   * 
   * @param dataSource
   */
  public void saveDataSource(final DataSource dataSource) {
    DataSourceVO dataSourceVO = modelMapper.map(dataSource, DataSourceVO.class);
    dataManagementDAO.saveDataSource(dataSourceVO);
    boolean ch = dataSource.getSourceId() != null;
    if (!ch) {
      dataSource.setSourceId(dataSourceVO.getSourceId());
    }
  }

  /**
   * Method to save customer
   * 
   * @param customer
   */
  public void saveCustomer(final Customers customer) {
    CustomersVO customersVO = DomainToEntityConverter.convertToCustomer(customer);
    dataManagementDAO.saveCustomer(customersVO);
    boolean ch = customer.getCustomerid() != null;
    if (!ch) {
      customer.setCustomerid(customersVO.getCustomerid());

    }
  }

  /**
   * Method to fetch all dataSource from database
   */
  @Override
  public List<DataSource> getAllDataSource() {
    List<DataSourceVO> dataSourceVOs = dataManagementDAO.getAllDataSource();
    List<DataSource> dataSources = null;
    if (null != dataSourceVOs && !dataSourceVOs.isEmpty()) {
      dataSources = new ArrayList<DataSource>();
      for (DataSourceVO dataSourceVO : dataSourceVOs) {
        DataSource dataSource = modelMapper.map(dataSourceVO, DataSource.class);
        dataSources.add(dataSource);
      }
    }
    return dataSources;
  }

  /**
   * Method to fetch all customers from database
   */
  @Override
  public List<Customers> getAllCustomer() {
    List<CustomersVO> customersVOs = dataManagementDAO.getAllCustomer();
    List<Customers> customers = null;
    if (null != customersVOs && !customersVOs.isEmpty()) {
      customers = new ArrayList<Customers>();
      for (CustomersVO customersVO : customersVOs) {
        Customers customer = modelMapper.map(customersVO, Customers.class);
        customers.add(customer);
      }
    }
    return customers;
  }

  /**
   * Method to fetch customers for a datasource
   */
  @Override
  public List<Customers> getAllCustomerBySource(Long id) {
    List<CustomersVO> customersVOs = dataManagementDAO.getAllCustomerBySource(id);
    List<Customers> customers = null;
    if (null != customersVOs && !customersVOs.isEmpty()) {
      customers = new ArrayList<Customers>();
      for (CustomersVO customersVO : customersVOs) {
        Customers customer = modelMapper.map(customersVO, Customers.class);
        customers.add(customer);
      }
    }
    return customers;
  }

  /**
   * Method to save scenario
   * 
   * @param scenario
   */
  public void saveScenario(final Scenario scenario) {
    CustomerScenarioVO customerScenarioVO = DomainToEntityConverter.convertToCustScenario(scenario);
    dataManagementDAO.save(customerScenarioVO);
  }

  /**
   * Method to get all scenarios
   * 
   */
  public List<Scenario> getAllScenario() {
    List<CustomerScenarioVO> customerScenarioVOs = dataManagementDAO.getAllCustScenario();
    List<Scenario> scenarios = null;
    if (null != customerScenarioVOs && !customerScenarioVOs.isEmpty()) {
      scenarios = new ArrayList<Scenario>();
      for (CustomerScenarioVO customerScenarioVO : customerScenarioVOs) {
        Scenario scenario = EntityToDomainConverter.convertCustScenario(customerScenarioVO);
        scenarios.add(scenario);
      }
    }
    return scenarios;
  }

  /**
   * Method to get valid request data for a particular scenario
   * 
   * @param scenarioId
   * @param sourceId
   * @param sourceType
   * @return
   */
  public Set<RequestData> getDataForScenario(final Long scenarioId, final Long sourceId, final String sourceType) {
    Set<RequestData> requestDatas = null;
    String addtionalDetails = null;
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      Set<DataSourceRequestDataVO> dsRequestDataVOs = dataManagementDAO.getDSRequestDataForScenario(scenarioId);
      if (null != dsRequestDataVOs && !dsRequestDataVOs.isEmpty()) {
        requestDatas = new HashSet<RequestData>();
        for (DataSourceRequestDataVO dataSourceRequestDataVO : dsRequestDataVOs) {
          RequestData requestData = EntityToDomainConverter.convertDSRequestData(dataSourceRequestDataVO);
          requestDatas.add(requestData);
        }
        DataSourceVO dataSourceVO = dataManagementDAO.getDataSourceById(sourceId);
        addtionalDetails = dataSourceVO.getAdditionalDetails();
        setModel(requestDatas, dataSourceVO.getPersonalInfoSchema(), dataSourceVO.getFormat(), addtionalDetails);
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      Set<CustomerRequestDataVO> customerRequestDataVOs = dataManagementDAO.getCustRequestDataForScenario(scenarioId);
      if (null != customerRequestDataVOs && !customerRequestDataVOs.isEmpty()) {
        requestDatas = new HashSet<RequestData>();
        for (CustomerRequestDataVO customerRequestDataVO : customerRequestDataVOs) {
          RequestData requestData = EntityToDomainConverter.convertCustRequestData(customerRequestDataVO);
          requestDatas.add(requestData);
        }
        CustomersVO customersVO = dataManagementDAO.getCustomerById(sourceId);
        addtionalDetails = customersVO.getAdditionalDetails();
        setModel(requestDatas, customersVO.getPersonalInfoSchema(), customersVO.getFormat(), addtionalDetails);
      }
    }
    return requestDatas;

  }

  /**
   * Method to get response count
   * @param scenarioId
   * @param sourceType
   * @return
   */
  public Long getResultCountForResponses(final Long scenarioId, final String sourceType) {
    Long resultCount = null;
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      resultCount = dataManagementDAO.getResultCountForData(scenarioId);
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      resultCount = dataManagementDAO.getResultCountForCustomer(scenarioId);
    }
    return resultCount;
  }

  /**
   * Method to get requestData
   * @param scenarioId
   * @param sourceId
   * @param sourceType
   * @param count
   * @param pageSize
   * @return 
   */
  public Set<RequestData> getDataPagination(final Long scenarioId, final Long sourceId, final String sourceType, final Long count, final int pageSize) {
    Set<RequestData> requestDatas = null;
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      Set<DataSourceRequestDataVO> dsRequestDataVOs = dataManagementDAO.getDSRequestDataPagination(scenarioId, count, pageSize);
      if (null != dsRequestDataVOs && !dsRequestDataVOs.isEmpty()) {
        requestDatas = new HashSet<RequestData>();
        for (DataSourceRequestDataVO dataSourceRequestDataVO : dsRequestDataVOs) {
          RequestData requestData = EntityToDomainConverter.convertDSRequestData(dataSourceRequestDataVO);
          requestDatas.add(requestData);
        }
        DataSourceVO dataSourceVO = dataManagementDAO.getDataSourceById(sourceId);
        setModel(requestDatas, dataSourceVO.getPersonalInfoSchema(), dataSourceVO.getFormat(), dataSourceVO.getAdditionalDetails());
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      Set<CustomerRequestDataVO> customerRequestDataVOs = dataManagementDAO.getCustRequestDataPagination(scenarioId, count, pageSize);
      if (null != customerRequestDataVOs && !customerRequestDataVOs.isEmpty()) {
        requestDatas = new HashSet<RequestData>();
        for (CustomerRequestDataVO customerRequestDataVO : customerRequestDataVOs) {
          RequestData requestData = EntityToDomainConverter.convertCustRequestData(customerRequestDataVO);
          requestDatas.add(requestData);
        }
        CustomersVO customersVO = dataManagementDAO.getCustomerById(sourceId);
        setModel(requestDatas, customersVO.getPersonalInfoSchema(), customersVO.getFormat(), customersVO.getAdditionalDetails());
      }
    }
    return requestDatas;

  }

  /**
   * Method to search request data based on form fields
   * 
   * @param field
   * @return
   */
  public List<RequestData> searchRequestData(final String scenarioRule, final Long dataSourceId,
    final String format, final String sourceType) {
    String dbScenarioRule = null;
    List<RequestData> requestDatas = new ArrayList<RequestData>();
    Map<String, String> dbRuleMap = new HashMap<String, String>();

    try {
      dbScenarioRule = constructRule(scenarioRule, dbRuleMap);
    } catch (Exception exception) {
      LOGGER.error(exception);
    }

    requestDatas = getRequestData(dataSourceId, format, dbScenarioRule, sourceType);
    return requestDatas;
  }

  /**
   * @param dataSourceId
   * @param format
   * @param dbScenarioRule
   * @param sourceType
   * @return 
   */
  private List<RequestData> getRequestData(
    final Long dataSourceId, final String format, String dbScenarioRule, final String sourceType) {
    List<RequestData> requestDataList = null;
    List<RequestData> requestDatas = new ArrayList<RequestData>();
    if ("true".equals(isSolrEnabled)) {
      try {
        requestDataList = solrService.searchRequestData(dbScenarioRule, dataSourceId, format, sourceType);
      } catch (Exception exception) {
        LOGGER.error(exception);
        isSolrEnabled = "false";
      }
    }
    if ("false".equals(isSolrEnabled)) {
      requestDataList = getRequestDataFromDB(dataSourceId, format, dbScenarioRule, sourceType);
    }
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDatas = compareRequestData(requestDataList, sourceType, dataSourceId, dbScenarioRule, format);
    }
    return requestDatas;
  }

  /**
   * Method to fetch the matching data from database
   * @param dataSourceId
   * @param format
   * @param dbScenarioRule
   * @param sourceType
   * @return
   */
  private List<RequestData> getRequestDataFromDB(
    final Long dataSourceId, final String format, String dbScenarioRule, final String sourceType) {
    List<RequestData> requestDataList = null;
    if (Constants.DATASOURCE_TYPE.equalsIgnoreCase(sourceType)) {
      List<DataSourceRequestDataVO> dsRequestDataList = dataManagementDAO.searchDSRequestData(dbScenarioRule, dataSourceId, format);
      if (null != dsRequestDataList && !dsRequestDataList.isEmpty()) {
        requestDataList = new ArrayList<>();
        for (DataSourceRequestDataVO dsRequestData : dsRequestDataList) {
          RequestData requestData = modelMapper.map(dsRequestData, RequestData.class);
          requestDataList.add(requestData);
        }
      }
    } else {
      List<CustomerRequestDataVO> custRequestDataList = dataManagementDAO.searchCustRequestData(dbScenarioRule, dataSourceId, format);
      if (null != custRequestDataList && !custRequestDataList.isEmpty()) {
        requestDataList = new ArrayList<>();
        for (CustomerRequestDataVO custRequestData : custRequestDataList) {
          RequestData requestData = modelMapper.map(custRequestData, RequestData.class);
          requestDataList.add(requestData);
        }
      }
    }
    return requestDataList;
  }

  /**
   * Method to compare the response data with scenario rule
   * @param requestDataList
   * @param sourceType
   * @param dataSourceId
   * @param scenarioRule
   * @param format
   * @return
   */
  private List<RequestData> compareRequestData(List<RequestData> requestDataList, String sourceType, Long dataSourceId, String scenarioRule, String format) {
    List<RequestData> requestDatas = new ArrayList<RequestData>();
    String responseSchema = null;
    if (Constants.FFF.equalsIgnoreCase(format)) {
      responseSchema = getResponseSchema(sourceType, dataSourceId);
    }
    for (RequestData requestData : requestDataList) {
      if (isValidJSONRequest(scenarioRule, format, requestData)) {
        requestDatas.add(requestData);
      } else if (isValidXMLRequest(scenarioRule, format, requestData)) {
        requestDatas.add(requestData);
      } else if (isValidFFFRequest(scenarioRule, format, responseSchema, requestData)) {
        requestDatas.add(requestData);
      }
    }
    return requestDatas;
  }

  /**
   * @param scenarioRule
   * @param format
   * @param responseSchema
   * @param requestData
   * @return
   */
  private boolean isValidFFFRequest(String scenarioRule, String format, String responseSchema, RequestData requestData) {
    return null != requestData.getResponseData() && Constants.FFF.equalsIgnoreCase(format) && FFFParserUtil.isScenarioMappingWithResponse(scenarioRule,
      requestData.getResponseData(), responseSchema);
  }

  /**
   * @param scenarioRule
   * @param format
   * @param requestData
   * @return
   */
  private boolean isValidXMLRequest(String scenarioRule, String format, RequestData requestData) {
    return null != requestData.getResponseData() && Constants.XML.equalsIgnoreCase(format)
      && XmlParserUtil.isScenarioMappingWithResponse(scenarioRule,
        requestData.getResponseData());
  }

  /**
   * @param scenarioRule
   * @param format
   * @param requestData
   * @return
   */
  private boolean isValidJSONRequest(String scenarioRule, String format, RequestData requestData) {
    return null != requestData.getResponseData() && Constants.JSON.equalsIgnoreCase(format) && JsonParserUtil.isScenarioMappingWithResponse(scenarioRule,
      requestData.getResponseData());
  }

  /**
   * Method to get the response schema from database
   * @param sourcetype
   * @param dataSourceId
   * @return
   */
  private String getResponseSchema(String sourcetype, Long dataSourceId) {
    String responseData = null;
    if (Constants.DATASOURCE_TYPE.equalsIgnoreCase(sourcetype)) {
      DataSource datasource = getDataSourceById(dataSourceId);
      responseData = datasource.getResponseSchema();

    } else if (Constants.CUSTOMER_TYPE.equalsIgnoreCase(sourcetype)) {
      Customers customer = getCustomerById(dataSourceId);
      responseData = customer.getResponseSchema();
    }
    return responseData;

  }

  /**
   * @param scenarioRule
   * @param dbRuleMap
   * @return
   */
  private String constructRule(final String scenarioRule, Map<String, String> dbRuleMap) {
    String dbScenarioRule = null;
    ObjectMapper objectMapper = new ObjectMapper();
    Map<String, String> jsonFieldMap;
    try {
      jsonFieldMap = objectMapper.readValue(scenarioRule, HashMap.class);

      for (String fieldName : jsonFieldMap.keySet()) {
        if (null != jsonFieldMap.get(fieldName) && !Constants.EXISTS.equalsIgnoreCase(jsonFieldMap.get(fieldName))
          && !jsonFieldMap.get(fieldName).startsWith(Constants.GREATERTHAN)
          && !jsonFieldMap.get(fieldName).startsWith(Constants.LESSTHAN)) {
          dbRuleMap.put(fieldName, jsonFieldMap.get(fieldName));
        }
      }
      dbScenarioRule = objectMapper.writeValueAsString(dbRuleMap);
    } catch (IOException exception) {
      LOGGER.error(exception);
    }
    return dbScenarioRule;
  }

  /**
   * Method to get the data source by id
   * 
   * @param dataSourceId
   * @return
   */
  public DataSource getDataSourceById(final Long dataSourceId) {
    DataSourceVO dataSourceVO = dataManagementDAO.getDataSourceById(dataSourceId);
    DataSource dataSource = null;
    if (null != dataSourceVO) {
      dataSource = modelMapper.map(dataSourceVO, DataSource.class);
    }
    return dataSource;
  }

  /**
   * Method to get the customer by id
   * 
   * @param customerId
   * @return
   */
  public Customers getCustomerById(final Long customerId) {
    CustomersVO customersVO = dataManagementDAO.getCustomerById(customerId);
    Customers customers = null;
    if (null != customersVO) {
      customers = EntityToDomainConverter.convertCustomer(customersVO);
    }
    return customers;
  }

  /**
   * Method to set personal info schema
   */
  public Set<RequestData> setModel(Set<RequestData> requestDataSet, String personalinfoschema, String formatOfDatasource, String additionalDetails) {
    String additionalDetail = additionalDetails;
    Map<String, String> additionalDetailsMap = null;
    String responsepersonalinfo = null;
    String requestString = null;
    String responseString = null;
    Object piParser = null;
    if (formatOfDatasource.equals(Constants.JSON)) {
      piParser = new PIparser();
    } else if (formatOfDatasource.equals(Constants.XML)) {
      piParser = new PIXmlparser();
    } else if (formatOfDatasource.equals(Constants.FFF)) {
      piParser = new PIFffparser();
    }

    for (RequestData requestData : requestDataSet) {
      requestString = requestData.getRequestDataValue();
      responseString = requestData.getResponseData();

      if (formatOfDatasource.equals(Constants.JSON)) {
        PIparser piJSONParser = (PIparser) piParser;
        responsepersonalinfo = piJSONParser.getPersonalInfoJson(personalinfoschema, responseString);
        additionalDetailsMap = getJSONAdditionalDetails(additionalDetail, responseString, piJSONParser);

      } else if (formatOfDatasource.equals(Constants.XML)) {
        PIXmlparser piXMLParser = (PIXmlparser) piParser;
        responsepersonalinfo = piXMLParser.getPersonalInfoXml(personalinfoschema, responseString);
        additionalDetailsMap = getXMLAdditionalDetails(additionalDetail, responseString, piXMLParser);
        requestString = piXMLParser.replaceXml(requestString);
        responseString = piXMLParser.replaceXml(responseString);
        requestData.setResponseData(responseString);
        requestData.setRequestDataValue(requestString);
      } else if (formatOfDatasource.equals(Constants.FFF)) {
        PIFffparser piFFFParser = (PIFffparser) piParser;
        responsepersonalinfo = piFFFParser.getFffPI(personalinfoschema, requestString);
        additionalDetailsMap = getFFFAdditionalDetails(additionalDetail, responseString, piFFFParser);
      }
      requestData.setResmodel(responsepersonalinfo);
      requestData.setAddDetailsModel(additionalDetailsMap);
      Model model = new Gson().fromJson(responsepersonalinfo, Model.class);
      requestData.setModelObject(model);
    }
    return requestDataSet;
  }

  /**
   * @param additionalDetail
   * @param additionalDetailsMap
   * @param responseString
   * @param piFFFParser
   * @return
   */
  private Map<String, String> getFFFAdditionalDetails(String additionalDetail, String responseString, PIFffparser piFFFParser) {
    Map<String, String> additionalDetailsMap = null;
    if (additionalDetail != null && !additionalDetail.isEmpty()) {
      additionalDetailsMap = piFFFParser.getAdditionalDetailsMapForFff(additionalDetail, responseString);
    }
    return additionalDetailsMap;
  }

  /**
   * @param additionalDetail
   * @param additionalDetailsMap
   * @param responseString
   * @param piXMLParser
   * @return
   */
  private Map<String, String> getXMLAdditionalDetails(String additionalDetail, String responseString, PIXmlparser piXMLParser) {
    Map<String, String> additionalDetailsMap = null;
    if (additionalDetail != null && !additionalDetail.isEmpty()) {
      additionalDetailsMap = piXMLParser.getAdditionalDetailsMapForXml(additionalDetail, responseString);
    }
    return additionalDetailsMap;
  }

  /**
   * @param additionalDetail
   * @param additionalDetailsMap
   * @param responseString
   * @param piJSONParser
   * @return
   */
  private Map<String, String> getJSONAdditionalDetails(String additionalDetail, String responseString, PIparser piJSONParser) {
    Map<String, String> additionalDetailsMap = null;
    if (additionalDetail != null && !additionalDetail.isEmpty()) {
      additionalDetailsMap = piJSONParser.getAdditionalDetailsMapForJson(additionalDetail, responseString);
    }
    return additionalDetailsMap;
  }

  /**
   * Method to update scenario in database
   * @param scenario
   * @param sourceType
   * 
   */
  @Override
  public void updateScenario(Scenario scenario, String sourceType) {
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      DataSourceScenarioVO dsScenarioVO = DomainToEntityConverter.convertToDsScenario(scenario);
      dataManagementDAO.update(dsScenarioVO);
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      CustomerScenarioVO customerScenarioVO = DomainToEntityConverter.convertToCustScenario(scenario);
      dataManagementDAO.update(customerScenarioVO);
    }

  }

  /**
   * Method to delete header details of a datasource from database
   * @param dataSourceId
   */
  @Override
  public void deleteHeaders(Long dataSourceId) {
    dataManagementDAO.deleteHeaders(dataSourceId);

  }

  /**
   * Method to delete header details of a customer from database
   * @param customerId
   */
  @Override
  public void deleteCusHeaders(Long customerId) {
    dataManagementDAO.deleteCusHeaders(customerId);

  }

  /**
   * Method to fetch scenario from database based on scenarioId
   * @param scenarioId
   * @param sourceType
   * @return
   */
  @Override
  public Scenario getScenarioById(final Long scenarioId, final String sourceType) {
    Scenario scenario = null;
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      DataSourceScenarioVO dsScenarioVO = dataManagementDAO.getDSScenarioById(scenarioId);
      scenario = EntityToDomainConverter.convertDSScenario(dsScenarioVO);
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      CustomerScenarioVO customerScenarioVO = dataManagementDAO.getCustScenarioById(scenarioId);
      scenario = EntityToDomainConverter.convertCustScenario(customerScenarioVO);
    }
    return scenario;

  }

  /**
   * Method to search scenario based on search criteria
   * @param scenarioName
   * @param sourceId
   * @param sourceType
   * @return
   */
  @Override
  public List<Scenario> getAllFilteredScenario(final String scenarioName, final Long sourceId, final String sourceType) {
    List<Scenario> scenarios = new ArrayList<Scenario>();
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      List<DataSourceScenarioVO> dataSourceScenarioVOs = dataManagementDAO.getAllFilteredScenario(scenarioName, sourceId, sourceType);
      if (null != dataSourceScenarioVOs && !dataSourceScenarioVOs.isEmpty()) {
        for (DataSourceScenarioVO dataSourceScenarioVO : dataSourceScenarioVOs) {
          Scenario scenario = EntityToDomainConverter.convertDSScenario(dataSourceScenarioVO);
          scenarios.add(scenario);
        }
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      List<CustomerScenarioVO> customerScenarioVOs = dataManagementDAO.getAllFilteredScenario(scenarioName, sourceId, sourceType);
      if (null != customerScenarioVOs && !customerScenarioVOs.isEmpty()) {
        for (CustomerScenarioVO customerScenarioVO : customerScenarioVOs) {
          Scenario scenario = EntityToDomainConverter.convertCustScenario(customerScenarioVO);
          scenarios.add(scenario);
        }

      }
    }
    return scenarios;
  }

  /**
   * Method to search scenario based on search criteria with pagination
   * @param scenarioName
   * @param sourceId
   * @param sourceType
   * @param count
   * @return
   */
  @Override
  public List<Scenario> getFilteredScenario(final String scenarioName, final Long sourceId, final String sourceType, final Long count) {
    List<Scenario> scenarios = new ArrayList<Scenario>();
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      List<DataSourceScenarioVO> dataSourceScenarioVOs = dataManagementDAO.getFilteredScenario(scenarioName, sourceId, sourceType, count);
      if (null != dataSourceScenarioVOs && !dataSourceScenarioVOs.isEmpty()) {
        for (DataSourceScenarioVO dataSourceScenarioVO : dataSourceScenarioVOs) {
          Scenario scenario = EntityToDomainConverter.convertDSScenario(dataSourceScenarioVO);
          scenarios.add(scenario);
        }
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      List<CustomerScenarioVO> customerScenarioVOs = dataManagementDAO.getFilteredScenario(scenarioName, sourceId, sourceType, count);
      if (null != customerScenarioVOs && !customerScenarioVOs.isEmpty()) {
        for (CustomerScenarioVO customerScenarioVO : customerScenarioVOs) {
          Scenario scenario = EntityToDomainConverter.convertCustScenario(customerScenarioVO);
          scenarios.add(scenario);
        }

      }
    }
    return scenarios;
  }

  /**
   * Method to fetch matching data for a scenario
   * @param scenario
   * @return 
   */
  public Set<RequestData> processScenario(Scenario scenario) {
    RulesHandler rulesHandler = new RulesHandler();
    Set<RequestData> modelSet = null;
    List<RequestData> requestDataList = null;
    Set<RequestData> requestDataSet = new HashSet<RequestData>();
    String piSchema = null;
    String format = null;
    String addtionalDetails = null;
    Map<String, String> dbRuleMap = new HashMap<String, String>();
    List<String> rulesList = rulesHandler.divideRule(scenario.getScenarioData());
    if (null != rulesList && !rulesList.isEmpty()) {
      for (String ruleJson : rulesList) {
        String dbScenarioRule = constructRule(ruleJson, dbRuleMap);

        if (Constants.DATASOURCE_TYPE.equals(scenario.getSourceType())) {
          saveOrUpdateDSScenario(scenario);
          DataSourceVO dataSourceVO = dataManagementDAO.getDataSourceById(scenario.getSourceId());
          piSchema = dataSourceVO.getPersonalInfoSchema();
          format = dataSourceVO.getFormat();
          addtionalDetails = dataSourceVO.getAdditionalDetails();
          requestDataList = getRequestData(scenario.getSourceId(), dataSourceVO.getFormat(), dbScenarioRule, Constants.DATASOURCE_TYPE);
        } else if (Constants.CUSTOMER_TYPE.equals(scenario.getSourceType())) {
          saveOrUpdateCustScenario(scenario);
          CustomersVO customerVO = dataManagementDAO.getCustomerById(scenario.getSourceId());
          piSchema = customerVO.getPersonalInfoSchema();
          format = customerVO.getFormat();
          addtionalDetails = customerVO.getAdditionalDetails();
          requestDataList = getRequestData(scenario.getSourceId(), customerVO.getFormat(), dbScenarioRule, Constants.CUSTOMER_TYPE);
        }
        if (null != requestDataList) {
          requestDataSet.addAll(requestDataList);
        }

      }
    }
    modelSet = setModel(requestDataSet, piSchema, format, addtionalDetails);
    return modelSet;
  }

  /**
   * Method to save or update scenario specific to a customer
   * @param scenario
   */
  private void saveOrUpdateCustScenario(Scenario scenario) {
    CustomerScenarioVO scenarioVO = DomainToEntityConverter.convertToCustScenario(scenario);
    scenarioVO.setStatus(1L);
    scenarioVO.setCustRequestDataSet(null);
    if (null == scenarioVO.getScenarioId()) {
      dataManagementDAO.save(scenarioVO);
      scenario.setScenarioId(scenarioVO.getScenarioId());
    } else {
      LOGGER.info("update entity");
      dataManagementDAO.update(scenarioVO);
      dataManagementDAO.deleteCustScenarioMapping(scenarioVO.getScenarioId());
    }
  }

  /**
   * Method to save or update scenario specific to datasource
   * @param scenario
   */
  private void saveOrUpdateDSScenario(Scenario scenario) {
    DataSourceScenarioVO scenarioVO = DomainToEntityConverter.convertToDsScenario(scenario);
    scenarioVO.setStatus(1L);
    scenarioVO.setDsRequestDataSet(null);
    if (null == scenarioVO.getScenarioId()) {
      dataManagementDAO.saveScenario(scenarioVO);
    } else {
      LOGGER.info("merge entity");
      dataManagementDAO.update(scenarioVO);
    }
  }

  /**
   * Method to fetch all datasources from database
   * @return
   */
  @Override
  public List<DataSourceVO> getAllDataSourceVo() {
    return dataManagementDAO.getAllDataSourceByQuery();
  }

  /**
   * Method to fetch all customers from database based on sourceId
   * @param sourceId
   * @return
   */
  @Override
  public List<CustomersVO> getAllCustomerBySourceId(Long sourceId) {
    return dataManagementDAO.getAllCustomerBySource(sourceId);
  }

  /**
   * Method to request data count for a datasource
   * @param sourceId
   * @return
   */
  @Override
  public long getDataSourceRequestCount(Long sourceId) {
    return dataManagementDAO.getDataSourceRequestCount(sourceId);
  }

  /**
   * Method to get request data count for customers
   * @param sourceId
   * @return
   */
  @Override
  public List<CustomersVO> getNoRequestCustomers(Long sourceId) {
    return dataManagementDAO.getNoRequestCustomers(sourceId);
  }

  /**
   * Method to get the basic info from db based on sourceId
   * @param sourceId
   * @param maxrequestperDay
   * @param status
   * @return
   */
  @Override
  public List<BasicInfoVO> getBasicInfoList(Long sourceId, Long maxrequestperDay, Long status) {
    return dataManagementDAO.getBasicInfoList(sourceId, maxrequestperDay, status);
  }

  /**
   * Method to get the commercial info from db based on sourceId
   * @param sourceId
   * @param maxrequestperDay
   * @param status
   * @return
   */
  @Override
  public List<CommercialInfoVO> getCommercialInfoList(Long sourceId, Long maxrequestperDay, Long status) {
    return dataManagementDAO.getCommercialInfoList(sourceId, maxrequestperDay, status);
  }

  /**
   * Method to save request data of datasource
   * @param request
   * @param basicInfoList
   */
  @Override
  public void insertDataSourceRequest(List<Object> request, List basicInfoList) {
    updateBasicInfo(basicInfoList);
    dataManagementDAO.insertDataSourceRequest(request);
    dataManagementDAO.delDSScenarioMapping(request);
  }

  /**
   * Method to save request data of customer
   */
  @Override
  public void insertCustomerRequest(List<Object> request, List basicInfoList) {
    updateBasicInfo(basicInfoList);
    dataManagementDAO.insertCustomerRequest(request);
    dataManagementDAO.delCustScenarioMapping(request);
  }

  /**
   * Method to get all scenarios for a datasource
   * @param sourceId
   * @return
   */
  @Override
  public List<DataSourceScenarioVO> getAllScenarioVo(Long sourceId) {
    return dataManagementDAO.getAllDSScenario(sourceId);
  }

  /**
   * Method to update datasource specific scenario
   */
  @Override
  public void updateDataSourceScenario(DataSourceScenarioVO scenario) {
    dataManagementDAO.update(scenario);
  }

  /**
   * Method to get all scenarios for a customer
   * @param customerid
   * @return
   */
  @Override
  public List<CustomerScenarioVO> getCustomerScenario(Long customerid) {

    return dataManagementDAO.getCustomerScenario(customerid);
  }

  /**
   * Method to update customer scenario
   * @param scenario
   */
  @Override
  public void updateCustomerScenario(CustomerScenarioVO scenario) {
    dataManagementDAO.update(scenario);
  }

  /**
   * Method to save datasource scenario mapping
   * @param scenarioId
   * @param requestId
   */
  @Override
  public void insertDataSourceSenarioResponseMapping(Long scenarioId, Long requestId) {
    dataManagementDAO.insertDSScenarioRequestmapping(scenarioId, requestId);

  }

  /**
   * Method to save customer scenario mapping
   * @param scenarioId
   * @param requestId
   */
  @Override
  public void insertCustomerSenarioResponseMapping(Long scenarioId, Long requestId) {
    dataManagementDAO.insertCustScenarioRequestmapping(scenarioId, requestId);

  }

  /**
   * Method to update basic info
   * @param basicInfos
   */
  @Override
  public void updateBasicInfo(List basicInfos) {
    if (null != basicInfos && !basicInfos.isEmpty()) {
      dataManagementDAO.updateInfo(basicInfos);
    }
  }

  /**
   * Method to get request data for a datasource
   * @param dataSource
   * @param maxrequestperDay
   * @return
   */
  @Override
  public List<DataSourceRequestDataVO> getRequestDataBySourceId(DataSourceVO dataSource, Long maxrequestperDay) {
    List<DataSourceRequestDataVO> dataSourceRequestDataVOs = dataManagementDAO.getRequestDataBySourceId(dataSource.getSourceId(), true, maxrequestperDay);
    if (null == dataSourceRequestDataVOs || dataSourceRequestDataVOs.isEmpty() || maxrequestperDay > dataSourceRequestDataVOs.size()) {
      dataSourceRequestDataVOs = dataManagementDAO.getRequestDataBySourceId(dataSource.getSourceId(), false, maxrequestperDay - dataSourceRequestDataVOs.size());
    }
    return dataSourceRequestDataVOs;
  }

  /**
   * Method to get request data for a customer
   * @param customer
   * @param recordCount
   * @return
   */
  @Override
  public List<CustomerRequestDataVO> getCustomerRequestDataByCustomerId(CustomersVO customer, Long recordCount) {
    List<CustomerRequestDataVO> customerRequestDataVOs = dataManagementDAO.getCustomerRequestDataByCustomerId(customer.getCustomerid(), true, recordCount);
    if (null == customerRequestDataVOs || customerRequestDataVOs.isEmpty() || recordCount>customerRequestDataVOs.size()) {
      customerRequestDataVOs = dataManagementDAO.getCustomerRequestDataByCustomerId(customer.getCustomerid(), false, recordCount-customerRequestDataVOs.size());
    }
    return customerRequestDataVOs;
  }

  /**
   * Method to get scenario details based on search criteria
   * @param scenarioName
   * @param customerType
   * @return
   */
  @Override
  public List<Scenario> getFilteredScenarioByScenario(String scenarioName, String customerType) {
    List<Scenario> scenarios = new ArrayList<Scenario>();
    List<CustomerScenarioVO> customerScenarioVOs = dataManagementDAO.getFilteredScenarioByScenario(scenarioName, customerType);
    if (null != customerScenarioVOs && !customerScenarioVOs.isEmpty()) {
      for (CustomerScenarioVO customerScenarioVO : customerScenarioVOs) {
        Scenario scenario = EntityToDomainConverter.convertCustScenario(customerScenarioVO);
        scenarios.add(scenario);
      }
    }
    return scenarios;
  }

  /**
   * Method to save scenario mapping to database
   * @param scenario
   * @param requestDatas
   *
   */
  @Override
  public void saveScenarioMapping(Scenario scenario, Set<RequestData> requestDatas) {
    if (null != requestDatas && null != scenario.getScenarioId()) {
      if (Constants.DATASOURCE_TYPE.equalsIgnoreCase(scenario.getSourceType())) {
        for (RequestData requestData : requestDatas) {
          dataManagementDAO.insertDSScenarioRequestmapping(scenario.getScenarioId(), requestData.getRequestId());
        }
      } else if (Constants.CUSTOMER_TYPE.equalsIgnoreCase(scenario.getSourceType())) {
        LOGGER.info("updated mapping");
        for (RequestData requestData : requestDatas) {
          dataManagementDAO.insertCustScenarioRequestmapping(scenario.getScenarioId(), requestData.getRequestId());
        }
      }
    }
  }

  /**
   * Method to get scenario details based on search criteria with pagination
   * @param scenarioName
   * @param customerType
   * @param count
   * @return
   */
  @Override
  public List<Scenario> getFilteredScenarioByPage(String scenarioName, String customerType, Long count) {
    List<Scenario> scenarios = new ArrayList<Scenario>();
    List<CustomerScenarioVO> customerScenarioVOs = dataManagementDAO.getFilteredScenarioByPage(scenarioName, customerType, count);
    if (null != customerScenarioVOs && !customerScenarioVOs.isEmpty()) {
      for (CustomerScenarioVO customerScenarioVO : customerScenarioVOs) {
        Scenario scenario = EntityToDomainConverter.convertCustScenario(customerScenarioVO);
        scenarios.add(scenario);
      }
    }
    return scenarios;
  }

  /**
   * Method to get scenario count
   * @param scenario
   * @param sourceId
   * @param sourceType
   * @return
   */
  @Override
  public Long getFilteredCountForScenario(String scenario, Long sourceId, String sourceType) {
    Long totalResultCount = null;
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      totalResultCount = dataManagementDAO.getAllFilteredCountForScenario(scenario, sourceId, sourceType);

    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      totalResultCount = dataManagementDAO.getAllFilteredCountForScenario(scenario, sourceId, sourceType);
    }
    return totalResultCount;
  }

  /**
   * Method to get request data for scenario
   * @param pageSize
   * @param scenarioId
   * @param sourceId
   * @param sourceType
   * @return
   */
  @Override
  public Set<RequestData> getEntriesForScenario(int pageSize, Long scenarioId, Long sourceId, String sourceType) {
    Set<RequestData> requestDatas = null;
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      Set<DataSourceRequestDataVO> dsRequestDataVOs = dataManagementDAO.getDSRequestEntriesForScenario(scenarioId, pageSize);
      if (null != dsRequestDataVOs && !dsRequestDataVOs.isEmpty()) {
        requestDatas = new HashSet<RequestData>();
        for (DataSourceRequestDataVO dataSourceRequestDataVO : dsRequestDataVOs) {
          RequestData requestData = EntityToDomainConverter.convertDSRequestData(dataSourceRequestDataVO);
          requestDatas.add(requestData);
        }
        DataSourceVO dataSourceVO = dataManagementDAO.getDataSourceById(sourceId);
        setModel(requestDatas, dataSourceVO.getPersonalInfoSchema(), dataSourceVO.getFormat(), dataSourceVO.getAdditionalDetails());
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      Set<CustomerRequestDataVO> customerRequestDataVOs = dataManagementDAO.getCustRequestEntriesForScenario(scenarioId, pageSize);
      if (null != customerRequestDataVOs && !customerRequestDataVOs.isEmpty()) {
        requestDatas = new HashSet<RequestData>();
        for (CustomerRequestDataVO customerRequestDataVO : customerRequestDataVOs) {
          RequestData requestData = EntityToDomainConverter.convertCustRequestData(customerRequestDataVO);
          requestDatas.add(requestData);
        }
        CustomersVO customersVO = dataManagementDAO.getCustomerById(sourceId);
        setModel(requestDatas, customersVO.getPersonalInfoSchema(), customersVO.getFormat(), customersVO.getAdditionalDetails());
      }
    }
    return requestDatas;

  }

  /**
   * Method to insert basic info to database 
   */
  @Override
  public void bulkInsertOfBasicInfo(List<Object> entities) {
    dataManagementDAO.bulkInsertOfBasicInfo(entities);
  }

  /**
   * Method to get datasource details by sourceId
   * @param sourceId
   * @return
   */
  @Override
  public DataSourceVO getDataSourceVOById(Long sourceId) {
    return dataManagementDAO.getDataSourceVOById(sourceId);
  }

  /**
   * Method to get customer details by customerId
   */
  @Override
  public CustomersVO getCustomerVOById(Long customerId) {
    return dataManagementDAO.getCustomerVOById(customerId);
  }
  
	/**
	 * Method to save audit log
	 * 
	 * @param auditlog
	 */
	@Override
	public void saveAuditLog(final AuditLog auditlog) {
		AuditLogVO auditlogVO = DomainToEntityConverter
				.convertToAuditLog(auditlog);
		dataManagementDAO.saveAuditLog(auditlogVO);

	}
	
	/**
	 * Method to get count of User-login in last 7 days
	 */
	@Override
	public Number getAuditLogVOCount() {
		return dataManagementDAO.getAuditLogVOCount();
	}

	/**
	 * Method to get list of User-login
	 */
	@Override
	public List<String[]> getAuditLogList(int days) {
		return dataManagementDAO.getAuditLogList(days);
	}
}
