package com.equifax.datoz.solr.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.ModifiableSolrParams;
import org.codehaus.jackson.map.ObjectMapper;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.domain.RequestData;
import com.equifax.datoz.exception.DatozException;
import com.equifax.datoz.solr.service.ISolrManagementService;

public class SolrManagementService implements ISolrManagementService {

  /**
   * Instance of Logger
   */
  private static final Logger LOGGER = Logger.getLogger(SolrManagementService.class);

  private String dsSolrUrl;

  private String custSolrUrl;

  /**
   * Method to search response data for selected datasource in Solr
   * @param field
   * @param dataSourceId
   * @param format
   * @return
   */
  @Override
  public List<RequestData> searchRequestData(final String field, final Long dataSourceId, final String format, final String sourceType) {
    LOGGER.debug("Entered SolrManagementService.searchDSRequestData()");
    List<RequestData> dataSourceRequestDataVOs = null;
    String solrUrl = null;
    String id = null;
    if (Constants.DATASOURCE_TYPE.equalsIgnoreCase(sourceType)) {
      solrUrl = dsSolrUrl;
      id = "sourceId:";
    } else {
      solrUrl = custSolrUrl;
      id = "customerId:";
    }
    SolrClient solr = new HttpSolrClient.Builder(solrUrl).build();
    Map<String, String> jsonFieldMap = new HashMap<String, String>();

    try {
      SolrQuery query = new SolrQuery();
      ModifiableSolrParams qparams = new ModifiableSolrParams();
      query.setRows(Integer.MAX_VALUE);

      ObjectMapper objectMapper = new ObjectMapper();
      jsonFieldMap = objectMapper.readValue(field, HashMap.class);

      if (!jsonFieldMap.isEmpty()) {
        qparams.add("defType", "edismax");
        qparams.add("df", Constants.RESPONSE_DATA);
        StringBuilder sb = new StringBuilder();
        String solrSearchQuery = setSolrQuery(format, jsonFieldMap);
        sb.append(solrSearchQuery + " && " + id + dataSourceId + " && status:1" + " && reqSendStatus:1");
        qparams.add("q", sb.toString());
      }
      query.add(qparams);
      QueryResponse rsp = solr.query(query);
      SolrDocumentList docs = rsp.getResults();
      if (null != docs && !docs.isEmpty()) {
        dataSourceRequestDataVOs = setRequestDataList(docs);
      }
    } catch (IOException | SolrServerException exception) {
      LOGGER.error("Exception SolrManagementService.searchDSRequestData() " + exception.getMessage());
      throw new DatozException(exception);
    }
    LOGGER.debug("Exited SolrManagementService.searchDSRequestData()");
    return dataSourceRequestDataVOs;

  }

  /**
   * Method to create requestData object from SolrDocument
   * @param docs
   * @return
   */
  private List<RequestData> setRequestDataList(SolrDocumentList docs) {
    List<RequestData> requestDatas = new ArrayList<RequestData>();
    for (SolrDocument solrDocument : docs) {
      if (null != solrDocument.get(Constants.REQUEST_ID)) {
        RequestData requestData = new RequestData();
        requestData.setRequestId(Long.valueOf(solrDocument.getFieldValueMap().get(Constants.REQUEST_ID).toString()));
        requestData.setStatus(Long.valueOf(solrDocument.getFieldValueMap().get("status").toString()));
        requestData.setReqSendStatus(Long.valueOf(solrDocument.getFieldValueMap().get("reqSendStatus").toString()));
        requestData.setResponseData(solrDocument.getFieldValueMap().get(Constants.RESPONSE_DATA).toString());
        requestData.setRequestDataValue(solrDocument.getFieldValueMap().get("requestDataValue").toString());
        requestDatas.add(requestData);
      }
    }
    return requestDatas;
  }

  /**
   * Method to set solr search query based on format
   * @param format
   * @return
   */
  private String setSolrQuery(String format, Map<String, String> jsonFieldMap) {
    StringBuilder sb = new StringBuilder();
    int count = 1;
    for (String fieldName : jsonFieldMap.keySet()) {
      String[] pathArray = fieldName.split("\\.");
      if (Constants.JSON.equalsIgnoreCase(format)) {
        sb.append("*\\\"" + pathArray[pathArray.length - 1] + "\\\"\\ \\:\\ \\\"" + jsonFieldMap.get(fieldName) + "\\\"*");
      } else if (Constants.XML.equalsIgnoreCase(format)) {
        sb.append("*<" + pathArray[pathArray.length - 1] + ">" + jsonFieldMap.get(fieldName) + "*");
      }
      if (jsonFieldMap.keySet().size() != count) {
        sb.append(" && ");
        count++;
      }
    }
    return sb.toString();
  }

  /**
   * @return the dsSolrUrl
   */
  public String getDsSolrUrl() {
    return dsSolrUrl;
  }

  /**
   * @param dsSolrUrl the dsSolrUrl to set
   */
  public void setDsSolrUrl(String dsSolrUrl) {
    this.dsSolrUrl = dsSolrUrl;
  }

  /**
   * @return the custSolrUrl
   */
  public String getCustSolrUrl() {
    return custSolrUrl;
  }

  /**
   * @param custSolrUrl the custSolrUrl to set
   */
  public void setCustSolrUrl(String custSolrUrl) {
    this.custSolrUrl = custSolrUrl;
  }
}
