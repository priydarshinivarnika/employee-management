package com.equifax.datoz.solr.service;

import java.util.List;

import com.equifax.datoz.domain.RequestData;

public interface ISolrManagementService {

  /**
   * Method to search response data in Solr
   * @param field
   * @param dataSourceId
   * @param format
   * @return
   */
  List<RequestData> searchRequestData(final String field, final Long dataSourceId, final String format, final String sourceType);
}
