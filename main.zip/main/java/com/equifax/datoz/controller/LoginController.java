package com.equifax.datoz.controller;

import javax.servlet.http.HttpServletRequest;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.domain.UserDetails;
import com.equifax.datoz.domain.UserRoles;
import com.equifax.datoz.login.service.ILoginManagementService;

@RestController
public class LoginController {

    @Autowired
    private ILoginManagementService loginService;
    /**
     * login page
     * @param error
     * @param logout
     * @return
     */

    @RequestMapping(value = {"/welcome", "/login"}, method = RequestMethod.GET)
    public ModelAndView login(@RequestParam(value = "error", required = false) String error,
        @RequestParam(value = "logout", required = false) String logout) {

        ModelAndView model = new ModelAndView();
        if (error != null) {
            model.addObject("error", "Invalid username and password!");
        }

        if (logout != null) {
            model.addObject("msg", "You've been logged out successfully.");
        }
        model.setViewName("login");

        return model;

    }
/**
 *  for 403 access denied page
 * @return
 */
   
    @RequestMapping(value = "/403", method = RequestMethod.GET)
    public ModelAndView accesssDenied() {

        ModelAndView model = new ModelAndView();

        // check if user is login
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            org.springframework.security.core.userdetails.UserDetails userDetail = (org.springframework.security.core.userdetails.UserDetails) auth.getPrincipal();
            model.addObject(Constants.LOGIN_USERNAME, userDetail.getUsername());

        }

        model.setViewName("403");
        return model;

    }

    /**
     * navigating to new user page
     * @return
     */
    @RequestMapping(value = "/newUser", method = RequestMethod.GET)
    public ModelAndView addNewUserPage() {

        ModelAndView modelandView = null;
        modelandView = new ModelAndView(Constants.SIGNUP_PAGE);

        return modelandView;

    }

    /**
     * Adding a new user
     * @param request
     * @return
     * @throws ParseException
     */
    
    @RequestMapping(value = "/Register", method = RequestMethod.POST)
    public ModelAndView addNewUser(HttpServletRequest request) throws ParseException {

        ModelAndView modelandView = null;

        String name = request.getParameter("Name");
        String username = request.getParameter("UserName");
        String password = request.getParameter("Password");
        String repassword = request.getParameter("RePassword");
        String userRole = request.getParameter("userRole");
        UserDetails userDetails = new UserDetails();
        Long count = loginService.existingUserCountWithSameName(username);

        if (count == 0) {
            if (password.equals(repassword)) {

                SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
                String dateInString = "31-dec-2050";
                Date date = formatter.parse(dateInString);
                java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                UserRoles userRoles = new UserRoles();
                userRoles.setRole(userRole);
                userRoles.setUserDetails(userDetails);
                userDetails.setName(name);
                userDetails.setUserName(username);
                userDetails.setPassword(password);
                userDetails.setStatus(1L);
                userDetails.setPasswordRetryCount(0L);
                userDetails.setExpiryDate(sqlDate);
                userDetails.setUserRoles(userRoles);

                loginService.saveUser(userDetails);
                modelandView = new ModelAndView("SuccessRegister");
                modelandView.addObject(Constants.LOGIN_MESSAGE, "Registered");

            } else {
                modelandView = new ModelAndView(Constants.SIGNUP_PAGE);
                modelandView.addObject(Constants.LOGIN_MESSAGE, "Password mismatch !!!");
                modelandView.addObject("name", name);
                modelandView.addObject(Constants.LOGIN_USERNAME, username);
            }
        } else {
            modelandView = new ModelAndView(Constants.SIGNUP_PAGE);
            modelandView.addObject(Constants.LOGIN_MESSAGE, "Username already exists !!!");
            modelandView.addObject("name", name);
        }
        return modelandView;

    }

    /**
     * navigate to forgot password page
     * @return
     */
    @RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
    public ModelAndView forgotPasswordPage() {

        ModelAndView modelandView = null;
        modelandView = new ModelAndView(Constants.PASSWORD_PAGE);
        return modelandView;

    }

    /**
     * Resetting password
     * @param request
     * @return
     * @throws ParseException
     */
     
    @RequestMapping(value = "/changePassword", method = RequestMethod.POST)
    public ModelAndView changePassword(HttpServletRequest request) throws ParseException {

        ModelAndView modelandView = null;

        String username = request.getParameter("UserName").trim();
        String name = request.getParameter("Name").trim();
        String password = request.getParameter("Password");
        String repassword = request.getParameter("RePassword");

        Long count = loginService.existingUserCountWithSameName(username);
        Long userId = null;
        UserDetails userDetails = new UserDetails();

        if (count == 0) {
            modelandView = new ModelAndView(Constants.PASSWORD_PAGE);
            modelandView.addObject(Constants.LOGIN_MESSAGE, "Not an existing user!!! Please give a valid username");

        } else if (count == 1) {
            userId = loginService.getUserId(username);

            String nameOfUser = loginService.getNameWithUserId(userId).trim();

            if (nameOfUser.equals(name)) {

                if (password.equals(repassword)) {
                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
                    String dateInString = "31-dec-2050";
                    Date date = formatter.parse(dateInString);
                    java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                    userDetails.setUserId(userId);
                    userDetails.setName(name);
                    userDetails.setUserName(username);
                    userDetails.setPassword(repassword);
                    userDetails.setStatus(1L);
                    userDetails.setPasswordRetryCount(0L);
                    userDetails.setExpiryDate(sqlDate);
                    loginService.saveUser(userDetails);
                    modelandView = new ModelAndView("SuccessPassword");
                    modelandView.addObject(Constants.LOGIN_MESSAGE, "Updated");
                } else {
                    modelandView = new ModelAndView(Constants.PASSWORD_PAGE);
                    modelandView.addObject(Constants.LOGIN_MESSAGE, "Password mismatch !!!");
                    modelandView.addObject("name", name);
                    modelandView.addObject(Constants.LOGIN_USERNAME, username);

                }

            } else {

                modelandView = new ModelAndView(Constants.PASSWORD_PAGE);
                modelandView.addObject(Constants.LOGIN_MESSAGE, "Please give your valid name");
                modelandView.addObject(Constants.LOGIN_USERNAME, username);

            }

        }

        return modelandView;

    }

}
