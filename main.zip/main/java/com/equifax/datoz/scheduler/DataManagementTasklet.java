package com.equifax.datoz.scheduler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.params.ModifiableSolrParams;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.domain.CommercialInfo;
import com.equifax.datoz.entity.BasicInfoVO;
import com.equifax.datoz.entity.BasicVO;
import com.equifax.datoz.entity.CommercialInfoVO;
import com.equifax.datoz.entity.CustomerDetailsVO;
import com.equifax.datoz.entity.CustomerRequestDataVO;
import com.equifax.datoz.entity.CustomersVO;
import com.equifax.datoz.entity.DataSourceDetailsVO;
import com.equifax.datoz.entity.DataSourceRequestDataVO;
import com.equifax.datoz.entity.DataSourceVO;
import com.equifax.datoz.entity.TaskLetDomain;
import com.equifax.datoz.service.IDataManagementService;

public class DataManagementTasklet implements Runnable {
  private static final Logger LOGGER = Logger.getLogger(DataManagementTasklet.class);

  IDataManagementService dataService;
  Map<Integer, List<TaskLetDomain>> dataSourcePriorityMap;
  Map<Long, List> updatableBasicInfos;

  public DataManagementTasklet() {
    super();
  }

  public DataManagementTasklet(IDataManagementService dataMgmntService) {
    super();
    this.dataService = dataMgmntService;
    this.dataSourcePriorityMap = new HashMap<Integer, List<TaskLetDomain>>();

  }

  public IDataManagementService getDataService() {
    return dataService;
  }

  public void setDataService(IDataManagementService dataService) {
    this.dataService = dataService;
  }

  @Override
  public void run() {

    List<TaskLetDomain> taskletList;

    LOGGER.info("DataManagementTasklet run method started ");
    try {

      prepareSchedulerTaskOnDataPriority(this.dataSourcePriorityMap);

      if (null != dataSourcePriorityMap && !dataSourcePriorityMap.isEmpty()) {
        Thread[] threads = new Thread[dataSourcePriorityMap.size()];
        int j = 0;

        for (Integer i : dataSourcePriorityMap.keySet()) {
          taskletList = dataSourcePriorityMap.get(i);
          if (!taskletList.isEmpty()) {
            threads[j] = new Thread(new DataProcessor(taskletList, dataService, updatableBasicInfos));
            threads[j].start();
            j++;
          }
        }

        for (int k = 0; k < threads.length; k++) {
          try {
            threads[k].join();
          } catch (InterruptedException e) {
            LOGGER.error(e);
          }
        }

      }

      /*** Load data to solar */
      populateSolRData();
    } catch (Exception e) {
     
      LOGGER.error(e);
    }

    LOGGER.info("DataManagementTasklet run method completed ");

  }

  /**
   * method to populate data to SOLR
   */
  private void populateSolRData() {

    deltaImportSolr(Constants.SOLRDATASOURCEURL);
    deltaImportSolr(Constants.SOLRCUSTOMERURL);

  }

  /**
   * @param urlString
   * @throws SolrServerException
   * @throws IOException
   */
  private void deltaImportSolr(String urlString) {
    try {
      SolrClient solr = new HttpSolrClient.Builder(urlString).build();
      ModifiableSolrParams params = new ModifiableSolrParams();
      params.set("qt", "/dataimport");
      params.set("command", "delta-import");
      solr.query(params);

    } catch (SolrServerException e) {
      LOGGER.error(e);
    } catch (IOException e) {
      LOGGER.error(e);
    }

  }

  /**
   * @return the dataSourcePriorityMap
   */
  public Map<Integer, List<TaskLetDomain>> getDataSourcePriorityMap() {
    return dataSourcePriorityMap;
  }

  /**
   * @param dataSourcePriorityMap
   *            the dataSourcePriorityMap to set
   */
  public void setDataSourcePriorityMap(Map<Integer, List<TaskLetDomain>> dataSourcePriorityMap) {
    this.dataSourcePriorityMap = dataSourcePriorityMap;
  }

  /**
   * Method to load basic info based on data avilability
   * @param taskPriority
   */
  private void prepareSchedulerTaskOnDataPriority(Map<Integer, List<TaskLetDomain>> taskPriority) {
    this.updatableBasicInfos = new HashMap<Long, List>();

    List<DataSourceVO> dataSourceList = dataService.getAllDataSourceVo();
    List<CustomersVO> customers = null;
    List<CustomersVO> noRequestCustomers = null;
    long dataSourcerequestCount = 0L;
    List basicVOs = null;
    int maxPriorityDataSourceWise = 0;
    int minPriority = 0;
    Long maxrequestperDay = 0L;
    List<TaskLetDomain> talskLetDomainList = null;

    if (isDatasourceListNotEmpty(dataSourceList)) {
      maxPriorityDataSourceWise = dataSourceList.size();
      for (DataSourceVO dataSourceVo : dataSourceList) {
        talskLetDomainList = new ArrayList<TaskLetDomain>();
        customers = dataService.getAllCustomerBySourceId(dataSourceVo.getSourceId());
        dataSourcerequestCount = dataService.getDataSourceRequestCount(dataSourceVo.getSourceId());
        if (isCustomerListNotEmpty(customers)) {

          noRequestCustomers = dataService.getNoRequestCustomers(dataSourceVo.getSourceId());
          maxrequestperDay = getMaxRequestPerDay(customers, noRequestCustomers, dataSourcerequestCount,
            dataSourceVo);
          if (Constants.CONSUMER_TYPE.equalsIgnoreCase(dataSourceVo.getDatasourceType())) {
            basicVOs = dataService.getBasicInfoList(dataSourceVo.getSourceId(), maxrequestperDay, 0L);
          } else {
            basicVOs = dataService.getCommercialInfoList(dataSourceVo.getSourceId(), maxrequestperDay, 0L);
          }
          prepareDataSourceRequestObject(noRequestCustomers, dataSourcerequestCount, basicVOs, maxrequestperDay, talskLetDomainList, dataSourceVo);
          prepareCustomerRequestObjects(customers, noRequestCustomers, basicVOs, maxrequestperDay, talskLetDomainList, dataSourceVo);

        } else {
          if (Constants.CONSUMER_TYPE.equalsIgnoreCase(dataSourceVo.getDatasourceType())) {
            basicVOs = dataService.getBasicInfoList(dataSourceVo.getSourceId(),
              dataSourceVo.getMaxRequestPerDay(), 0L);
          } else {
            basicVOs = dataService.getCommercialInfoList(dataSourceVo.getSourceId(),
              dataSourceVo.getMaxRequestPerDay(), 0L);
          }
          prepareRequestObjectForDataSource(basicVOs, dataSourceVo.getMaxRequestPerDay(),
            talskLetDomainList, dataSourceVo);
        }
        if (null != talskLetDomainList && !talskLetDomainList.isEmpty()) {
          if (!isRequestAvailable(noRequestCustomers, dataSourcerequestCount)) {
            taskPriority.put(maxPriorityDataSourceWise, talskLetDomainList);
            maxPriorityDataSourceWise--;
          } else {
            minPriority++;
            taskPriority.put(minPriority, talskLetDomainList);
          }
        }
        if (!isBasicInfoEmpty(basicVOs)) {
          updatableBasicInfos.put(dataSourceVo.getSourceId(), basicVOs);
        }

      }
    }

  }

  /**
   * method to prepare  request object for data source based on request count for the data source and  its customers
   * @param noRequestCustomers
   * @param dataSourcerequestCount
   * @param basicInfos
   * @param maxrequestperDay
   * @param talskLetDomainList
   * @param dataSourceVo
   */
  private void prepareDataSourceRequestObject(List<CustomersVO> noRequestCustomers, long dataSourcerequestCount, List basicInfos, Long maxrequestperDay,
    List<TaskLetDomain> talskLetDomainList, DataSourceVO dataSourceVo) {
    if (dataSourcerequestCount == 0 || (isRequestAvailable(noRequestCustomers, dataSourcerequestCount))) {
      prepareRequestObjectForDataSource(basicInfos, maxrequestperDay, talskLetDomainList,
        dataSourceVo);
    }
  }

  /**
   *  method to prepare  request object for data source based on request count for the   customers
   * @param customers
   * @param noRequestCustomers
   * @param basicInfos
   * @param maxrequestperDay
   * @param talskLetDomainList
   * @param dataSourceVo
   * @return
   */
  private void prepareCustomerRequestObjects(List<CustomersVO> customers, List<CustomersVO> noRequestCustomers, List basicInfos, Long maxrequestperDay,
    List<TaskLetDomain> talskLetDomainList, DataSourceVO dataSourceVo) {
    if (isCustomerListNotEmpty(noRequestCustomers)) {

      getUsedBasicInfo(basicInfos, maxrequestperDay, dataSourceVo);
      prepareRequestSchemaForCustomers(noRequestCustomers, basicInfos, maxrequestperDay,
        talskLetDomainList, dataSourceVo);
    } else {
      prepareRequestSchemaForCustomers(customers, basicInfos, maxrequestperDay, talskLetDomainList,
        dataSourceVo);
    }

  }

  /**
   * Method to get used basic info if unused basic info does not exist for newly added customers
   * @param basicInfos 
   * @param maxrequestperDay
   * @param dataSourceVo
   * @return
   */
  private void getUsedBasicInfo(List basicInfos, Long maxrequestperDay, DataSourceVO dataSourceVo) {

    if (isBasicInfoEmpty(basicInfos)) {
      /** get basic info with used status */
      if (Constants.COMMERCIAL_TYPE.equalsIgnoreCase(dataSourceVo.getDatasourceType())) {
        basicInfos.addAll(dataService.getCommercialInfoList(dataSourceVo.getSourceId(), maxrequestperDay, 1L));
      } else {
        basicInfos.addAll(dataService.getBasicInfoList(dataSourceVo.getSourceId(), maxrequestperDay, 1L));
      }
    }

  }

  /**
   * method to check whether data source and customers under the data source having request
   * @param noRequestCustomers
   * @param dataSourcerequestCount
   * @return
   */
  private boolean isRequestAvailable(List<CustomersVO> noRequestCustomers, long dataSourcerequestCount) {
    return dataSourcerequestCount != 0 && !isCustomerListNotEmpty(noRequestCustomers);
  }

  /**
   * method to check data source list is not empty
   * @param dataSourceList
   * @return
   */
  private boolean isDatasourceListNotEmpty(List<DataSourceVO> dataSourceList) {
    return null != dataSourceList && !dataSourceList.isEmpty();
  }

  /**
   * Method to check basic info is empty
   * @param basicInfos
   * @return
   */
  private boolean isBasicInfoEmpty(List basicInfos) {
    return null == basicInfos || (null != basicInfos && basicInfos.isEmpty());
  }

  /**
   * @param customers
   * @return
   */
  private boolean isCustomerListNotEmpty(List<CustomersVO> customers) {
    return null == customers || (null != customers && !customers.isEmpty());
  }

  /**
   * Method to prepare business object for customers 
   * @param noRequestCustomers
   * @param basicInfos
   * @param maxrequestperDay
   * @param talskLetDomainList
   * @param dataSourceVo
   */
  private void prepareRequestSchemaForCustomers(List<CustomersVO> noRequestCustomers, List basicInfos,
    Long maxrequestperDay, List<TaskLetDomain> talskLetDomainList, DataSourceVO dataSourceVo) {
    for (CustomersVO customer : noRequestCustomers) {
      setCustomerDetails(customer, dataSourceVo);
      prepareRequestForCustomers(basicInfos, maxrequestperDay, talskLetDomainList, customer);
    }
  }

  /**
   * Method to get maximum request per day 
   * @param customers
   * @param noRequestCustomers
   * @param dataSourcerequestCount
   * @param dataSourceVo
   * @return
   */
  private Long getMaxRequestPerDay(List<CustomersVO> customers, List<CustomersVO> noRequestCustomers,
    long dataSourcerequestCount, DataSourceVO dataSourceVo) {
    Long maxrequestperDay;

    if (null != noRequestCustomers && !noRequestCustomers.isEmpty()) {
      maxrequestperDay = dataSourceVo.getMaxRequestPerDay()
        / (noRequestCustomers.size() + (dataSourcerequestCount == 0 ? 1 : 0));
    } else {
      maxrequestperDay = dataSourceVo.getMaxRequestPerDay() / (customers.size() + 1);
    }
    return maxrequestperDay;
  }

  /**
   * method to get URL,user name and password from data source,if that is not available at customer side 
   * @param customer
   * @param dataSourceVo
   */
  private void setCustomerDetails(CustomersVO customer, DataSourceVO dataSourceVo) {
    if (StringUtils.isEmpty(customer.getUrl())) {
      customer.setUrl(dataSourceVo.getUrl());
    }
    if (StringUtils.isEmpty(customer.getUsername())) {
      customer.setUsername(dataSourceVo.getUsername());
    }
    if (StringUtils.isEmpty(customer.getPassword())) {
      customer.setPassword(dataSourceVo.getPassword());
    }

  }

  /**
   * Method to prepare  request object for customers 
   * @param basicInfos
   * @param maxrequestperDay
   * @param talskLetDomainList
   * @param customer
   */
  private void prepareRequestForCustomers(List basicInfos, Long maxrequestperDay,
    List<TaskLetDomain> talskLetDomainList, CustomersVO customer) {
    List<Object> requestObject = new ArrayList<Object>();
    try {

      if (null != customer.getUrl()) {
        if (null != basicInfos && basicInfos.isEmpty()) {
          requestObject.addAll(getProcessedRequestDataForCustomer(customer, maxrequestperDay));
        } else if (basicInfos.size() == maxrequestperDay) {
          requestObject = prepareRequestObject(basicInfos, customer, 1);
        } else {
          requestObject = prepareRequestObject(basicInfos, customer, 1);
          requestObject
            .addAll(getProcessedRequestDataForCustomer(customer, maxrequestperDay - basicInfos.size()));
        }

        if (!requestObject.isEmpty()) {
          talskLetDomainList.add(new TaskLetDomain(maxrequestperDay, customer, requestObject));

        }
      }
    } catch (Exception e) {
      LOGGER.error(e);
    }
  }

  /**
   * Method to get already used request objects,in case if not meeting daily limit with  new data 
   * @param customer
   * @param maxrequestperDay
   * @return
   */
  private List<CustomerRequestDataVO> getProcessedRequestDataForCustomer(CustomersVO customer,
    Long maxrequestperDay) {
    return dataService.getCustomerRequestDataByCustomerId(customer, maxrequestperDay);
  }

  /**
   * Prepare request object fro data source
   * @param basicInfos
   * @param maxrequestperDay
   * @param talskLetDomainList
   * @param dataSource
   * @return
   */
  private void prepareRequestObjectForDataSource(List basicInfos, Long maxrequestperDay,
    List<TaskLetDomain> talskLetDomainList, DataSourceVO dataSource) {
    List<Object> requestObject = new ArrayList<Object>();

    if (null != dataSource.getUrl()) {
      if (null != basicInfos && basicInfos.isEmpty()) {
        requestObject.addAll(getProcessedRequestData(dataSource, maxrequestperDay));
      } else if (basicInfos.size() == maxrequestperDay) {
        requestObject.addAll(prepareRequestObject(basicInfos, dataSource, 0));
      } else {
        requestObject.addAll(prepareRequestObject(basicInfos, dataSource, 0));
        requestObject.addAll(getProcessedRequestData(dataSource, maxrequestperDay - basicInfos.size()));
      }
      if (!requestObject.isEmpty()) {
        talskLetDomainList.add(new TaskLetDomain(maxrequestperDay, dataSource, requestObject));

      }
    }

  }

  /**
   * Method to get already used request objects,in case if not meeting daily limit with  new data for data source
   * @param dataSource
   * @param maxrequestperDay
   * @return
   */
  private List<DataSourceRequestDataVO> getProcessedRequestData(DataSourceVO dataSource, Long maxrequestperDay) {
    return dataService.getRequestDataBySourceId(dataSource, maxrequestperDay);
  }

  /**
   * method to get request format from data source or customer object
   * @param requestData
   * @return
   */
  private static String getFormat(Object requestData) {
    String format = null;
    if (requestData instanceof DataSourceVO) {
      DataSourceVO dataSourceVO = (DataSourceVO) requestData;
      format = dataSourceVO.getFormat();
    } else if (requestData instanceof CustomersVO) {
      CustomersVO customersVO = (CustomersVO) requestData;
      format = customersVO.getFormat();
    }
    return format;
  }

  /**
   * Method to prepare  request object status 0 for datasorce request and 1 for  customer request
   * @param basicInfos
    * @param requestSchema
   * @param status
   * @return
   */
  private List<Object> prepareRequestObject(List basicInfos, Object object,
    int status) {
    List<Object> requestObject = new ArrayList<Object>();
    String requestString = null;
    if (null != getRequestData(object)) {
      for (Object info : basicInfos) {
        if (info instanceof BasicInfoVO) {
          BasicInfoVO basicInfo = (BasicInfoVO) info;
          if (getFormat(object).equals(Constants.FFF)) {
            requestString = getRequestFFF(basicInfo, getRequestData(object));
          } else {
            requestString = getRequestData(basicInfo, getRequestData(object));
          }
        } else if (info instanceof CommercialInfoVO) {
          CommercialInfoVO commercialInfoVO = (CommercialInfoVO) info;
          requestString = createCommercialRequest(commercialInfoVO, getRequestData(object));
        }
        if (status == 0) {

          requestObject.add(new DataSourceRequestDataVO(requestString));

        } else {

          requestObject.add(new CustomerRequestDataVO(requestString));

        }
      }
    }

    return requestObject;
  }

  /**
   * Method to prepare request string
   * @param basicInfo
   * @param requestString
   * @return
   */
  private String getRequestData(BasicInfoVO basicInfo, String requestString) {
    String formatedRequestString = null;
    formatedRequestString = requestString.replace(Constants.SSN, getValue(basicInfo.getSocialSecurityNumber()))
      .replace(Constants.FIRSTNAME, getValue(basicInfo.getFirstName()))
      .replace(Constants.MIDDLENAME, getValue(basicInfo.getMiddleName()))
      .replace(Constants.LASTNAME, getValue(basicInfo.getLastName()))
      .replace(Constants.HOUSENUMBER, getValue(basicInfo.getHouseNumber()))
      .replace(Constants.STREETNAME, getValue(basicInfo.getStreetName()))
      .replace(Constants.STREETTYPE, getValue(basicInfo.getStreetType()))
      .replace(Constants.CITY, getValue(basicInfo.getCity()))
      .replace(Constants.STATE, getValue(basicInfo.getState()))
      .replace(Constants.ZIP, getValue(basicInfo.getZip()));
    return formatedRequestString;
  }

  /**
   * Method to prepare request string
   * @param basicInfo
   * @param requestString
   * @return
   */
  private String createCommercialRequest(CommercialInfoVO commercialInfoVO, String requestString) {
    String formatedRequestString = null;
    formatedRequestString = requestString.replace(Constants.BUSINESS_NAME, getValue(commercialInfoVO.getBusinessName()))
      .replace(Constants.TAX_ID, getValue(commercialInfoVO.getTaxId()))
      .replace(Constants.ADDRESS_LINE, getValue(commercialInfoVO.getAddressLine()))
      .replace(Constants.STREETNAME, getValue(commercialInfoVO.getStreetName()))
      .replace(Constants.STREETTYPE, getValue(commercialInfoVO.getStreetType()))
      .replace(Constants.CITY, getValue(commercialInfoVO.getCity()))
      .replace(Constants.STATE_PROVINCE, getValue(commercialInfoVO.getState()))
      .replace(Constants.ZIP, getValue(commercialInfoVO.getZip()));
    return formatedRequestString;
  }

  private String getRequestFFF(BasicInfoVO basicInfo, String requestString) {
    ObjectMapper mapper = new ObjectMapper();

    String formattedRequest = getRequestData(basicInfo, requestString);

    Map<String, String> map = new HashMap<String, String>();
    try {
      map = mapper.readValue(formattedRequest, new TypeReference<Map<String, String>>() {

      });
    } catch (IOException e) {
      LOGGER.error("Exception occured while reading the value from mapper.", e);
      return "";
    }

    formattedRequest = formattedRequest.replaceAll("\",", "\"").replaceAll("\"", "").replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("\\{", "").replaceAll("\\}", "")
      .replace("\\s+", "");
    List<String> lines = Arrays.asList(formattedRequest.split("\n"));
    String fffString = StringUtils.rightPad("", Constants.FORHUNDREDANDEIGHT);
    for (String line : lines) {
      String key = line.split(":")[0];
      if (key.trim().isEmpty()) {
        continue;
      }
      String value = line.split(":")[1].trim();
      if (!value.trim().isEmpty() && value.matches("^[0-9,]*$")) {
        int startIndex = Integer.parseInt(value.split(",")[0]);
        int endIndex = Integer.parseInt(value.split(",")[1].trim());
        int length = endIndex - startIndex;
        if (key.trim().equals(Constants.FILLER)) {
          key = "";
        }
        key = StringUtils.rightPad(key, length);
        fffString = insertString(fffString, key, startIndex);
      }
    }
    return fffString;
  }

  private static String insertString(String main, String insert, int index) {

    int endIndex = index + insert.length();
    String subString1 = main.substring(0, index);
    String subString2 = main.substring(endIndex);
    return subString1 + insert + subString2;
  }

  /**
   * Method to get empty if the string value is null
   * @param value
   * @return
   */
  private String getValue(String value) {
    return StringUtils.trimToEmpty(value);
  }

  /**
   * Method to get the request data and update the user details if the data format is XML
   * @param requestData
   * @return
   */
  private String getRequestData(Object requestData) {
    String request = null;
    try {
      if (requestData instanceof DataSourceVO) {
        DataSourceVO dataSourceVO = (DataSourceVO) requestData;
        request = dataSourceVO.getRequestSchema();
        if (StringUtils.isNotEmpty(request) && dataSourceVO.getFormat().equalsIgnoreCase(Constants.XML)) {
          request = request.replace(Constants.USERID, dataSourceVO.getUsername())
            .replace(Constants.PASSWORD, dataSourceVO.getPassword());
          request = updtHeaderValuesForXmlReqDS(request, dataSourceVO);
        }

      } else {
        CustomersVO customersVO = (CustomersVO) requestData;
        request = customersVO.getRequestSchema();
        if (StringUtils.isNotEmpty(request) && customersVO.getFormat().equalsIgnoreCase(Constants.XML)) {
          request = request.replace(Constants.USERID, customersVO.getUsername())
            .replace(Constants.PASSWORD, customersVO.getPassword());
          request = updtHeaderValuesForXmlReqCust(request, customersVO);
        }

      }
    } catch (Exception e) {
      LOGGER.error(e);
    }
    return request;
  }

  /**
   * Method to update header values for xml response for customer object
   * @param request
   * @param customersVO
   * @return
   */
  private String updtHeaderValuesForXmlReqCust(String request, CustomersVO customersVO) {
    String updatedRequest = null;
    if (null != customersVO.getCustomerDetails() && !customersVO.getCustomerDetails().isEmpty()) {
      for (CustomerDetailsVO customerDetailsVO : customersVO.getCustomerDetails()) {
        updatedRequest = request.replace(Constants.DOLLER_SYMBOLS + customerDetailsVO.getHeaderName() + Constants.DOLLER_SYMBOLS,
          customerDetailsVO.getHeaderValue());
      }
    }
    return updatedRequest;
  }

  /**
   * Method to update header values for xml response for data source object
   * @param request
   * @param dataSourceVO
   * @return
   */
  private String updtHeaderValuesForXmlReqDS(String request, DataSourceVO dataSourceVO) {
    String updatedRequest = request;
    if (null != dataSourceVO.getDataSourceDetails() && !dataSourceVO.getDataSourceDetails().isEmpty()) {
      for (DataSourceDetailsVO dataSourceDetailsVO : dataSourceVO.getDataSourceDetails()) {
        updatedRequest = request.replace(Constants.DOLLER_SYMBOLS + dataSourceDetailsVO.getHeaderName() + Constants.DOLLER_SYMBOLS,
          dataSourceDetailsVO.getHeaderValue());
      }
    }
    return updatedRequest;
  }

}
