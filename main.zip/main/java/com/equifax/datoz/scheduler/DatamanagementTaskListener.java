package com.equifax.datoz.scheduler;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.equifax.datoz.service.IDataManagementService;

public class DatamanagementTaskListener implements ServletContextListener, ApplicationContextInitializer<ConfigurableApplicationContext> {
  DatamanagementScheduledExecutorService datamanagementScheduledExecutorService;
  private static final Logger LOGGER = Logger.getLogger(DatamanagementTaskListener.class);

  @Override
  public void contextDestroyed(ServletContextEvent arg0) {
    LOGGER.info("Destroyed DatamanagementTaskListener class ");
  }

  @Override
  public void contextInitialized(ServletContextEvent event) {
    ApplicationContext appCtx = WebApplicationContextUtils.getWebApplicationContext(event.getServletContext());
    IDataManagementService dataService = (IDataManagementService) appCtx.getBean("dataService");
    datamanagementScheduledExecutorService = (DatamanagementScheduledExecutorService) appCtx.getBean("datamanagementScheduledExecutorService");
    datamanagementScheduledExecutorService.setDataService(dataService);
    datamanagementScheduledExecutorService.executeUpdateThread();

  }

  @Override
  public void initialize(ConfigurableApplicationContext applicationContext) {
    LOGGER.info("Initilized DatamanagementTaskListener class ");
    datamanagementScheduledExecutorService = (DatamanagementScheduledExecutorService) applicationContext.getBean("datamanagementScheduledExecutorService");
  }

}
