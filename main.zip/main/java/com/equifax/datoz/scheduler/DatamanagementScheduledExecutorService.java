package com.equifax.datoz.scheduler;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.equifax.datoz.service.IDataManagementService;

public class DatamanagementScheduledExecutorService {

  static IDataManagementService dataService;
  private static final Logger LOGGER = Logger.getLogger(DatamanagementScheduledExecutorService.class);

  public IDataManagementService getDataService() {
    return dataService;
  }

  public void setDataService(IDataManagementService dataService) {
    DatamanagementScheduledExecutorService.dataService = dataService;
  }

  public void executeUpdateThread() {
    LOGGER.info("DatamanagementScheduledExecutorService -> executeUpdateThread ( ) method invoked ");
    ScheduledExecutorService execService = Executors.newScheduledThreadPool(1);
    DataManagementTasklet dataManagementTasklet = new DataManagementTasklet(dataService);
    execService.scheduleWithFixedDelay(dataManagementTasklet, 0, 5, TimeUnit.HOURS);
  }

}
