package com.equifax.datoz.scheduler;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.entity.BasicInfoVO;
import com.equifax.datoz.entity.CustomerRequestDataVO;
import com.equifax.datoz.entity.CustomerScenarioVO;
import com.equifax.datoz.entity.CustomersVO;
import com.equifax.datoz.entity.DataSourceRequestDataVO;
import com.equifax.datoz.entity.DataSourceScenarioVO;
import com.equifax.datoz.entity.DataSourceVO;
import com.equifax.datoz.entity.TaskLetDomain;
import com.equifax.datoz.handler.RulesHandler;
import com.equifax.datoz.service.IDataManagementService;
import com.equifax.datoz.util.FFFParserUtil;
import com.equifax.datoz.util.JsonParserUtil;
import com.equifax.datoz.util.XmlParserUtil;

public class DataProcessor implements Runnable {

  private static final Logger LOGGER = Logger.getLogger(DataProcessor.class);
  List<TaskLetDomain> taskletList;
  IDataManagementService dataService;
  Map<Long, List> updatableBasicInfos;

  public DataProcessor(List<TaskLetDomain> taskletList, IDataManagementService dataService,
    Map<Long, List> updatableBasicInfos) {
    super();
    this.taskletList = taskletList;
    this.dataService = dataService;
    this.updatableBasicInfos = updatableBasicInfos;
  }

  @Override
  public void run() {
    LOGGER.info("DataProcessor run method started ");
    for (TaskLetDomain taskLetDomain : taskletList) {
      if (null != taskLetDomain.getRequest() && !taskLetDomain.getRequest().isEmpty()) {
        processRequest(taskLetDomain);
        updateRequestToDB(taskLetDomain);
        invokeScenarioResponseMapping(taskLetDomain);

      }

    }
    LOGGER.info("DataProcessor run method completed ");
  }

  /**
   * Method to invoke scenario Response mapping
   * @param taskLetDomain
   */
  private void invokeScenarioResponseMapping(TaskLetDomain taskLetDomain) {
    try {
      if (taskLetDomain.isScenarioMappingRequired()) {
        mapResponsesWithScenario(taskLetDomain);
      }
    } catch (Exception e) {
      LOGGER.error(e);
    }
  }

  /**
   * Method to process and send the request to the corresponding web services
   * 
   * @param taskLetDomain
   */
  public void processRequest(TaskLetDomain taskLetDomain) {

    if (isDataSourceObject(taskLetDomain)) {

      for (Object dataSourceRequest : taskLetDomain.getRequest()) {
        DataSourceRequestDataVO request = (DataSourceRequestDataVO) dataSourceRequest;
        String status = getDataSourceObject(taskLetDomain).getSslDetails();
        if (status == "skipHostNameValidation:false") {
          request.setResponseData(sendRequest(taskLetDomain, request.getRequestDataValue()));
        } else {
          request.setResponseData(sendRequestWithoutSsl(taskLetDomain, request.getRequestDataValue()));
        }
        if (null == request.getRequestId()) {
          request.setCreatedDate(new Date());
        }
        request.setUpdatedDate(new Date());
        request.setSourceId(getDataSourceObject(taskLetDomain).getSourceId());
        if (null != request.getResponseData()
          && isValidXmlResponse(request.getResponseData(), taskLetDomain.getFormat())) {
          taskLetDomain.setScenarioMappingRequired(Boolean.TRUE);
          setDataSourceRequestStatus(request, 1L);
        } else {
          setDataSourceRequestStatus(request, 0L);
        }

      }
    } else {

      for (Object customerRequest : taskLetDomain.getRequest()) {
        CustomerRequestDataVO request = (CustomerRequestDataVO) customerRequest;
        String status = getCustomerObject(taskLetDomain).getSslDetails();
        if (status == "skipHostNameValidation:false") {
          request.setResponseData(sendRequest(taskLetDomain, request.getRequestDataValue()));
        } else {
          request.setResponseData(sendRequestWithoutSsl(taskLetDomain, request.getRequestDataValue()));
        }
        if (null == request.getRequestId()) {
          request.setCreatedDate(new Date());
        }
        request.setUpdatedDate(new Date());
        request.setCustomerId(getCustomerObject(taskLetDomain).getCustomerid());
        if (null != request.getResponseData()
          && isValidXmlResponse(request.getResponseData(), taskLetDomain.getFormat())) {
          taskLetDomain.setScenarioMappingRequired(Boolean.TRUE);
          setCustomerRequestStatus(request, 1L);
        } else {
          setCustomerRequestStatus(request, 0L);
        }

      }
    }

  }

  /**
   * method to check whether the object is data source or customer
   * 
   * @param taskLetDomain
   * @return
   */
  private boolean isDataSourceObject(TaskLetDomain taskLetDomain) {
    return taskLetDomain.getObject() instanceof DataSourceVO;
  }

  /**
   * Method to send request to corresponding data source or customer services
   * 
   * @param taskLetDomain
   * @param restTemplate
   * @param httpHeaders
   * @return
   */
  private String sendRequest(TaskLetDomain taskLetDomain, String requestString) {
    String responseString = null;
    RestTemplate restTemplate = new RestTemplate();
    try {

      HttpEntity httpEntity = new HttpEntity(requestString, taskLetDomain.getHttpHeaders());
      ResponseEntity response = restTemplate.exchange(taskLetDomain.getUrl(), HttpMethod.POST, httpEntity,
        String.class);
      responseString = response.getBody().toString();

    } catch (Exception e) {
      LOGGER.error(e);
    }

    return responseString;
  }

  /**
   * method to send request for https with out certificate
   * @param taskLetDomain
   * @param requestString
   * @return
   */
  private String sendRequestWithoutSsl(TaskLetDomain taskLetDomain, String requestString) {
    String responseString = null;
    SSLContext sslContext = null;
    try {
      sslContext = new SSLContextBuilder()
        .loadTrustMaterial(null, (certificate, authType) -> true).build();
    } catch (KeyManagementException e) {
      LOGGER.error(e);
    } catch (NoSuchAlgorithmException e) {
      LOGGER.error(e);
    } catch (KeyStoreException e) {
      LOGGER.error(e);
    }
    HttpClient httpClient = HttpClients.custom().setSSLContext(sslContext)
      .setSSLHostnameVerifier(new NoopHostnameVerifier())
      .build();
    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
    requestFactory.setHttpClient(httpClient);
    RestTemplate restTemplate = new RestTemplate(requestFactory);

    try {
      LOGGER.info("DataProcessor -> sendRequest() method invoked    ");
      HttpEntity httpEntity = new HttpEntity(requestString, taskLetDomain.getHttpHeaders());
      ResponseEntity response = restTemplate.exchange(
        taskLetDomain.getUrl(), HttpMethod.POST, httpEntity,
        String.class);

      responseString = response.getBody().toString();
      LOGGER.info("DataProcessor -> sendRequest() method response recieved     ");
    } catch (Exception e) {
      LOGGER.error(e);
    }

    return responseString;
  }

  /**
   * Method to check the request format
   * 
   * @param responseData
   * @param format
   * @return
   */
  private boolean isValidXmlResponse(String responseData, String format) {
    boolean status = Boolean.TRUE;
    if (format.equalsIgnoreCase(Constants.XML) && responseData.contains(Constants.ERRORTAG)) {
      status = Boolean.FALSE;
    }

    return status;
  }

  /**
   * Method to set the request object status based response validity
   * 
   * @param request
   * @param status
   */
  private void setDataSourceRequestStatus(DataSourceRequestDataVO request, long status) {
    request.setReqSendStatus(status);
    request.setStatus(status);
    request.setResUpdatedDate(new Date());
  }

  /**
   * Method to get data source object
   * 
   * @param taskLetDomain
   * @return
   */
  private DataSourceVO getDataSourceObject(TaskLetDomain taskLetDomain) {
    return (DataSourceVO) taskLetDomain.getObject();
  }

  /**
   * method to get customer object
   * 
   * @param taskLetDomain
   * @return
   */
  private CustomersVO getCustomerObject(TaskLetDomain taskLetDomain) {
    return (CustomersVO) taskLetDomain.getObject();
  }

  /**
   * Method to set the request status of customer object
   * 
   * @param request
   * @param status
   */
  private void setCustomerRequestStatus(CustomerRequestDataVO request, long status) {
    request.setReqSendStatus(status);
    request.setStatus(status);
    request.setResUpdatedDate(new Date());
  }

  /**
   * Method to update request to DB and basic info used status
   * 
   * @param taskLetDomain
   */
  private void updateRequestToDB(TaskLetDomain taskLetDomain) {

    removeUnwantedRequestObject(taskLetDomain.getRequest());
    if (isDataSourceObject(taskLetDomain)) {

      dataService.insertDataSourceRequest(taskLetDomain.getRequest(), getUpdatableBasicInfoList(taskLetDomain));

    } else {
      dataService.insertCustomerRequest(taskLetDomain.getRequest(), getUpdatableBasicInfoList(taskLetDomain));

    }

  }

  /**
   * Method to remove already existing request from DB without any response in
   * current transaction
   * 
   * @param request
   */
  private void removeUnwantedRequestObject(List<Object> request) {
    List<Object> objectsToRemove = new ArrayList<Object>();

    for (Object object : request) {
      if (object instanceof DataSourceRequestDataVO) {
        DataSourceRequestDataVO requestObject = (DataSourceRequestDataVO) object;
        if (null != requestObject.getRequestId() && null == requestObject.getResponseData()) {
          objectsToRemove.add(requestObject);
        }
      } else {
        CustomerRequestDataVO requestObject = (CustomerRequestDataVO) object;
        if (null != requestObject.getRequestId() && null == requestObject.getResponseData()) {
          objectsToRemove.add(requestObject);
        }
      }
    }
    if (!objectsToRemove.isEmpty()) {
      request.removeAll(objectsToRemove);
    }

  }

  /**
   * method get basicinfo list for updating status  to DB
   * @param taskLetDomain
   * @return
   */
  private List<BasicInfoVO> getUpdatableBasicInfoList(TaskLetDomain taskLetDomain) {
    List<BasicInfoVO> basicInfosList = null;
    if (isDataSourceObject(taskLetDomain)) {
      if (updatableBasicInfos.containsKey(getDataSourceObject(taskLetDomain).getSourceId())) {
        basicInfosList = updatableBasicInfos.get(getDataSourceObject(taskLetDomain).getSourceId());
      }
    } else {
      if (updatableBasicInfos.containsKey(getCustomerObject(taskLetDomain).getDataSourceVO().getSourceId())) {
        basicInfosList = updatableBasicInfos
          .get(getCustomerObject(taskLetDomain).getDataSourceVO().getSourceId());
      }
    }

    return basicInfosList;
  }

  /**
   * Method map response with vaialable scenarios
   * 
   * @param taskLetDomain
   */
  private void mapResponsesWithScenario(TaskLetDomain taskLetDomain) {
    List<DataSourceScenarioVO> dataSourceSenariosList = null;
    List<CustomerScenarioVO> customerSenariosList = null;

    if (isDataSourceObject(taskLetDomain)) {

      dataSourceSenariosList = dataService.getAllScenarioVo(getDataSourceObject(taskLetDomain).getSourceId());

      updateDataSourceScenarioResponseMapping(dataSourceSenariosList, taskLetDomain.getRequest(), taskLetDomain.getFormat(),
        getDataSourceObject(taskLetDomain).getResponseSchema());
    } else {

      customerSenariosList = dataService.getCustomerScenario(getCustomerObject(taskLetDomain).getCustomerid());

      updateCustomerScenarioResponseMapping(customerSenariosList, taskLetDomain.getRequest(), taskLetDomain.getFormat(), getCustomerObject(taskLetDomain).getResponseSchema());
    }

  }

  /**
   * method to check and update scenario response mapping *
   * 
   * @param dataSourceSenariosList
   * @param requestDataList
   * @param response
   * @param string
   */
  private void updateDataSourceScenarioResponseMapping(List<DataSourceScenarioVO> dataSourceSenariosList,
    List<Object> requestDataList, String dataFormat, String responseSchema) {
    Boolean updateStatus = Boolean.FALSE;

    try {

      if (null != dataSourceSenariosList && !dataSourceSenariosList.isEmpty()) {
        for (DataSourceScenarioVO scenario : dataSourceSenariosList) {
          updateStatus = isScenarioMappingWithResponse(requestDataList, dataFormat, scenario, responseSchema);
        }

      }

    } catch (Exception e) {
      LOGGER.error(e);
    }

  }

  /**
   * Method to check the scenario is mapping with response
   * 
   * @param requestDataList
   * @param dataFormat
   * @param updateStatus
   * @param rulesHandler
   * @param scenario
   * @return
   */
  private Boolean isScenarioMappingWithResponse(List<Object> requestDataList, String dataFormat, Object scenario, String responseSchema) {
    Boolean updateStatus = Boolean.FALSE;

    List<String> rulesList;
    for (Object requestData : requestDataList) {
      if (null != getResponseData(requestData)) {
        rulesList = getRulesList(scenario);
        for (String scenarioJson : rulesList) {
          updateStatus = checkScenarioMappingWithResponse(dataFormat, scenario, requestData, scenarioJson, responseSchema);
        }

      }

    }

    return updateStatus;
  }

  /**
   * Method to get response data from object
   * 
   * @param requestObject
   */
  private String getResponseData(Object requestObject) {
    String response = null;
    if (requestObject instanceof DataSourceRequestDataVO) {
      DataSourceRequestDataVO datasourceRequestData = (DataSourceRequestDataVO) requestObject;
      response = datasourceRequestData.getResponseData();
    } else {
      CustomerRequestDataVO customerRequestData = (CustomerRequestDataVO) requestObject;
      response = customerRequestData.getResponseData();
    }
    return response;
  }

  /**
   * Method to split the rules from scenario json
   * 
   * @param rulesHandler
   * @param datasourceScenario
   * @return
   */
  private List<String> getRulesList(Object scenario) {
    RulesHandler rulesHandler = new RulesHandler();
    DataSourceScenarioVO datasourceScenario = null;
    String scenarioData = null;
    CustomerScenarioVO customerScenario = null;

    if (scenario instanceof DataSourceScenarioVO) {
      datasourceScenario = (DataSourceScenarioVO) scenario;
      scenarioData = datasourceScenario.getScenarioData();
    } else {
      customerScenario = (CustomerScenarioVO) scenario;
      scenarioData = customerScenario.getScenarioData();
    }

    return rulesHandler.divideRule(scenarioData);
  }

  /**
   * Method to check the scenario mapping with response
   * 
   * @param dataFormat
   * @param scenario
   * @param requestData
   * @param scenarioJson
   * @return
   */
  private Boolean checkScenarioMappingWithResponse(String dataFormat, Object scenario, Object requestData,
    String scenarioJson, String responseSchema) {
    Boolean updateStatus = Boolean.FALSE;

    if (dataFormat.equalsIgnoreCase(Constants.JSON)
      && JsonParserUtil.isScenarioMappingWithResponse(scenarioJson, getResponseData(requestData))) {

      setRequestObject(scenario, requestData);
      updateStatus = Boolean.TRUE;
    } else if (dataFormat.equalsIgnoreCase(Constants.XML)
      && XmlParserUtil.isScenarioMappingWithResponse(scenarioJson, getResponseData(requestData))) {
      setRequestObject(scenario, requestData);
      updateStatus = Boolean.TRUE;
    } else if (dataFormat.equalsIgnoreCase(Constants.FFF) 
      && FFFParserUtil.isScenarioMappingWithResponse(scenarioJson, getResponseData(requestData), responseSchema)) {
      setRequestObject(scenario, requestData);
      updateStatus = Boolean.TRUE;

    }

    return updateStatus;
  }

  /**
   * Method to update the scenario with the response
   * 
   * @param scenario
   * @param requestData
   */
  private void setRequestObject(Object scenario, Object requestData) {

    DataSourceScenarioVO datasourceScenario = null;

    CustomerScenarioVO customerScenario = null;
    if (scenario instanceof DataSourceScenarioVO) {
      datasourceScenario = (DataSourceScenarioVO) scenario;
      DataSourceRequestDataVO datasourceRequestData = (DataSourceRequestDataVO) requestData;
      dataService.insertDataSourceSenarioResponseMapping(datasourceScenario.getScenarioId(),
        datasourceRequestData.getRequestId());

    } else {
      customerScenario = (CustomerScenarioVO) scenario;
      CustomerRequestDataVO customerRequestData = (CustomerRequestDataVO) requestData;
      dataService.insertCustomerSenarioResponseMapping(customerScenario.getScenarioId(),
        customerRequestData.getRequestId());

    }

  }

  /**
   * method to check and update the scenario with response
   * 
   * @param customerSenariosList
   * @param requestDataList
   * @param dataFormat
   */
  private void updateCustomerScenarioResponseMapping(List<CustomerScenarioVO> customerSenariosList,
    List<Object> requestDataList, String dataFormat, String responseSchema) {
    Boolean updateStatus = Boolean.FALSE;

    try {

      if (null != customerSenariosList && !customerSenariosList.isEmpty()) {
        for (CustomerScenarioVO scenario : customerSenariosList) {
          updateStatus = isScenarioMappingWithResponse(requestDataList, dataFormat, scenario, responseSchema);
        }

      }

    } catch (Exception e) {
      LOGGER.error(e);
    }

  }

}
