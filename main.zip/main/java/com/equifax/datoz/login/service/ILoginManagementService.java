package com.equifax.datoz.login.service;

import org.springframework.stereotype.Component;

import com.equifax.datoz.domain.UserDetails;

@Component
public interface ILoginManagementService {

  void saveUser(final UserDetails userDetails);

  Long existingUserCountWithSameName(final String userName);

  Long getUserId(String username);

  String getNameWithUserId(Long userId);
}
