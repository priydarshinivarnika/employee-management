package com.equifax.datoz.login.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.datoz.domain.UserDetails;
import com.equifax.datoz.entity.UserDetailsVO;
import com.equifax.datoz.login.dao.ILoginManagementDao;
import com.equifax.datoz.login.service.ILoginManagementService;

@Transactional(readOnly = false)
@Component
public class LoginManagementService implements ILoginManagementService {

    @Autowired
    public ILoginManagementDao loginManagementDAO;

    private ModelMapper modelMapper = new ModelMapper();

    /**
     * to save new user
     */
    
    @Override
    public void saveUser(UserDetails userDetails) {

        UserDetailsVO userDetailsVO = modelMapper.map(userDetails, UserDetailsVO.class);
        loginManagementDAO.saveUser(userDetailsVO);

    }
    
    /**
     * to get count of users with same name
     */

    @Override
    public Long existingUserCountWithSameName(String userName) {

        return loginManagementDAO.existingUserCountWithSameName(userName);
    }

    /**
     * get user id using username
     */
    @Override
    public Long getUserId(String username) {

        return loginManagementDAO.getUserId(username);
    }

    /**
     * get name with user id
     */
    @Override
    public String getNameWithUserId(Long userId) {

        return loginManagementDAO.getNameWithUserId(userId);

    }

}
