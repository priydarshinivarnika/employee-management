package com.equifax.datoz.login.dao.impl;

import org.hibernate.Session;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

import com.equifax.datoz.entity.UserDetailsVO;
import com.equifax.datoz.login.dao.ILoginManagementDao;

public class LoginManagementDao extends HibernateDaoSupport implements ILoginManagementDao {

    

    /**
     * to save new user
     */ 
    
    
    @Override
    public void saveUser(UserDetailsVO userDetails) {

        getHibernateTemplate().saveOrUpdate(userDetails);

    }
    
    /**
     * to get count of users with same name
     */
    @Override
    public Long existingUserCountWithSameName(String userName) {

        Session session = getSessionFactory().getCurrentSession();

        String query = "select count(*) FROM UserDetailsVO  WHERE userName = '" + userName + "'";
        return (long) session.createQuery(query).uniqueResult();

    }

    
    /**
     * get user id using username
     */
    @Override
    public Long getUserId(String username) {

        Session session = getSessionFactory().getCurrentSession();

        String query = "select userId  FROM UserDetailsVO  WHERE userName = '" + username + "'";
        return (long) session.createQuery(query).uniqueResult();
    }
    /**
     * get name with user id
     */
    @Override
    public String getNameWithUserId(final Long userid) {

        Session session = getSessionFactory().getCurrentSession();

        String query = "select name  FROM UserDetailsVO  WHERE userId =" + userid;
        return (String) session.createQuery(query).uniqueResult();

    }

}
