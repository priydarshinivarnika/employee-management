package com.equifax.datoz.login.dao;

import com.equifax.datoz.entity.UserDetailsVO;

public interface ILoginManagementDao {

  void saveUser(final UserDetailsVO userDetails);

  Long existingUserCountWithSameName(final String userName);

  Long getUserId(String username);

  String getNameWithUserId(Long userId);

}
