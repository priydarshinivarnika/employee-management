package com.equifax.datoz.domain;

import java.io.Serializable;

public class UserRoles  implements Serializable   {

    
    private static final long serialVersionUID = 1L;
    private Long userRoleId;
    private String role;
    private String userName;
    private UserDetails userDetails;
    /**
     * @return the userRoleId
     */
    public Long getUserRoleId() {
        return userRoleId;
    }
    /**
     * @param userRoleId
     *            the userRoleId to set
     */
    public void setUserRoleId(Long userRoleId) {
        this.userRoleId = userRoleId;
    }
    /**
     * @return the role
     */
    public String getRole() {
        return role;
    }
    /**
     * @param role
     *            the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }
    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }
    /**
     * @param userName
     *            the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**
     * @return the userDetails
     */
    public UserDetails getUserDetails() {
        return userDetails;
    }
    /**
     * @param userDetails
     *            the userDetails to set
     */
    public void setUserDetails(UserDetails userDetails) {
        this.userDetails = userDetails;
    }
   
    
}
