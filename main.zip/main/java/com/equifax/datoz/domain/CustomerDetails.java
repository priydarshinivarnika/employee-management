package com.equifax.datoz.domain;

import java.io.Serializable;

public class CustomerDetails implements Serializable {
  
  private static final long serialVersionUID = 1L;
  private Long id;
  private String headerName;
  private String headerValue;
  private Customers customers;
  
  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }
  /**
   * @param id
   *            the id to set
   */
  public void setId(Long id) {
    this.id = id;
  }
  /**
   * @return the headerName
   */
  public String getHeaderName() {
    return headerName;
  }
  /**
   * @param headerName
   *            the headerName to set
   */
  public void setHeaderName(String headerName) {
    this.headerName = headerName;
  }
  /**
   * @return the headerValue
   */
  public String getHeaderValue() {
    return headerValue;
  }
  /**
   * @param headerValue
   *            the headerValue to set
   */
  public void setHeaderValue(String headerValue) {
    this.headerValue = headerValue;
  }
  
  /**
   * @return the customers
   */
  public Customers getCustomers() {
    return customers;
  }
  /**
   * @param customers
   *            the customers to set
   */
  public void setCustomers(Customers customers) {
    this.customers = customers;
  }
  
  
}
