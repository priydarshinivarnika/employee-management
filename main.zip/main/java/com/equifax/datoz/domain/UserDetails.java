package com.equifax.datoz.domain;

import java.io.Serializable;
import java.util.Date;

public class UserDetails implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Long userId;
    private String name;
    private String userName;
    private String password;
    private Long status;
    private Date  expiryDate;
    private Long passwordRetryCount;
    private UserRoles userRoles;
    
    /**
    * @return the userId
    */
    public Long getUserId() {
        return userId;
    }
    /**
    * @param userId
    *            the userId to set
    */
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    /**
    * @return the name
    */
    public String getName() {
        return name;
    }
    /**
    * @param name
    *            the name to set
    */
    public void setName(String name) {
        this.name = name;
    }
    /**
    * @return the userName
    */
    public String getUserName() {
        return userName;
    }
    /**
    * @param userName
    *            the userName to set
    */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**
    * @return the password
    */
    public String getPassword() {
        return password;
    }
    /**
    * @param password
    *            the password to set
    */
    public void setPassword(String password) {
        this.password = password;
    }
    /**
    * @return the status
    */
    public Long getStatus() {
        return status;
    }
    /**
    * @param status
    *            the status to set
    */
    public void setStatus(Long status) {
        this.status = status;
    }
    /**
    * @return the expiryDate
    */
    public Date getExpiryDate() {
        return expiryDate;
    }
    /**
    * @param expiryDate
    *            the expiryDate to set
    */
    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
    /**
    * @return the passwordRetryCount
    */
    public Long getPasswordRetryCount() {
        return passwordRetryCount;
    }
    /**
    * @param passwordRetryCount
    *            the passwordRetryCount to set
    */
    public void setPasswordRetryCount(Long passwordRetryCount) {
        this.passwordRetryCount = passwordRetryCount;
    }
    /**
    * @return the userRoles
    */
    public UserRoles getUserRoles() {
        return userRoles;
    }
    /**
    * @param userRoles
    *            the userRoles to set
    */
    public void setUserRoles(UserRoles userRoles) {
        this.userRoles = userRoles;
    }
    
}
