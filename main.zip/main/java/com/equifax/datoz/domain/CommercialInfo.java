package com.equifax.datoz.domain;

public class CommercialInfo {

    
    Long commercialInfoId;
    String businessName;
    String taxId;
    String houseNumber;
    String addressLine;
    String streetName;
    String streetType;
    String city;
    String state;
    String country;
    String zip;
    Long status;
    DataSource dataSource;
    
    /**
     * 
     * @return commercialInfoId
     */
    public Long getCommercialInfoId() {
        return commercialInfoId;
    }
    
    /**
     * 
     * @param commercialInfoId
     */
    public void setCommercialInfoId(Long commercialInfoId) {
        this.commercialInfoId = commercialInfoId;
    }
    
    /**
     * 
     * @return businessName
     */
    public String getBusinessName() {
        return businessName;
    }
    
    /**
     * 
     * @param businessName
     */
    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }
    
    /**
     * 
     * @return taxId 
     */
    public String getTaxId() {
        return taxId;
    }
    
    /**
     * 
     * @param taxId
     */
    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }
    
    /**
     * 
     * @return houseNumber
     */
    public String getHouseNumber() {
        return houseNumber;
    }
    
    /**
     * 
     * @param houseNumber
     */
    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }
    
    /**
     * 
     * @return addressLine
     */
    public String getAddressLine() {
        return addressLine;
    }
    
    /**
     * 
     * @param addressLine
     */
    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }
    
    /**
     * 
     * @return streetName
     */
    public String getStreetName() {
        return streetName;
    }
    
    /**
     * 
     * @param streetName
     */
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }
    
    /**
     * 
     * @return streetType
     */
    public String getStreetType() {
        return streetType;
    }
    
    /**
     * 
     * @param streetType
     */
    public void setStreetType(String streetType) {
        this.streetType = streetType;
    }
    
    /**
     * 
     * @return city
     */
    public String getCity() {
        return city;
    }
    
    /**
     * 
     * @param city
     */
    public void setCity(String city) {
        this.city = city;
    }
    
    /**
     * 
     * @return state
     */
    public String getState() {
        return state;
    }
    
    /**
     * 
     * @param state
     */
    public void setState(String state) {
        this.state = state;
    }
    
    /**
     * 
     * @return country
     */
    public String getCountry() {
        return country;
    }
    
    /**
     * 
     * @param country
     */
    public void setCountry(String country) {
        this.country = country;
    }
    
    
    /**
     * 
     * @return zip
     */
    public String getZip() {
        return zip;
    }
    
    /**
     * 
     * @param zip
     */
    public void setZip(String zip) {
        this.zip = zip;
    }
    
    /**
     * 
     * @return status
     */
    public Long getStatus() {
        return status;
    }
    
    /**
     * 
     * @param status
     */
    public void setStatus(Long status) {
        this.status = status;
    }
    
    /**
     * 
     * @return dataSource
     */
    public DataSource getDataSource() {
        return dataSource;
    }
    
    /**
     * 
     * @param dataSource
     */
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    
    
    
}
