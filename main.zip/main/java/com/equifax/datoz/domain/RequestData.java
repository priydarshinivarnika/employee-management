package com.equifax.datoz.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import com.equifax.datoz.handler.Model;

public class RequestData implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

 
  private String requestDataValue;

 
  private String responseData;

 
  private Date createdDate;

  
  private Date updatedDate;


  private Date resUpdatedDate;

 
  private Long requestId;
  
 

  private Long status;
  private DataSource dataSource;
  private String model;
  private String resmodel;

  
  private Long reqSendStatus;
  private Model modelObject;
  private Map<String, String> addDetailsModel;

  
  public RequestData() {
      super();
    }   

  /**
   * @return the requestDataValue
   */
  public String getRequestDataValue() {
    return requestDataValue;
  }

  /**
   * @param requestDataValue
   *            the requestDataValue to set
   */
  public void setRequestDataValue(String requestDataValue) {
    this.requestDataValue = requestDataValue;
  }

  /**
   * @return the createdDate
   */
  public Date getCreatedDate() {
    return createdDate;
  }

  /**
   * @param createdDate
   *            the createdDate to set
   */
  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  /**
   * @return the updated_date
   */
  public Date getUpdatedDate() {
    return updatedDate;
  }

  /**
   * @param updatedDate
   *            the updatedDate to set
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * @return the requestId
   */
  public Long getRequestId() {
    return requestId;
  }

  /**
   * @param requestId
   *            the requestId to set
   */
  public void setRequestId(Long requestId) {
    this.requestId = requestId;
  }

  /**
   * @return the status
   */
  public Long getStatus() {
    return status;
  }

  /**
   * @param status
   *            the status to set
   */
  public void setStatus(Long status) {
    this.status = status;
  }

  /**
   * @return the dataSource
   */
  public DataSource getDataSource() {
    return dataSource;
  }

  /**
   * @param dataSource
   *            the dataSource to set
   */
  public void setDataSource(DataSource dataSource) {
    this.dataSource = dataSource;
  }

  /**
   * @return the responseData
   */
  public String getResponseData() {
    return responseData;
  }

  /**
   * @param response_data the response_data to set
   */
  public void setResponseData(String responseData) {
    this.responseData = responseData;
  }

  /**
   * @return the res_updated_date
   */
  public Date getResUpdatedDate() {
    return resUpdatedDate;
  }

  /**
   * @param resUpdatedDate the resUpdatedDate to set
   */
  public void setResUpdatedDate(Date resUpdatedDate) {
    this.resUpdatedDate = resUpdatedDate;
  }

  /**
   * @return the reqSendStatus
   */
 
  public Long getReqSendStatus() {
    return reqSendStatus;
  }
  /**
   * @param reqSendStatus the reqSendStatus to set
   */
  public void setReqSendStatus(Long reqSendStatus) {
    this.reqSendStatus = reqSendStatus;
  }

  /**
   * @return the reqSendStatus
   */
  public String getModel() {

    return model;

  }
  /**
   * @param model the model to set
   */
  public void setModel(String model) {

    this.model = model;

  }
  /**
   * @return the resmodel
   */
  public String getResmodel() {
    return resmodel;
  }
  /**
   * @param resmodel the resmodel to set
   */
  public void setResmodel(String resmodel) {
    this.resmodel = resmodel;
  }
  /**
   * @return the modelObject
   */
  public Model getModelObject() {
    return modelObject;
  }
  /**
   * @param modelObject the modelObject to set
   */
  public void setModelObject(Model modelObject) {
    this.modelObject = modelObject;
  }
  /**
   * @return the addDetailsModel
   */
  public Map<String, String> getAddDetailsModel() {
      return addDetailsModel;
  }
  /**
   * @param addDetailsModel the addDetailsModel to set
   */
  public void setAddDetailsModel(Map<String, String> addDetailsModel) {
      this.addDetailsModel = addDetailsModel;
  }
}
