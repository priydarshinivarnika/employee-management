/**
 * 
 */
package com.equifax.datoz.domain;

import java.io.Serializable;
import java.util.Set;



/**
 * @author pxm198
 *
 */
public class Scenario implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long scenarioId;

    private String scenarioName;
    private String description;
    private Long status;

    private String scenarioData;
    private Set<RequestData> requestDataSet;
    private Long sourceId;
    private String sourceType;
    private String dataSourceName;
    private String customerName;
    private String infoSchema;
    private String format;
    private String responseSchema;

    public Scenario() {
        super();
    }

    /**
     * @param scenarioName
     * @param description
     * @param scenarioData
     * @param id
     * @param sourceType
     */
    public Scenario(String scenarioName, String description, String scenarioData, Long id, String sourceType) {
        super();
        this.scenarioName = scenarioName;
        this.description = description;
        this.scenarioData = scenarioData;
        this.sourceId = id;
        this.sourceType = sourceType;
    }

    /**
     * @param scenarioName
     * @param description
     * @param status
     * @param scenarioData
     * @param id
     * @param sourceType
     */
    public Scenario(String scenarioName, String description, Long status, String scenarioData, Long id, String sourceType) {
        super();
        this.scenarioName = scenarioName;
        this.description = description;
        this.status = status;
        this.scenarioData = scenarioData;
        this.sourceId = id;
        this.sourceType = sourceType;
    }

    /**
     * @param scenarioId
     * @param scenarioName
     * @param description
     * @param status
     * @param scenarioData
     * @param dataSourceId
     * @param customerId
     */
    public Scenario(Long scenarioId, String scenarioName, String description, Long status, String scenarioData) {
        super();
        this.scenarioId = scenarioId;
        this.scenarioName = scenarioName;
        this.description = description;
        this.status = status;
        this.scenarioData = scenarioData;
    }

    /**
     * @return the scenarioId
     */
    public Long getScenarioId() {
        return scenarioId;
    }

    /**
     * @param scenarioId
     *            the scenarioId to set
     */
    public void setScenarioId(Long scenarioId) {
        this.scenarioId = scenarioId;
    }

    /**
     * @return the scenarioName
     */
    public String getScenarioName() {
        return scenarioName;
    }

    /**
     * @param scenarioName
     *            the scenarioName to set
     */
    public void setScenarioName(String scenarioName) {
        this.scenarioName = scenarioName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the status
     */
    public Long getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(Long status) {
        this.status = status;
    }

    /**
     * @return the scenarioData
     */
    public String getScenarioData() {
        return scenarioData;
    }

    /**
     * @param scenarioData
     *            the scenarioData to set
     */
    public void setScenarioData(String scenarioData) {
        this.scenarioData = scenarioData;
    }

    /**
     * @return the requestDataSet
     */
    public Set<RequestData> getRequestDataSet() {
        return requestDataSet;
    }

    /**
     * @param requestDataSet
     *            the requestDataSet to set
     */
    public void setRequestDataSet(Set<RequestData> requestDataSet) {
        this.requestDataSet = requestDataSet;
    }

    /**
     * @return the sourceId
     */
    public Long getSourceId() {
        return sourceId;
    }

    /**
     * @param sourceId the sourceId to set
     */
    public void setSourceId(Long sourceId) {
        this.sourceId = sourceId;
    }

    /**
     * @return the sourceType
     */
    public String getSourceType() {
        return sourceType;
    }

    /**
     * @param sourceType the sourceType to set
     */
    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    /**
     * @return the dataSourceName
     */
    public String getDataSourceName() {
        return dataSourceName;
    }

    /**
     * @param dataSourceName the dataSourceName to set
     */
    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }

    /**
     * @return the customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * @param customerName the customerName to set
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * @return the infoSchema
     */
    public String getInfoSchema() {
        return infoSchema;
    }

    /**
     * @param infoSchema the infoSchema to set
     */
    public void setInfoSchema(String infoSchema) {
        this.infoSchema = infoSchema;
    }

    /**
     * @return the format
     */
    public String getFormat() {
        return format;
    }

    /**
     * @param format the format to set
     */
    public void setFormat(String format) {
        this.format = format;
    }

    /**
     * @return the responseSchema
     */
    public String getResponseSchema() {
        return responseSchema;
    }

    /**
     * @param responseSchema the responseSchema to set
     */
    public void setResponseSchema(String responseSchema) {
        this.responseSchema = responseSchema;
    }

   

   
}
