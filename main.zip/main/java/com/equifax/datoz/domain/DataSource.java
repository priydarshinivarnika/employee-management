package com.equifax.datoz.domain;

import java.io.Serializable;
import java.util.*;




public class DataSource implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
   
  private Long sourceId;
  private String name;
  private String description;
  private String url;
  private String format;
  private String username;
  private String password;
  private Long timeout;
 
  private Long maxRequestPerDay;
  
  private String contentType;

  private String orgCode;
  
  private String igOrchestrationcode;
  
  private String memberNumber;
 
  private String requestSchema;
  
  private String responseSchema;
  private Set<DataSourceDetails> dataSourceDetails = new HashSet<DataSourceDetails>();
 
  private String personalInfoSchema;
  private String additionalDetails;
  private String sslDetails;
  private String datasourceType;
  
  /**
   * 
   */
  public DataSource() {
    super();
    
  }

  /**
   * @param source_id
   */
  public DataSource(Long sourceId) {
    super();
    this.sourceId = sourceId;
  }
 
  
  public String getSslDetails() {
    return sslDetails;
}

public void setSslDetails(String sslDetails) {
    this.sslDetails = sslDetails;
}
  
  public String getPersonalInfoSchema() {
    return personalInfoSchema;
  }

  public void setPersonalInfoSchema(String personalInfoSchema) {
    this.personalInfoSchema = personalInfoSchema;
  }

  /**
   * @return the source_id
   */
  public Long getSourceId() {
    return sourceId;
  }

  /**
   * @param source_id
   *            the source_id to set
   */
  public void setSourceId(Long sourceId) {
    this.sourceId = sourceId;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name
   *            the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description
   *            the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the url
   */
  public String getUrl() {
    return url;
  }

  /**
   * @param url
   *            the url to set
   */
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   * @return the format
   */
  public String getFormat() {
    return format;
  }

  /**
   * @param format
   *            the format to set
   */
  public void setFormat(String format) {
    this.format = format;
  }

  /**
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * @param username
   *            the username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @param password
   *            the password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * @return the timeout
   */
  public Long getTimeout() {
    return timeout;
  }

  /**
   * @param timeout
   *            the timeout to set
   */
  public void setTimeout(Long timeout) {
    this.timeout = timeout;
  }

  /**
   * @return the maxRequestPerDay
   */
  public Long getMaxRequestPerDay() {
    return maxRequestPerDay;
  }

  /**
   * @param maxRequestPerDay
   *            the maxRequestPerDay to set
   */
  public void setMaxRequestPerDay(Long maxRequestPerDay) {
    this.maxRequestPerDay = maxRequestPerDay;
  }

  /**
   * @return the content_type
   */
  public String getContentType() {
    return contentType;
  }

  /**
   * @param contentType
   *            the contentType to set
   */
  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  /**
   * @return the orgCode
   */
  public String getOrgCode() {
    return orgCode;
  }

  /**
   * @param orgCode
   *            the orgCode to set
   */
  public void setOrgCode(String orgCode) {
    this.orgCode = orgCode;
  }

  /**
   * @return the igOrchestrationcode
   */
  public String getIgOrchestrationcode() {
    return igOrchestrationcode;
  }

  /**
   * @param igOrchestrationcode
   *            the igOrchestrationcode to set
   */
  public void setIgOrchestrationcode(String igOrchestrationcode) {
    this.igOrchestrationcode = igOrchestrationcode;
  }

  /**
   * @return the memberNumber
   */
  public String getMemberNumber() {
    return memberNumber;
  }

  /**
   * @param memberNumber
   *            the memberNumber to set
   */
  public void setMemberNumber(String memberNumber) {
    this.memberNumber = memberNumber;
  }

  /**
   * @return the requestSchema
   */
  public String getRequestSchema() {
    return requestSchema;
  }

  /**
   * @param requestSchema
   *            the requestSchema to set
   */
  public void setRequestSchema(String requestSchema) {
    this.requestSchema = requestSchema;
  }

  /**
   * @return the responseSchema
   */
  public String getResponseSchema() {
    return responseSchema;
  }

  /**
   * @param responseSchema
   *            the responseSchema to set
   */
  public void setResponseSchema(String responseSchema) {
    this.responseSchema = responseSchema;
  }

  /**
   * @return the dataSourceDetails
   */
  public Set<DataSourceDetails> getDataSourceDetails() {
    return dataSourceDetails;
  }

  /**
   * @param dataSourceDetails the dataSourceDetails to set
   */
  public void setDataSourceDetails(Set<DataSourceDetails> dataSourceDetails) {
    this.dataSourceDetails = dataSourceDetails;
  }
  /**
   * @return the additionalDetails
   */
  public String getAdditionalDetails() {
      return additionalDetails;
  }
  /**
   * @param additionalDetails the additionalDetails to set
   */
  public void setAdditionalDetails(String additionalDetails) {
      this.additionalDetails = additionalDetails;
  }
/**
 * 
 * @return datasourceType
 */
public String getDatasourceType() {
    return datasourceType;
}


/**
 * @param datasourceType the datasourceType to set
 */
public void setDatasourceType(String datasourceType) {
    this.datasourceType = datasourceType;
}

 

  
}
