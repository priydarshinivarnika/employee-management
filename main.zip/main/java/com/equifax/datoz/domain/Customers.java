package com.equifax.datoz.domain;

import java.io.Serializable;
import java.util.*;

/**
 * @author dxh159
 *
 */
/**
 * @author dxh159
 *
 */
public class Customers implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long customerid;
    private Long sourceId;
    private String name;
    private String description;
    private String url;
    private String format;
    private String username;
    private String password;
    private Long timeout;
    private Long maxRequestPerDay;
    private String requestSchema;
    private String responseSchema;
    private String personalInfoSchema;
    private String additionalDetails;
    private Set<CustomerDetails> customerDetails = new HashSet<CustomerDetails>();
    
    private String sslDetails;

    /**
     * @param customerid
     * @param sourceId
     * @param name
     * @param description
     * @param url
     * @param format
     * @param username
     * @param password
     * @param timeout
     * @param maxRequestPerDay
     * @param requestSchema
     * @param responseSchema
     * @param personalInfoSchema
     * @param additionalDetails
     * @param customerDetails
     */
public Customers(Long customerid, Long sourceId, String name, String description, String url, String format, String username, String password, Long timeout,
    Long maxRequestPerDay,
    String requestSchema, String responseSchema, String personalInfoSchema, String additionalDetails, Set<CustomerDetails> customerDetails) {

    this.customerid = customerid;
    this.sourceId = sourceId;
    this.name = name;
    this.description = description;
    this.url = url;
    this.format = format;
    this.username = username;
    this.password = password;
    this.timeout = timeout;
    this.maxRequestPerDay = maxRequestPerDay;
    this.requestSchema = requestSchema;
    this.responseSchema = responseSchema;
    this.personalInfoSchema = personalInfoSchema;
    this.additionalDetails = additionalDetails;
    this.customerDetails = customerDetails;
}

public Customers() {
    super();
}
/**
 * @return the sslDetails
 */
    public String getSslDetails() {
        return sslDetails;
    }
    /**
     * @param sslDetails
     *            the sslDetails to set
     */
    public void setSslDetails(String sslDetails) {
        this.sslDetails = sslDetails;
    }
    /**
     * @return the customerid
     */
    public Long getCustomerid() {
        return customerid;
    }
    /**
     * @param customerid
     *            the customerid to set
     */
    public void setCustomerid(Long customerid) {
        this.customerid = customerid;
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description
     *            the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }
    /**
     * @param url
     *            the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }
    /**
     * @return the format
     */
    public String getFormat() {
        return format;
    }
    /**
     * @param format
     *            the format to set
     */
    public void setFormat(String format) {
        this.format = format;
    }
    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }
    /**
     * @param username
     *            the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }
    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }
    /**
     * @param password
     *            the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
    /**
     * @return the timeout
     */
    public Long getTimeout() {
        return timeout;
    }
    /**
     * @param timeout
     *            the timeout to set
     */
    public void setTimeout(Long timeout) {
        this.timeout = timeout;
    }
    /**
     * @return the maxRequestPerDay
     */
    public Long getMaxRequestPerDay() {
        return maxRequestPerDay;
    }
    /**
     * @param maxRequestPerDay
     *            the maxRequestPerDay to set
     */
    public void setMaxRequestPerDay(Long maxRequestPerDay) {
        this.maxRequestPerDay = maxRequestPerDay;
    }
    /**
     * @return the requestSchema
     */
    public String getRequestSchema() {
        return requestSchema;
    }
    /**
     * @param requestSchema
     *            the requestSchema to set
     */
    public void setRequestSchema(String requestSchema) {
        this.requestSchema = requestSchema;
    }
    /**
     * @return the responseSchema
     */
    public String getResponseSchema() {
        return responseSchema;
    }
    /**
     * @param responseSchema
     *            the responseSchema to set
     */
    public void setResponseSchema(String responseSchema) {
        this.responseSchema = responseSchema;
    }
    /**
     * @return the personalInfoSchema
     */
    public String getPersonalInfoSchema() {
        return personalInfoSchema;
    }
    /**
     * @param personalInfoSchema
     *            the personalInfoSchema to set
     */
    public void setPersonalInfoSchema(String personalInfoSchema) {
        this.personalInfoSchema = personalInfoSchema;
    }
    /**
     * @return the customerDetails
     */
    public Set<CustomerDetails> getCustomerDetails() {
        return customerDetails;
    }
    /**
     * @param customerDetails
     *            the customerDetails to set
     */
    public void setCustomerDetails(Set<CustomerDetails> customerDetails) {
        this.customerDetails = customerDetails;
    }
    /**
     * @return the sourceId
     */
    public Long getSourceId() {
        return sourceId;
    }
    /**
     * @param sourceId
     *            the sourceId to set
     */
    public void setSourceId(Long sourceId) {
        this.sourceId = sourceId;
    }
    /**
     * @return the additionalDetails
     */
    public String getAdditionalDetails() {
        return additionalDetails;
    }
    /**
     * @param additionalDetails
     *            the additionalDetails to set
     */
    public void setAdditionalDetails(String additionalDetails) {
        this.additionalDetails = additionalDetails;
    }

   
   
}
