package com.equifax.datoz.domain;



public class BasicInfo {

    Long infoId;
    String firstName;
    String lastName;
    String middleName;
    String socialSecurityNumber;
    String houseNumber;
    String streetName;
    String streetType;
    String city;
    String state;
    String country;
    String zip;
    Long status;
    DataSource dataSource;

    /**
     * @return the infoId
     */
 public Long getInfoId() {
    return infoId;
}
 /**
  * @param infoId
  *            the infoId to set
  */
public void setInfoId(Long infoId) {
    this.infoId = infoId;
}
/**
 * @return the firstName
 */
public String getFirstName() {
    return firstName;
}
/**
 * @param firstName
 *            the firstName to set
 */
public void setFirstName(String firstName) {
    this.firstName = firstName;
}
/**
 * @return the lastName
 */
public String getLastName() {
    return lastName;
}
/**
 * @param lastName
 *            the lastName to set
 */
public void setLastName(String lastName) {
    this.lastName = lastName;
}
/**
 * @return the middleName
 */
public String getMiddleName() {
    return middleName;
}
/**
 * @param middleName
 *            the middleName to set
 */
public void setMiddleName(String middleName) {
    this.middleName = middleName;
}
/**
 * @return the socialSecurityNumber
 */
public String getSocialSecurityNumber() {
    return socialSecurityNumber;
}
/**
 * @param socialSecurityNumber
 *            the socialSecurityNumber to set
 */
public void setSocialSecurityNumber(String socialSecurityNumber) {
    this.socialSecurityNumber = socialSecurityNumber;
}
/**
 * @return the houseNumber
 */
public String getHouseNumber() {
    return houseNumber;
}
/**
 * @param houseNumber
 *            the houseNumber to set
 */
public void setHouseNumber(String houseNumber) {
    this.houseNumber = houseNumber;
}
/**
 * @return the streetName
 */
public String getStreetName() {
    return streetName;
}
/**
 * @param streetName
 *            the streetName to set
 */
public void setStreetName(String streetName) {
    this.streetName = streetName;
}
/**
 * @return the streetType
 */
public String getStreetType() {
    return streetType;
}
/**
 * @param streetType
 *            the streetType to set
 */
public void setStreetType(String streetType) {
    this.streetType = streetType;
}
/**
 * @return the city
 */
public String getCity() {
    return city;
}
/**
 * @param city
 *            the city to set
 */
public void setCity(String city) {
    this.city = city;
}
/**
 * @return the state
 */
public String getState() {
    return state;
}
/**
 * @param state
 *            the state to set
 */
public void setState(String state) {
    this.state = state;
}
/**
 * @return the country
 */
public String getCountry() {
    return country;
}
/**
 * @param country
 *            the country to set
 */
public void setCountry(String country) {
    this.country = country;
}
/**
 * @return the zip
 */
public String getZip() {
    return zip;
}
/**
 * @param zip
 *            the zip to set
 */
public void setZip(String zip) {
    this.zip = zip;
}
/**
 * @return the status
 */
public Long getStatus() {
    return status;
}
/**
 * @param status
 *            the status to set
 */
public void setStatus(Long status) {
    this.status = status;
}
/**
 * @return the dataSource
 */
public DataSource getDataSource() {
    return dataSource;
}
/**
 * @param dataSource
 *            the dataSource to set
 */
public void setDataSource(DataSource dataSource) {
    this.dataSource = dataSource;
}
   
}
