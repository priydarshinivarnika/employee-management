package com.equifax.datoz.domain;

import java.io.Serializable;
import java.util.Date;
public class ResponseData implements Serializable {

private static final long serialVersionUID = 1L;
	
private Long responseId;
private RequestData requestData;
private String responseDataValue;
private Date updatedDate;
private Long status;

/**
* @return the response_Id
*/
public Long getResponseId() {
return responseId;
}

/**
* @param responseId
* the responseId to set
*/
public void setResponseId(Long responseId) {
this.responseId = responseId;
}

/**
* @return the requestData
*/
public RequestData getRequestData() {
return requestData;
}

/**
* @param requestData the requestData to set
*/
public void setRequestData(RequestData requestData) {
this.requestData = requestData;
}

/**
* @return the responseDataValue
*/
public String getResponseData() {
return responseDataValue;
}

/**
* @param responseDataValue
* the responseDataValue to set
*/
public void setResponseData(String responseDataValue) {
this.responseDataValue = responseDataValue;
}

/**
* @return the updatedDate
*/
public Date getUpdatedDate() {
return updatedDate;
}

/**
* @param updatedDate
* the updatedDate to set
*/
public void setUpdatedDate(Date updatedDate) {
this.updatedDate = updatedDate;
}

/**
* @return the status
*/
public Long getStatus() {
return status;
}

/**
* @param status
* the status to set
*/
public void setStatus(Long status) {
this.status = status;
}
}
