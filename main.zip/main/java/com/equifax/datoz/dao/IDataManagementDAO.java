package com.equifax.datoz.dao;

import java.util.List;
import java.util.Set;

import com.equifax.datoz.entity.BasicInfoVO;
import com.equifax.datoz.entity.CommercialInfoVO;
import com.equifax.datoz.entity.CustomerRequestDataVO;
import com.equifax.datoz.entity.CustomerScenarioVO;
import com.equifax.datoz.entity.CustomersVO;
import com.equifax.datoz.entity.DataSourceRequestDataVO;
import com.equifax.datoz.entity.DataSourceScenarioVO;
import com.equifax.datoz.entity.DataSourceVO;

public interface IDataManagementDAO {

  /**
   * Method to save request data
   * 
   * @param requestData
   */
  void saveRequest(final Object requestData);

  /**
   * Method to search scenario based on the criteria
   * 
   * @param scenario
   * @return
   */
  List<DataSourceScenarioVO> searchScenario(final DataSourceScenarioVO scenario);

  /**
   * Method to fetch data source
   * 
   * @return
   */
  List<DataSourceVO> getAllDataSource();

  /**
   * Method to fetch customer
   * 
   * @return
   */
  List<CustomersVO> getAllCustomer();

  /**
  /**
   * Method to save data source
   * 
   * @param dataSource
   */
  void saveDataSource(final DataSourceVO dataSource);

  /**
   * Method to save customer
   * 
   * @param customer
   */
  void saveCustomer(final CustomersVO customer);

  /**
   * Method to save scenario
   * 
   * @param scenario
   */
  void saveScenario(final DataSourceScenarioVO scenario);

  /**
   * Method to get all scenario from db
   * 
   * @return
   */
  List<CustomerScenarioVO> getAllCustScenario();

  /**
   * Method to get valid request data for a particular scenario specific to ds
   * 
   * @param scenario
   * @return
   */
  Set<DataSourceRequestDataVO> getDSRequestDataForScenario(final Long scenarioId);

  /**
   * Method to get valid request data for a particular scenario specific to ds for pagination
   * @param scenarioId
   * @param count
   * @param pageSize
   * @return
   */
  Set<DataSourceRequestDataVO> getDSRequestDataPagination(final Long scenarioId, final Long count, int pageSize);

  /**
   * Method to get valid request data for a particular scenario specific to customer
   * 
   * @param scenario
   * @return
   */
  Set<CustomerRequestDataVO> getCustRequestDataForScenario(final Long scenarioId);

  /**
   * Method to get valid request data for a particular scenario specific to customer for pagination
   * @param scenarioId
   * @param count
   * @param pageSize
   * @return
   */
  Set<CustomerRequestDataVO> getCustRequestDataPagination(final Long scenarioId, final Long count, int pageSize);

  /**
   * Method to search request data based on form fields
   * 
   * @param field
   * @return
   */
  List<DataSourceRequestDataVO> searchDSRequestData(final String field, final Long dataSourceId, final String format);

  /**
   * Method to search request data based on form fields
   * 
   * @param field
   * @return
   */
  List<CustomerRequestDataVO> searchCustRequestData(final String field, final Long dataSourceId, final String format);

  /**
   * Method to get the data source by id
   * 
   * @param dataSourceId
   * @return
   */
  DataSourceVO getDataSourceById(final Long dataSourceId);

  /**
   * Method to get the customer by id
   * 
   * @param customerId
   * @return
   */
  CustomersVO getCustomerById(final Long customerId);

  /**
   * Method to get the data source by id
   * 
   * @param dataSourceId
   * @param status 
   * @param recordCount 
   * @return
   */

  List<DataSourceRequestDataVO> getRequestDataBySourceId(final Long dataSourceId, boolean status, Long recordCount);

  /**
   * @param sourceId
   * @return
   */
  List<DataSourceScenarioVO> getAllDSScenario(Long sourceId);

  /**
   * Method to update request data
   * 
   * @param requestData
   */
  void updateRequest(final DataSourceRequestDataVO requestData);

  /**
   * Method to update scenario
   * @param scenario
   */
  void updateScenario(DataSourceScenarioVO scenario);

  /**
   *Method to delete headers for data source
   * 
   * @param dataSourceId
   */
  void deleteHeaders(final Long dataSourceId);

  /**
   * Method to delete headers for customer
   * @param customerId
   */
  void deleteCusHeaders(final Long customerId);

  /**
   * method to get datasource scenario by Id
   * @param scenarioId
   * @return
   */
  DataSourceScenarioVO getDSScenarioById(final Long scenarioId);

  /**
   * method to get scenario based on filter condition
   * @param scenario
   * @param sourceId
   * @param sourceType
   * @return
   */
  List getAllFilteredScenario(String scenario, Long sourceId, final String sourceType);

  /**
   * Method to get scenario by applying filter conditions 
   * @param scenario
   * @param sourceId
   * @param sourceType
   * @param count
   * @return
   */
  List getFilteredScenario(String scenario, Long sourceId, final String sourceType, final Long count);

  /**
   * Get all customers by source id
   * @param id
   * @return
   */
  List<CustomersVO> getAllCustomerBySource(long id);

  /**
   * Method to save  data
   * 
   * @param object
   */
  void save(final Object object);

  /**
   * Method to update data in db
   * @param object
   */
  void update(Object entity);

  /**
   * Merge different entities
   * @param entity
   */
  void mergeEntity(Object entity);

  /**
   * Method to get scenario by id
   * @param scenarioId
   * @return
   */
  CustomerScenarioVO getCustScenarioById(Long scenarioId);

  /**
   * Method to get data source request count
   * @param sourceId
   * @return
   */
  long getDataSourceRequestCount(Long sourceId);

  /**
   * Method to get customers without any request
   * @param sourceId
   * @return
   */
  List<CustomersVO> getNoRequestCustomers(Long sourceId);

  /**
   * Method to get basic info based on source id
   * @param sourceId
   * @param maxrequestperDay
   * @param status
   * @return
   */
  List<BasicInfoVO> getBasicInfoList(Long sourceId, Long maxrequestperDay, Long status);
  
  
  /**
   * Method to get commercial info based on source id
   * @param sourceId
   * @param maxrequestperDay
   * @param status
   * @return
   */
  List<CommercialInfoVO> getCommercialInfoList(Long sourceId, Long maxrequestperDay, Long status);

  /**
   * Method to insert data source request
   * @param request
   */
  void insertDataSourceRequest(List<Object> request);

  /**
   * Method to insert customer request
   * @param request
   */
  void insertCustomerRequest(List<Object> request);

  /**
   * Metho to get all scenario based on customer i d
   * @param customerid
   * @return
   */
  List<CustomerScenarioVO> getCustomerScenario(Long customerid);

  /**
   * Method to update scenario and data source request mapping
   * @param scenarioId
   * @param requestId
   */
  void insertDSScenarioRequestmapping(Long scenarioId, Long requestId);

  /**
   * Method to update scenario and customer request mapping
   * @param scenarioId
   * @param requestId
   */
  void insertCustScenarioRequestmapping(Long scenarioId, Long requestId);

  /**
   * Method to update basic info list status
   * @param basicInfos
   */
  void updateBasicInfo(List<BasicInfoVO> basicInfos);
  
  /**
   * Method to update basic info list status
   * @param basicInfos
   */
  void updateInfo(List basicInfos);

  /**
   * Method to get customer request by customer i d
   * @param customerIdId
   * @param status
   * @param recordCount
   * @return
   */
  List<CustomerRequestDataVO> getCustomerRequestDataByCustomerId(final Long customerIdId, boolean status, Long recordCount);

  /**
   * Method to get scenario based on name and type
   * @param scenarioName
   * @param customerType
   * @return
   */
  List<CustomerScenarioVO> getFilteredScenarioByScenario(String scenarioName, String customerType);

  /**
   * method to get customer request data based on request ids 
   * @param requestIds
   * @return
   */
  Set<CustomerRequestDataVO> getCustRequestData(List<Long> requestIds);

  /**
   * method to get data source request dat based on ids
   * @param requestIds
   * @return
   */
  Set<DataSourceRequestDataVO> getDSRequestData(List<Long> requestIds);

  /**
   * method for bulk insert
   * @param entities
   */
  void bulkInsert(List<Object> entities);

  /**
   * Method to get all data source by query
   * @return
   */
  List<DataSourceVO> getAllDataSourceByQuery();

  /**
   * method to get the request count for data source
   * @param scenarioId
   * @return
   */
  Long getResultCountForData(Long scenarioId);

  /**
   * Method to get request count for customer
   * @param scenarioId
   * @return
   */
  Long getResultCountForCustomer(Long scenarioId);

  /**
   * Method to get scenario based on filter condition and pagination
   * @param scenarioName
   * @param customerType
   * @param count
   * @return
   */
  List<CustomerScenarioVO> getFilteredScenarioByPage(String scenarioName, String customerType, Long count);

  /**
   * Method to get count of scenario based on filter condition and pagination
   * @param scenario
   * @param sourceId
   * @param sourceType
   * @return
   */
  Long getAllFilteredCountForScenario(String scenario, Long sourceId, String sourceType);

  /**
   * Method to get data source request based on pagination
   * @param scenarioId
   * @param pageSize
   * @return
   */
  Set<DataSourceRequestDataVO> getDSRequestEntriesForScenario(Long scenarioId, int pageSize);

  /**
   * Method to get customer request based on pagination
   * @param scenarioId
   * @param pageSize
   * @return
   */
  Set<CustomerRequestDataVO> getCustRequestEntriesForScenario(Long scenarioId, int pageSize);

  /**
   * method to insert basic info
   * @param entities
   */
  void bulkInsertOfBasicInfo(List<Object> entities);

  /**
   * Method to get data source by source id 
   * @param sourceId
   * @return
   */
  DataSourceVO getDataSourceVOById(Long sourceId);

  /**
   * Method to get customer based on id
   * @param customerId
   * @return
   */
  CustomersVO getCustomerVOById(Long customerId);
  
  /**
   * Method to delete customer scenario and request mapping from database
   * @param scenarioId
   */
  void deleteCustScenarioMapping(Long scenarioId);
  
  
  /**
   * Method to delete datasource scenario and request mapping from database
   * @param scenarioId
   */
  void deleteDSScenarioMapping(Long scenarioId);
  
  /**
   * Method to delete customer scenario and request mapping from database
   * @param requestId
   */
  void delCustScenarioMapping(List requests);
  
  
  /**
   * Method to delete datasource scenario and request mapping from database
   * @param requestId
   */
  void delDSScenarioMapping(List requests);
  
  
}
