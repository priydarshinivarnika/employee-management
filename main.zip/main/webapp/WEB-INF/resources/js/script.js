/* .......................... DRAG AND DROP .......................*/

function drag_handler(ev) {

}

function dragstart_handler(ev) {
	ev.dataTransfer.setData("text", ev.target.id);
}

function drop_handler(ev) {

	ev.currentTarget.style.background = "lightyellow";
	ev.preventDefault();
	var data = ev.dataTransfer.getData("text");
	var value = document.getElementById(data).innerHTML;
	value = value.replace(/<\/?[^>]+(>|$)/g, "")
	value = '${' + value + '}';

	ev.target.value = ev.target.value + value;
}

function dragover_handler(ev) {

	ev.preventDefault();

} // .......................Function End

/* ..................... POPUP ...................... */

$(function() {

	$("#response a").on("click", function() {

		var span_val = $(this).next("div").html();

		document.getElementById("modal").innerHTML = span_val;

	});
	$("#matchedresponse a").on("click", function() {

		var span_val = $(this).next("div").html();

		document.getElementById("modal").innerHTML = span_val;

	});

	var clipboard = new Clipboard('#myButton');
	clipboard.on('success', function(e) {
		clipboardData.setData("Text", e.text);
	});
	clipboard.on('error', function(e) {

	});

});

/* ...................Highlighter & Filtering............ */
$(document)
		.ready(
				function() {

					var highlight = function(string) {

						$("#myUL li.match").each(
								function() {
									var matchStart = $(this).text()
											.toLowerCase().indexOf(
													"" + string.toLowerCase()
															+ "");
									var matchEnd = matchStart + string.length
											- 1;
									var beforeMatch = $(this).text().slice(0,
											matchStart);
									var matchText = $(this).text().slice(
											matchStart, matchEnd + 1);
									var afterMatch = $(this).text().slice(
											matchEnd + 1);
									$(this).html(
											beforeMatch + "<em>" + matchText
													+ "</em>" + afterMatch);
								});
					};

					$("#myInput")
							.on(
									"keyup",
									function() {

										if (this.value.length >= 0) {
											$("#myUL li")
													.removeClass("match")
													.hide()
													.filter(
															function() {
																return $(this)
																		.text()
																		.toLowerCase()
																		.indexOf(
																				$(
																						"#myInput")
																						.val()
																						.toLowerCase()) != -1;
															})
													.addClass("match").show();
											highlight(this.value);
											$("#myUL").show();
										} else {
											$("#myUL, #myUL li").removeClass(
													"match").hide();
											$("#myUL, #myUL li").show();

										}

									});

				});

$(function() {

	$('[data-toggle="tooltip"]').tooltip();
	$("[rel=tooltip]").tooltip({
		html : true
	});
});
$(document).ready(function() {
	$('#response').DataTable();
});

$(function() {
	$("#btnAdd").bind("click", function() {
		var div = $("<tr />");
		div.html(GetDynamicTextBox(""));
		$("#TextBoxContainer").append(div);
	});
	$("body").on("click", ".remove", function() {
		$(this).closest("tr").remove();
	});

	$("#btnAdditional").bind("click", function() {
		var div = $("<tr />");
		div.html(GetAdditionalDetailBox(""));
		$("#AdditionalDetailContainer").append(div);
	});
});

function GetDynamicTextBox(value) {
	return '<td><input name = "headerkey" type="text" value = "'
			+ value
			+ '" class="form-control" /></td>'
			+ '<td><input name = "headervalue" type="text" value = "'
			+ value
			+ '" class="form-control" /></td>'
			+ '<td><button type="button" class="btn btn-danger remove">x</button></td>'
}
function GetAdditionalDetailBox(value) {
	return '<td><input name = "additionalField" type="text" value = "'
			+ value
			+ '" class="form-control" /></td>'
			+ '<td><input name = "additionalFieldPath" type="text" value = "'
			+ value
			+ '" class="form-control" /></td>'
			+ '<td><button type="button" class="btn btn-danger remove">x</button></td>'
}

$(document).ready(function() {
	$('.form-filter').multifilter()
})

function getScenarioFormFields(sourceId, sourceType) {

	$.ajax({
		url : "./getScenarioFormFields?sourceId=" + sourceId + "&sourceType="
				+ sourceType,
		beforeSend : function() {
			addSpinner($('body'));
		},
		success : function(data) {

			removeSpinner($('body'));
			$(".overlaybg").hide();
			var custId = document.getElementById("customerId");

			custId.value = sourceId;

			var divFormFields = document.getElementById("divFormFields");

			var ul = document.getElementById("myUL");

			$("#myUL").remove();

			var custUL = document.createElement('ul');

			custUL.setAttribute('id', 'myUL');
			custUL.setAttribute('class', 'list-formfields');

			divFormFields.appendChild(custUL);

			for (var i = 0; i < data.length; i++)

			{

				var li = document.createElement('li');

				li.setAttribute('class', 'item');

				li.setAttribute('id', data[i]);

				li.setAttribute('draggable', 'true');

				li.setAttribute('ondragstart', 'dragstart_handler(event)');

				custUL.appendChild(li);

				t = document.createTextNode(data[i]);

				li.innerHTML = li.innerHTML + data[i];

			}

		},
		error : function() {

			removeSpinner($('body'));
			$(".overlaybg").hide();
		}

	});
}

function getList(dsId) {

	$.ajax({

		url : "./getCustomerList?id=" + dsId,

		beforeSend : function() {

			addSpinner($('body'));

		},

		success : function(options) {

			removeSpinner($('body'));

			$(".overlaybg").hide();

			var dropdown = $('#customerselect');

			$('>option', dropdown).remove();

			var opt = new Option("SELECT");

			$("#customerselect").append(opt);

			if (options) {

				$.each(options, function(key, value) {

					dropdown.append($('<option/>').val(key).text(value));

				});

			}

		},
		error : function() {

			removeSpinner($('body'));
			$(".overlaybg").hide();
		}

	});

}

function passwordFunction() {

	var x = document.getElementById("password");

	if (x.type === "password") {

		x.type = "text";

	} else {

		x.type = "password";

	}

}

function getCustomers(sourceId) {

	$.get("./getCustomerList?sourceId=" + sourceId, function(data) {
		var custId = document.getElementById("customerId");
		custId.value = sourceId;
		var divFormFields = document.getElementById("divFormFields");
		var ul = document.getElementById("myUL");
		$("#myUL").remove();
		var custUL = document.createElement('ul');
		custUL.setAttribute('id', 'myUL');
		custUL.setAttribute('class', 'list-formfields');
		divFormFields.appendChild(custUL);
		for (var i = 0; i < data.length; i++) {
			var li = document.createElement('li');
			li.setAttribute('class', 'item');
			li.setAttribute('id', data[i]);
			li.setAttribute('draggable', 'true');
			li.setAttribute('ondragstart', 'dragstart_handler(event)');
			custUL.appendChild(li);
			t = document.createTextNode(data[i]);
			li.innerHTML = li.innerHTML + data[i];
		}

	});
}

$(function() {
	$("#save").click(function() {

		var datasource = $('#selectadd');
		if (datasource.val() == 'SELECT') {
			$('#selectadd').focus();

			return false;
		} else
			return;
	});
});

/*
 * spinner methods
 */

function addSpinner(el, static_pos) {
	document.body.style.backgroundColor = "rgba(255,255,255,0.5)";

	var spinner = el.children('.spinner');
	if (spinner.length && !spinner.hasClass('spinner-remove'))
		return null;
	!spinner.length
			&& (spinner = $(
					'<div class="spinner'
							+ (static_pos ? '' : ' spinner-absolute') + '"/>')
					.appendTo(el));
	animateSpinner(spinner, 'add');
}

function removeSpinner(el, complete) {
	var spinner = el.children('.spinner');
	spinner.length && animateSpinner(spinner, 'remove', complete);
}

function animateSpinner(el, animation, complete) {
	$(".overlaybg").show();
	if (el.data('animating')) {

		el.removeClass(el.data('animating')).data('animating', null);
		el.data('animationTimeout')
				&& clearTimeout(el.data('animationTimeout'));
	}
	el.addClass('spinner-' + animation).data('animating',
			'spinner-' + animation);
	el.data('animationTimeout', setTimeout(function() {
		animation == 'remove' && el.remove();
		complete && complete();
		document.body.style.backgroundColor = "#fff";
	}, parseFloat(el.css('animation-duration')) * 1000));
}

$(document).ready(function() {
	$('#mymodal').on('hidden', function() {
		clear()
	});
});

/*
 * function for pagination in matched request and responses
 */
function matchedDataPagination(val) {
	var qty = document.getElementById('qty').value;
	var count = parseInt(qty, 10) + val;
	document.getElementById('qty').value = count;
	var scenarioId = document.getElementById('scenarioId').value;
	var sourceId = document.getElementById('sourceId').value;
	var sourceType = document.getElementById('sourceType').value;
	var totalResultCount = document.getElementById('totalResultCount').value;
	var pageSize = document.getElementById("entries").value;
	var lastPage = (Math.ceil(totalResultCount / pageSize));
	if (count == lastPage) {
		document.getElementById('up').disabled = true;
	}
	if (count < 1) {
		count = 1;
	}
	if (count == 1) {
		document.getElementById('down').disabled = true;
		document.getElementById('up').disabled = false;

	}
	if (count > 1) {
		document.getElementById('down').disabled = false;
	}

	if (count < lastPage) {
		document.getElementById('up').disabled = false;
	}

	$("#matchedresponse").empty();
	$
			.ajax({

				url : "./getPages?count=" + count + "&id=" + scenarioId
						+ "&sourceId=" + sourceId + "&sourceType=" + sourceType
						+ "&pageSize=" + pageSize,
				beforeSend : function() {
					addSpinner($('body'));
				},
				success : function(data) {
					removeSpinner($('body'));
					$(".overlaybg").hide();

					var table = document.getElementById("matchedresponse");
					var header = table.createTHead();
					var row = header.insertRow(0);
					var cell = row.insertCell(0);

					cell.innerHTML = "<b>Data</b>";

					for (var i = 0; i < data.length; i++) {

						var row = table.insertRow(i + 1);
						var cell = row.insertCell(0);

						cell.innerHTML = data[i].resmodel;
						cell.innerHTML += "<div>";
						cell.innerHTML += "<a onclick ='displayModal(this.id)' data-toggle ='modal' data-target='#myModal' href='#' id="
								+ i
								+ ">Request Data</a> <div style='display:none;'>"
								+ data[i].requestDataValue
								+ "</div> &nbsp; &nbsp;&nbsp; &nbsp;";
						cell.innerHTML += "<a  href='#'id=data"
								+ i
								+ " onclick ='displayModal(this.id)' data-toggle ='modal' data-target='#myModal' >Response Data</a> <div style='display:none;'>"
								+ data[i].responseData
								+ "</div>&nbsp; &nbsp;&nbsp; &nbsp;";
						for ( var j in (data[i].addDetailsModel)) {

							cell.innerHTML += "<a  href='#'id=add"
									+ i
									+ " onclick ='displayModal(this.id)' data-toggle ='modal' data-target='#myModal' >"
									+ j + "</a> <div style='display:none;'>"
									+ data[i].addDetailsModel[j]
									+ "</div>&nbsp; &nbsp;&nbsp; &nbsp;";
						}

					}
				}
			})
}

/*
 * function to display model during pagination
 */
function displayModal(val) {

	$("#modal").empty();

	var data = document.getElementById(val).nextElementSibling;
	var span_val = data.innerHTML;

	document.getElementById("modal").innerHTML = span_val;

}

/*
 * function for pagination in scenariolist.jsp
 */

function scenarioListPagination(val) {
	var pages = document.getElementById('pages').value;
	var count = parseInt(pages, 10) + val;
	document.getElementById('pages').value = count;
	var dataSourceId = document.getElementById('dataSourceId').value;
	var customerId = document.getElementById('customerId').value;
	var scenario = document.getElementById('scenario').value;
	var totalResultCount = document.getElementById('totalResultCount').value;
	var sourceType = document.getElementById('sourceType').value;
	if (sourceType == "dataSource") {
		url = "./getResult?count=" + count + "&sourceId=" + dataSourceId
				+ "&scenario=" + scenario + "&sourceType=" + sourceType;
	} else if (sourceType == "customer") {
		url = "./getResult?count=" + count + "&sourceId=" + customerId
				+ "&scenario=" + scenario + "&sourceType=" + sourceType;
	}

	var lastPage = (Math.ceil(totalResultCount / 10));
	if (count == lastPage) {
		document.getElementById('up').disabled = true;
	}
	if (count < 1) {
		count = 1;
	}
	if (count == 1) {
		document.getElementById('down').disabled = true;
		document.getElementById('up').disabled = false;
	}
	if (totalResultCount < 10) {
		document.getElementById('up').disabled = true;
	}
	if (count > 1) {
		document.getElementById('down').disabled = false;
	}
	if (count < lastPage) {
		document.getElementById('up').disabled = false;
	}

	$("#myTable").empty();
	$
			.ajax({

				url : url,

				beforeSend : function() {
					addSpinner($('body'));
				},
				success : function(data) {
					removeSpinner($('body'));
					$(".overlaybg").hide();

					if (sourceType == "dataSource") {

						var table = document.getElementById("myTable");

						var header = table.createTHead();
						var row = header.insertRow(0);
						var cell1 = row.insertCell(0);
						var cell2 = row.insertCell(1);
						var cell3 = row.insertCell(2);
						var cell4 = row.insertCell(3);
						cell1.innerHTML = "<b>Scenario Name</b>";
						cell2.innerHTML = "<b>Description</b>";
						cell3.innerHTML = "<b>Source</b>";
						cell4.innerHTML = "<b>Customer</b>";
						for (var i = 0; i < data.length; i++) {

							var row = table.insertRow(i + 1);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);

							cell1.innerHTML += "<a onclick='addSpinner($('this.body'))' href=./navRequestData?id="
									+ data[i].scenarioId
									+ "&sourceId="
									+ data[i].sourceId
									+ "&sourceType="
									+ data[i].sourceType
									+ ">"
									+ data[i].scenarioName + " </a>";
							cell1.innerHTML += "<a onclick='addSpinner($('this.body'))' href=./editScenario?scenarioId="
									+ data[i].scenarioId
									+ "&sourceType="
									+ data[i].sourceType
									+ " ><span class='glyphicon glyphicon-pencil'></span></a>";
							cell2.innerHTML = data[i].description;
							cell3.innerHTML = data[i].dataSourceName;
							cell4.innerHTML = "";
						}

					}

					else if (sourceType == "customer") {

						var table = document.getElementById("myTable");

						var header = table.createTHead();
						var row = header.insertRow(0);
						var cell1 = row.insertCell(0);
						var cell2 = row.insertCell(1);
						var cell3 = row.insertCell(2);
						var cell4 = row.insertCell(3);
						cell1.innerHTML = "<b>Scenario Name</b>";
						cell2.innerHTML = "<b>Description</b>";
						cell3.innerHTML = "<b>Source</b>";
						cell4.innerHTML = "<b>Customer</b>";
						for (var i = 0; i < data.length; i++) {

							var row = table.insertRow(i + 1);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);

							cell1.innerHTML += "<a onclick='addSpinner($('this.body'))' href=./navRequestData?id="
									+ data[i].scenarioId
									+ "&sourceId="
									+ data[i].sourceId
									+ "&sourceType="
									+ data[i].sourceType
									+ ">"
									+ data[i].scenarioName + " </a>";
							cell1.innerHTML += "<a onclick='addSpinner($('this.body'))' href=./editScenario?scenarioId="
									+ data[i].scenarioId
									+ "&sourceType="
									+ data[i].sourceType
									+ " ><span class='glyphicon glyphicon-pencil'></span></a>";
							cell2.innerHTML = data[i].description;
							cell3.innerHTML = data[i].dataSourceName;
							cell4.innerHTML = data[i].customerName;
						}

					}
				}
			})

}

/*
 * Function on entry change to display matched requets and responses
 * 
 */

function matchedDataEntries() {

	document.getElementById('qty').value = 1;
	var totalResultCount = parseInt(document.getElementById('totalResultCount').value);

	var scenarioId = document.getElementById('scenarioId').value;
	var sourceId = document.getElementById('sourceId').value;
	var sourceType = document.getElementById('sourceType').value;
	var pageSize = parseInt(document.getElementById("entries").value);

	var count = document.getElementById('qty').value;

	if (totalResultCount < pageSize) {
		document.getElementById('up').disabled = true;
		document.getElementById('down').disabled = true;
	} else {
		document.getElementById('up').disabled = false;

	}

	if (count == 1) {
		document.getElementById('down').disabled = true;
	}

	$("#matchedresponse").empty();
	$
			.ajax({

				url : "./getEntries?pageSize=" + pageSize + "&id=" + scenarioId
						+ "&sourceId=" + sourceId + "&sourceType=" + sourceType,
				beforeSend : function() {
					addSpinner($('body'));
				},
				success : function(data) {
					removeSpinner($('body'));
					$(".overlaybg").hide();

					var table = document.getElementById("matchedresponse");
					var header = table.createTHead();
					var row = header.insertRow(0);
					var cell = row.insertCell(0);

					cell.innerHTML = "<b>Data</b>";

					for (var i = 0; i < data.length; i++) {

						var row = table.insertRow(i + 1);
						var cell = row.insertCell(0);

						cell.innerHTML = data[i].resmodel;
						cell.innerHTML += "<div>";
						cell.innerHTML += " <a onclick ='displayModal(this.id)' data-toggle ='modal' data-target='#myModal' href='#' id="
								+ i
								+ ">Request Data</a> <div style='display:none;'>"
								+ data[i].requestDataValue
								+ "</div> &nbsp;&nbsp;&nbsp;&nbsp;";
						cell.innerHTML += "<a  href='#'id=data"
								+ i
								+ " onclick ='displayModal(this.id)' data-toggle ='modal' data-target='#myModal' >Response Data</a> <div style='display:none;'>"
								+ data[i].responseData
								+ "</div>  &nbsp; &nbsp; &nbsp;&nbsp;";
						for ( var j in (data[i].addDetailsModel)) {

							cell.innerHTML += "<a  href='#'id=add"
									+ i
									+ " onclick ='displayModal(this.id)' data-toggle ='modal' data-target='#myModal' >"
									+ j + "</a> <div style='display:none;'>"
									+ data[i].addDetailsModel[j]
									+ "</div>  &nbsp;&nbsp; &nbsp;&nbsp;";
						}

					}
				}
			})
}

$(document).ready(function() {
	var url = window.location;
	$('ul.nav a[href="' + url + '"]').parent().addClass('active');
	$('ul.nav a').filter(function() {
		return this.href == url;
	}).parent().addClass('active');

	$('.dropdown').click(function() {
		$(this).addClass('open');
	});

	$(".drop-sce").on("click", function() {
		$(".drop-sce").addClass("active");

	});

	$('.dropdown-toggle').dropdown();

	/*
	 * $('#dataSync').click(function () {
	 * 
	 * });
	 */

});

function scheduleDataSync() {
	Confirm('Datoz', 'Are you sure you want to start Data Sync', 'Yes',
			'Cancel'); /* change */

	/*
	 * $.ajax({
	 * 
	 * url : "./schedule", type : "POST",
	 * 
	 * beforeSend : function() { addSpinner($('body')); }, success :
	 * function(data) { removeSpinner($('body')); $(".overlaybg").hide();
	 * 
	 * $('#scheduleModal').modal('toggle') }, error : function() {
	 * 
	 * removeSpinner($('body')); $(".overlaybg").hide(); }
	 *  })
	 */
}

function Confirm(title, msg, $true, $false) { /* change */
	var $content = "<div class='dialog-ovelay'>"
			+ "<div class='dialog'><header>" + " <h3> " + title + " </h3> "
			+ "<i class='fa fa-close'></i>" + "</header>"
			+ "<div class='dialog-msg'>" + " <p> " + msg + " </p> " + "</div>"
			+ "<footer>" + "<div class='controls'>"
			+ " <button class='button button-danger doAction'>" + $true
			+ "</button> "
			+ " <button class='button button-default cancelAction'>" + $false
			+ "</button> " + "</div>" + "</footer>" + "</div>" + "</div>";
	$('body').prepend($content);
	$('.doAction').click(function() {
		$.ajax({

			url : "./schedule",
			type : "POST",

			beforeSend : function() {
				addSpinner($('body'));
			},
			success : function(data) {
				removeSpinner($('body'));
				$(".overlaybg").hide();

				$('#scheduleModal').modal('toggle')
			},
			error : function() {

				removeSpinner($('body'));
				$(".overlaybg").hide();
			}

		})
		$(this).parents('.dialog-ovelay').fadeOut(500, function() {
			$(this).remove();
		});
	});
	$('.cancelAction, .fa-close').click(function() {
		$(this).parents('.dialog-ovelay').fadeOut(500, function() {
			$(this).remove();
		});
	});

}
