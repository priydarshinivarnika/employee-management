

-- tables
-- Table: data_source
CREATE TABLE data_source (
    source_id number  NOT NULL,
    name varchar(50)  NULL,
    description varchar(500)  NULL,
    url varchar(500)  NULL,
    format varchar(500)  NULL,
    username varchar(500)  NULL,
    password varchar(500)  NULL,
    timeout number  NULL,
    max_request_per_day number  NULL,
    content_type varchar(500)  NULL,
    org_code varchar(100)  NULL,
    ig_orchestrationcode varchar(500)  NULL,
    member_number varchar(100)  NULL,
	personal_info_schema clob NULL, 
    request_schema clob  NULL,
    response_schema clob  NULL,
    CONSTRAINT data_source_pk PRIMARY KEY (source_id)
);

-- Table: data_source_details
CREATE TABLE data_source_details (
    id number  NOT NULL,
    source_id number  NULL,
    header_name varchar(100)  NULL,
    header_value varchar(1000)  NULL,
    CONSTRAINT data_source_details_pk PRIMARY KEY (id)
);

-- Table: .customers

-- DROP TABLE customers;

CREATE TABLE customers
(
    customer_id number NOT NULL,
    source_id number,
    description varchar(500),
    url varchar(500),
    format varchar(500),
    username varchar(500),
    password varchar(500),
    timeout number,
    max_request_per_day number,
    request_schema clob,
    response_schema clob,
    personal_info_schema clob,
    customer_name varchar(255),
    CONSTRAINT customers_pkey PRIMARY KEY (customer_id),
    CONSTRAINT "customers to datasource" FOREIGN KEY (source_id)
        REFERENCES data_source (source_id)
);

CREATE TABLE customer_details
(
    id number NOT NULL,
    customer_id number,
    header_name varchar(100),
    header_value varchar(1000),
    CONSTRAINT customer_details_pkey PRIMARY KEY (id),
    CONSTRAINT "customer_details to customers" FOREIGN KEY (customer_id)
        REFERENCES customers (customer_id)
);


-- Table: request_data
CREATE TABLE ds_request_data (
    request_data clob   NULL,
    created_date date  NULL,
    updated_date date  NULL,
    request_id number  NOT NULL,
    status number  NULL,
    source_id number  NULL,
    response_data clob  NULL,
    res_updated_date date  NULL,
	req_send_status number  NULL,
    CONSTRAINT request_data_pk PRIMARY KEY (request_id)
);

CREATE TABLE cust_request_data (
    request_data clob   NULL,
    created_date date  NULL,
    updated_date date  NULL,
    request_id number  NOT NULL,
    status number  NULL,
    customer_id number  NULL,
    response_data clob  NULL,
    res_updated_date date  NULL,
	req_send_status number  NULL,
    CONSTRAINT cust_request_data_pk PRIMARY KEY (request_id)
);

-- Table: scenario
CREATE TABLE ds_scenario (
    scenario_id number  NOT NULL,
    scenario_name varchar(100)  NULL,
    description varchar(1000)  NULL,
    status number  NULL,
    scenario_data clob  NULL,
    source_id number  NULL,
    CONSTRAINT scenario_pk PRIMARY KEY (scenario_id)
);

CREATE TABLE cust_scenario (
    scenario_id number  NOT NULL,
    scenario_name varchar(100)  NULL,
    description varchar(1000)  NULL,
    status number  NULL,
    scenario_data clob  NULL,
    customer_id number  NULL,
    CONSTRAINT cust_scenario_pk PRIMARY KEY (scenario_id)
);

-- Table: user
CREATE TABLE user_details (
    user_id number  NOT NULL,
    name varchar(100)  NULL,
    user_name varchar(100)  NULL,
    password varchar(100)  NULL,
    status number  NULL,
    expiry_date date  NULL,
    pwd_retry_count number  NOT NULL,
    CONSTRAINT user_pk PRIMARY KEY (user_id)
);

CREATE TABLE user_roles (
    user_role_id number  NOT NULL,
    role varchar(50)  NULL,
    user_name varchar(100)  NULL,    
    CONSTRAINT user_role_pk PRIMARY KEY (user_role_id)
);


CREATE TABLE basic_info (
    info_id number  NOT NULL,
	SSN varchar(100)  NULL,
    first_name varchar(100)  NULL,
    last_name varchar(100)  NULL,
	middle_name varchar(100)  NULL,
    house_number varchar(100)  NULL,
	street_name varchar(100)  NULL,
	street_type varchar(100)  NULL,
	city varchar(100)  NULL,
	state varchar(100)  NULL,
	zip varchar(100)  NULL,
	country varchar(100)  NULL,
    status number  NULL,
	source_id number  NULL,
    CONSTRAINT basic_info_pk PRIMARY KEY (info_id)
);

CREATE TABLE commercial_info (
    commercial_info_id number  NOT NULL,
	business_name varchar(100)  NULL,
    tax_id varchar(100)  NULL,
    house_number varchar(100)  NULL,
	address_line varchar(100)  NULL,
	street_name varchar(100)  NULL,
	street_type varchar(100)  NULL,
	city varchar(100)  NULL,
	state varchar(100)  NULL,
	zip varchar(100)  NULL,
	country varchar(100)  NULL,
    status number  NULL,
	source_id number  NULL,
    CONSTRAINT commercial_info_pk PRIMARY KEY (commercial_info_id)
);

-- Table: scenario_request_mapping
CREATE TABLE ds_scenario_request_mapping (
    request_id number  NOT NULL,
    scenario_id number  NOT NULL,
    CONSTRAINT ds_scenario_request_pk PRIMARY KEY (request_id,scenario_id)
);

-- Table: scenario_request_mapping
CREATE TABLE cust_scenario_request_mapping (
    request_id number  NOT NULL,
    scenario_id number  NOT NULL,
    CONSTRAINT cust_mapping_pk PRIMARY KEY (request_id,scenario_id)
);

-- Table:audit_log
CREATE TABLE audit_log(
	log_id number NOT NULL,
    user_id number NOT NULL,
    action_id number NOT NULL,
    attributes varchar(200),
    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT log_id_pk PRIMARY KEY (log_id)
);

--Table:audit_action
CREATE TABLE audit_action(
	action_id number NOT NULL,
    action_name varchar(50)
 );
 
INSERT INTO audit_action(action_id, action_name) VALUES (1, 'user_login');

ALTER TABLE customers ADD additional_details clob NULL;
ALTER TABLE data_source ADD additional_details clob NULL;
ALTER TABLE data_source  ADD ssl_details varchar2(250);
ALTER TABLE customers  ADD ssl_details varchar2(250);
ALTER TABLE data_source ADD DATASOURCE_TYPE VARCHAR2(50);

CREATE SEQUENCE seq_scenario_id INCREMENT BY 1;
CREATE SEQUENCE seq_datasource_id INCREMENT BY 1; 
CREATE SEQUENCE seq_customer_id INCREMENT BY 1;  
CREATE SEQUENCE seq_requestdata_id INCREMENT BY 1; 
CREATE SEQUENCE seq_cust_scenario_id INCREMENT BY 1;
CREATE SEQUENCE seq_cust_requestdata_id INCREMENT BY 1;  
CREATE SEQUENCE seq_info_id INCREMENT BY 1; 
CREATE SEQUENCE seq_datasourcedetails_id INCREMENT BY 1;      
CREATE SEQUENCE seq_customerdetails_id INCREMENT BY 1; 
CREATE SEQUENCE seq_user_id INCREMENT BY 1;
CREATE SEQUENCE seq_user_role_id INCREMENT BY 1;
CREATE SEQUENCE seq_commercial_info_id INCREMENT BY 1;       
CREATE SEQUENCE seq_log_id INCREMENT BY 1;

GRANT INSERT, SELECT, DELETE, UPDATE ON data_source to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON data_source_details to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON customers to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON customer_details to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON ds_scenario to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON ds_request_data to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON ds_scenario_request_mapping to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON cust_scenario to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON cust_request_data to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON cust_scenario_request_mapping to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON basic_info to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON user_details to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON user_roles to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON commercial_info to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON audit_log to U_QATOZ;
GRANT INSERT, SELECT, DELETE, UPDATE ON audit_action to U_QATOZ;
GRANT SELECT ON seq_info_id to U_QATOZ;
GRANT SELECT ON seq_cust_requestdata_id to U_QATOZ;
GRANT SELECT ON seq_cust_scenario_id to U_QATOZ;
GRANT SELECT ON seq_customerdetails_id to U_QATOZ;
GRANT SELECT ON seq_datasource_id to U_QATOZ;
GRANT SELECT ON seq_datasourcedetails_id to U_QATOZ;
GRANT SELECT ON seq_requestdata_id to U_QATOZ;
GRANT SELECT ON seq_scenario_id to U_QATOZ;
GRANT SELECT ON seq_customer_id to U_QATOZ;  
GRANT SELECT ON seq_user_id to U_QATOZ;
GRANT SELECT ON seq_user_role_id to U_QATOZ;  .
GRANT SELECT ON seq_commercial_info_id to U_QATOZ;
GRANT SELECT ON seq_log_id to U_QATOZ;     
-- End of file.

