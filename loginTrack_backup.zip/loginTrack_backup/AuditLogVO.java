package com.equifax.datoz.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "audit_log")
public class AuditLogVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long actionId;
	private Long actionType;
	private String attributes;
	private Date addedDate;

	private UserDetailsVO userDetailsVO;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "action_seq")
	@SequenceGenerator(name = "action_seq", sequenceName = "seq_action_id", allocationSize = 1)
	@Column(name = "action_id")
	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	@Column(name = "action_type")
	public Long getActionType() {
		return actionType;
	}

	public void setActionType(Long actionType) {
		this.actionType = actionType;
	}

	@Column(name = "attributes")
	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	@Column(name = "added_date")
	public Date getAddedDate() {
		return addedDate;
	}

	public void setAddedDate(Date addedDate) {
		this.addedDate = addedDate;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id", nullable = false, referencedColumnName = "user_id")
	public UserDetailsVO getUserDetailsVO() {
		return userDetailsVO;
	}

	public void setUserDetailsVO(UserDetailsVO userDetailsVO) {
		this.userDetailsVO = userDetailsVO;
	}

}
