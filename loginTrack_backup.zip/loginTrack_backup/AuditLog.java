package com.equifax.datoz.domain;

import java.io.Serializable;
import java.util.Date;

public class AuditLog implements Serializable  {

	private static final long serialVersionUID = 1L;
	private	Long actionId;
	private	Long userId;
	private Long actionType;
	private String attributes;
	private Date addedDate;
	private UserDetails userDetails;
	
	/**
     * @return the actionId
     */
	public Long getActionId() {
		return actionId;
	}
	 /**
     * @param actionId
     *            the actionId to set
     */
	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}
	/**
     * @return the userId
     */
	public Long getUserId() {
		return userId;
	}
	/**
     * @param userId
     *            the userId to set
     */
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	/**
     * @return the actionType
     */
	public Long getActionType() {
		return actionType;
	}
	/**
     * @param actionType
     *            the actionType to set
     */
	public void setActionType(Long actionType) {
		this.actionType = actionType;
	}
	/**
     * @return the attributes
     */
	public String getAttributes() {
		return attributes;
	}
	/**
     * @param attributes
     *            the attributes to set
     */
	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}
	/**
     * @return the addedDate
     */
	public Date getAddedDate() {
		return addedDate;
	}
	/**
     * @param addedDate
     *            the addedDate to set
     */
	public void setAddedDate(Date addedDate) {
		this.addedDate = addedDate;
	}
	/**
     * @return the serialVersionUID
     */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/**
     * @return the userDetails
     */
	public UserDetails getUserDetails() {
		return userDetails;
	}
	/**
     * @param userDetails
     *            the userDetails to set
     */
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	
}
