package com.equifax.datoz.dao.impl;

import java.io.IOException;
import java.util.*;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.*;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.dao.IDataManagementDAO;
import com.equifax.datoz.entity.*;

public class DataManagementDAO extends HibernateDaoSupport implements IDataManagementDAO {
  private static final Logger LOGGER = Logger.getLogger(DataManagementDAO.class);

  /*
   * (non-Javadoc)
   * 
   * @see com.equifax.datoz.dao.IDataManagementDAO#searchScenario(com.equifax.datoz.entity.DataSourceScenarioVO)
   */
  @Override
  public List<DataSourceScenarioVO> searchScenario(final DataSourceScenarioVO scenario) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(DataSourceScenarioVO.class);
    hibCriteria.add(Restrictions.like(Constants.SCENARIONAME, scenario.getScenarioName()));
    hibCriteria.add(Restrictions.eq(Constants.SOURCEID, scenario.getDataSourceVO().getSourceId()));
    return hibCriteria.list();
  }

  /**
   * Method to search request data based on form fields
   * 
   * @param field
   * @return
   */
  @Override
  public List<DataSourceRequestDataVO> searchDSRequestData(final String field, final Long dataSourceId, final String format) {
    Session session = getSessionFactory().getCurrentSession();
    Map<String, String> jsonFieldMap = new HashMap<String, String>();
    ObjectMapper objectMapper = new ObjectMapper();
    Criteria hibCriteria = session.createCriteria(DataSourceRequestDataVO.class);

    Conjunction conjunction = Restrictions.conjunction();
    conjunction.add(Restrictions.eq(Constants.SOURCEID, dataSourceId));
    conjunction.add(Restrictions.eq(Constants.REQ_SEND_STATUS, 1L));
    conjunction.add(Restrictions.eq(Constants.STATUS, 1L));
    if (null != field && !field.isEmpty()) {
      try {
        jsonFieldMap = objectMapper.readValue(field, HashMap.class);

        Map<String, String> fieldMap = new HashMap<String, String>();
        addLikeStmtInQuery(format, jsonFieldMap, conjunction, fieldMap);

      } catch (IOException e) {
        LOGGER.error(e);
      }

      hibCriteria.add(conjunction);
      hibCriteria.setMaxResults(Constants.PAGESIZE);
    }
    return hibCriteria.list();
  }

  /**
   * Method to add condition to search query
   * @param format
   * @param jsonFieldMap
   * @param conjunction
   * @param fieldName
   * @param pathArray
   * @param disjunction
   */
  private void addQueryContraints(final String format, Map<String, String> jsonFieldMap, Conjunction conjunction, String fieldName, String[] pathArray, Disjunction disjunction) {
    if (Constants.JSON.equalsIgnoreCase(format.toUpperCase())) {
      disjunction.add(Restrictions.like(Constants.RESPONSE_DATA, "%\"" + pathArray[pathArray.length - 1]
        + "\"" + ": \"" + jsonFieldMap.get(fieldName) + "\"%"));
      disjunction.add(Restrictions.like(Constants.RESPONSE_DATA, "%\"" + pathArray[pathArray.length - 1]
        + "\"" + " : \"" + jsonFieldMap.get(fieldName) + "\"%"));
      disjunction.add(Restrictions.like(Constants.RESPONSE_DATA, "%\"" + pathArray[pathArray.length - 1]
        + "\"" + ":\"" + jsonFieldMap.get(fieldName) + "\"%"));
      conjunction.add(disjunction);
    } else if (Constants.XML.equalsIgnoreCase(format.toUpperCase())) {
      conjunction.add(Restrictions.like(Constants.RESPONSE_DATA,
        "%<" + pathArray[pathArray.length - 1] + ">" + jsonFieldMap.get(fieldName) + "%"));
    }
  }

  /**
   * Method to search request data based on form fields
   * 
   * @param field
   * @return
   */
  @Override
  public List<CustomerRequestDataVO> searchCustRequestData(final String field, final Long dataSourceId, final String format) {
    Session session = getSessionFactory().getCurrentSession();
    Map<String, String> jsonFieldMap = new HashMap<String, String>();
    ObjectMapper objectMapper = new ObjectMapper();
    Criteria hibCriteria = session.createCriteria(CustomerRequestDataVO.class);

    Conjunction conjunction = Restrictions.conjunction();
    conjunction.add(Restrictions.eq(Constants.CUSTOMERID, dataSourceId));
    conjunction.add(Restrictions.eq(Constants.REQ_SEND_STATUS, 1L));
    conjunction.add(Restrictions.eq(Constants.STATUS, 1L));
    if (null != field && !field.isEmpty()) {
      try {
        jsonFieldMap = objectMapper.readValue(field, HashMap.class);

        Map<String, String> fieldMap = new HashMap<String, String>();
        addLikeStmtInQuery(format, jsonFieldMap, conjunction, fieldMap);

      } catch (IOException ioException) {
        LOGGER.error("Exception occured in DataManagementDAO.searchCustRequestData() :: " + ioException);
      }

      hibCriteria.add(conjunction);
    }

    return hibCriteria.list();
  }

  /**
   * @param format
   * @param jsonFieldMap
   * @param conjunction
   * @param fieldMap
   */
  private void addLikeStmtInQuery(final String format, Map<String, String> jsonFieldMap, Conjunction conjunction, Map<String, String> fieldMap) {
    if (!jsonFieldMap.isEmpty()) {
      for (String fieldName : jsonFieldMap.keySet()) {
        String[] pathArray = fieldName.split("\\.");
        Disjunction disjunction = Restrictions.disjunction();
        addQueryContraints(format, jsonFieldMap, conjunction, fieldName, pathArray, disjunction);
        fieldMap.put(pathArray[pathArray.length - 1], jsonFieldMap.get(fieldName));
      }
    }
  }

  @Override
  public void saveRequest(Object requestData) {
    getHibernateTemplate().save(requestData);

  }

  @Override
  public List<DataSourceVO> getAllDataSource() {
    return getHibernateTemplate().loadAll(DataSourceVO.class);
  }

  @Override
  public List<CustomersVO> getAllCustomer() {
    return getHibernateTemplate().loadAll(CustomersVO.class);
  }

  /**
   * Method to get the customer by sourceId
   * 
   * @param sourceId
   * @return
   */
  @Override
  public List<CustomersVO> getAllCustomerBySource(long id) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(CustomersVO.class);
    hibCriteria.add(Restrictions.eq(Constants.DATASOURCE_SOURCEID, id));
    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    return hibCriteria.list();
  }

  /**
   * Method to save data source
   * 
   * @param dataSource
   */
  @Override
  public void saveDataSource(final DataSourceVO dataSource) {
    getHibernateTemplate().saveOrUpdate(dataSource);
  }

  /**
   * Method to save customer
   * 
   * @param customer
   */
  @Override
  public void saveCustomer(final CustomersVO customer) {
    getHibernateTemplate().saveOrUpdate(customer);
  }

  /**
   * Method to save scenario
   * 
   * @param scenario
   */
  @Override
  public void saveScenario(final DataSourceScenarioVO scenario) {
    getHibernateTemplate().saveOrUpdate(scenario);
    getHibernateTemplate().flush();
  }

  /**
   * Method to get all scenario from db
   * 
   * @return
   */
  @Override
  public List<CustomerScenarioVO> getAllCustScenario() {
    return getHibernateTemplate().loadAll(CustomerScenarioVO.class);
  }

  /**
   * Method to get valid request data for a particular scenario
   * 
   * @param scenario
   * @return
   */
  @Override
  public Set<DataSourceRequestDataVO> getDSRequestDataForScenario(final Long scenarioId) {

    Session session = getSessionFactory().getCurrentSession();
    Set<DataSourceRequestDataVO> requestDataSet = null;
    String queryString = Constants.DATASOURCEREQUESTDATAVO_QUERY + scenarioId + Constants.CLOSING_BRACES;
    Query query = session.createQuery(queryString);
    query.setFirstResult(0);
    query.setMaxResults(Constants.PAGESIZE);
    List<DataSourceRequestDataVO> requestDataList = query.list();
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<DataSourceRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }
    return requestDataSet;

  }

  @Override
  public Long getResultCountForData(final Long scenarioId) {
    Session session = getSessionFactory().getCurrentSession();
    String countQ = Constants.DATASOURCEREQUESTDATAVO_COUNT_QUERY + scenarioId
      + Constants.CLOSING_BRACES;
    return (Long) session.createQuery(countQ).uniqueResult();

  }

  @Override
  public Set<DataSourceRequestDataVO> getDSRequestDataPagination(final Long scenarioId, final Long count, final int pageSize) {

    Session session = getSessionFactory().getCurrentSession();
    Set<DataSourceRequestDataVO> requestDataSet = null;

    String queryString = Constants.DATASOURCEREQUESTDATAVO_QUERY + scenarioId + Constants.CLOSING_BRACES;
    Query query = session.createQuery(queryString);
    if (count > 1) {
      query.setFirstResult((int) ((count - 1) * pageSize));
      query.setMaxResults(pageSize);
    } else if (count == 1) {
      query.setFirstResult(0);
      query.setMaxResults(pageSize);
    }
    List<DataSourceRequestDataVO> requestDataList = query.list();
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<DataSourceRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }

    return requestDataSet;

  }

  /**
   * Method to get valid request data for a particular scenario
   * 
   * @param scenario
   * @return
   */
  @Override
  public Set<CustomerRequestDataVO> getCustRequestDataForScenario(final Long scenarioId) {

    Session session = getSessionFactory().getCurrentSession();
    Set<CustomerRequestDataVO> requestDataSet = null;
    String queryString = Constants.CUSTOMERREQUESTDATAVO_QUERY + scenarioId + Constants.CLOSING_BRACES;
    Query query = session.createQuery(queryString);
    query.setFirstResult(0);
    query.setMaxResults(Constants.PAGESIZE);
    List<CustomerRequestDataVO> requestDataList = query.list();
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<CustomerRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }
    return requestDataSet;
  }

  @Override
  public Long getResultCountForCustomer(final Long scenarioId) {
    Session session = getSessionFactory().getCurrentSession();
    String countQ = Constants.CUSTOMERREQUESTDATAVO_COUNT_QUERY + scenarioId
      + Constants.CLOSING_BRACES;

    return (long) session.createQuery(countQ).uniqueResult();

  }

  @Override
  public Set<CustomerRequestDataVO> getCustRequestDataPagination(final Long scenarioId, final Long count, final int pageSize) {

    Session session = getSessionFactory().getCurrentSession();
    Set<CustomerRequestDataVO> requestDataSet = null;
    String queryString = Constants.CUSTOMERREQUESTDATAVO_QUERY + scenarioId + Constants.CLOSING_BRACES;
    Query query = session.createQuery(queryString);

    if (count > 1) {
      query.setFirstResult((int) ((count - 1) * pageSize));

    } else if (count == 1) {
      query.setFirstResult(0);

    }
    query.setMaxResults(pageSize);
    List<CustomerRequestDataVO> requestDataList = query.list();
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<CustomerRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }
    return requestDataSet;

  }

  /**
   * Method to get the data source by id
   * 
   * @param dataSourceId
   * @return
   */
  @Override
  public DataSourceVO getDataSourceById(final Long dataSourceId) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(DataSourceVO.class);
    hibCriteria.add(Restrictions.eq(Constants.SOURCEID, dataSourceId));
    return (DataSourceVO) hibCriteria.uniqueResult();
  }

  /**
   * Method to get the customer by id
   * 
   * @param customerId
   * @return
   */
  @Override
  public CustomersVO getCustomerById(final Long customerId) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(CustomersVO.class);
    hibCriteria.add(Restrictions.eq(Constants.CUSTOMER_ID, customerId));
    return (CustomersVO) hibCriteria.uniqueResult();
  }

  @Override
  public List<DataSourceRequestDataVO> getRequestDataBySourceId(Long dataSourceId, boolean status, Long recordCount) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(DataSourceRequestDataVO.class);
    hibCriteria.add(Restrictions.eq(Constants.SOURCEID, dataSourceId));
    if (status) {
      hibCriteria.add(Restrictions.eq(Constants.REQ_SEND_STATUS, 0L));
    } else {
      hibCriteria.add(Restrictions.eq(Constants.STATUS, 1L));
      hibCriteria.add(Restrictions.isNotNull(Constants.RESPONSEUPDATEDDATE));
      hibCriteria.addOrder(Order.asc(Constants.RESPONSEUPDATEDDATE));
    }
    hibCriteria.setMaxResults(recordCount.intValue());

    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    return hibCriteria.list();
  }

  @Override
  public List<DataSourceScenarioVO> getAllDSScenario(Long sourceId) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(DataSourceScenarioVO.class);
    hibCriteria.add(Restrictions.eq(Constants.DATASOURCE_SOURCEID, sourceId));
    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    return hibCriteria.list();
  }

  @Override
  public void updateRequest(DataSourceRequestDataVO requestData) {
    getHibernateTemplate().saveOrUpdate(requestData);

  }

  @Override
  public void updateScenario(DataSourceScenarioVO scenario) {
    getHibernateTemplate().saveOrUpdate(scenario);

  }

  @Override
  public void deleteHeaders(Long dataSourceId) {
    Session session = getSessionFactory().getCurrentSession();
    session.createSQLQuery(Constants.DELETEQUERY + dataSourceId).executeUpdate();
  }

  @Override
  public void deleteCusHeaders(Long customerId) {
    Session session = getSessionFactory().getCurrentSession();
    session.createSQLQuery(Constants.DELETECUSQUERY + customerId).executeUpdate();
  }

  @Override
  public DataSourceScenarioVO getDSScenarioById(final Long scenarioId) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(DataSourceScenarioVO.class);
    hibCriteria.add(Restrictions.eq(Constants.SCENARIOID, scenarioId));
    DataSourceScenarioVO scenario = null;
    List<DataSourceScenarioVO> scenarioList = hibCriteria.list();
    if (null != scenarioList && !scenarioList.isEmpty()) {
      scenario = scenarioList.get(0);
    }
    return scenario;
  }

  @Override
  public CustomerScenarioVO getCustScenarioById(final Long scenarioId) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(CustomerScenarioVO.class);
    hibCriteria.add(Restrictions.eq(Constants.SCENARIOID, scenarioId));
    CustomerScenarioVO scenario = null;
    List<CustomerScenarioVO> scenarioList = hibCriteria.list();
    if (null != scenarioList && !scenarioList.isEmpty()) {
      scenario = scenarioList.get(0);
    }
    return scenario;
  }

  @Override
  public List<CustomerScenarioVO> getAllFilteredScenario(final String scenarioName, final Long sourceId, final String sourceType) {
    Session session = getSessionFactory().getCurrentSession();
    String hqlQuery = "";

    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      hqlQuery = Constants.FROM_DATASOURCESCENARIOVO;

      if (null != sourceId) {

        hqlQuery += Constants.WHERE_DATASOURCEVO_SOURCEID + sourceId;
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      hqlQuery = Constants.FROM_CUSTOMERSCENARIOVO;

      if (null != sourceId) {

        hqlQuery += Constants.WHERE_CUSTOMERSVO_CUSTOMERID + sourceId;
      }
    }
    if (null != scenarioName && !scenarioName.isEmpty()) {

      if (hqlQuery.contains(Constants.WHERE)) {
        hqlQuery += Constants.AND_LOWER_SCENARIONAME_LIKE + scenarioName.toLowerCase() + Constants.PERCENTAGE_WITH_SNGLE_QUOTES;

      } else {
        hqlQuery += Constants.WHERE_LOWER_SCENARIONAME_LIKE + scenarioName.toLowerCase() + Constants.PERCENTAGE_WITH_SNGLE_QUOTES;

      }
    }

    Query query = session.createQuery(hqlQuery);

    query.setFirstResult(0);
    query.setMaxResults(Constants.PAGESIZE);

    return query.list();
  }

  @Override
  public Long getAllFilteredCountForScenario(String scenarioName, Long sourceId, String sourceType) {
    Session session = getSessionFactory().getCurrentSession();
    String hqlQuery = "";
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      hqlQuery = Constants.FROM_DATASOURCESCENARIOVO;

      if (null != sourceId) {

        hqlQuery += Constants.WHERE_DATASOURCEVO_SOURCEID + sourceId;
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      hqlQuery = Constants.FROM_CUSTOMERSCENARIOVO;

      if (null != sourceId) {

        hqlQuery += Constants.WHERE_CUSTOMERSVO_CUSTOMERID + sourceId;
      }
    }
    if (null != scenarioName && !scenarioName.isEmpty()) {

      if (hqlQuery.contains(Constants.WHERE)) {
        hqlQuery += Constants.AND_LOWER_SCENARIONAME_LIKE + scenarioName.toLowerCase() + Constants.PERCENTAGE_WITH_SNGLE_QUOTES;

      } else {
        hqlQuery += Constants.WHERE_LOWER_SCENARIONAME_LIKE + scenarioName.toLowerCase() + Constants.PERCENTAGE_WITH_SNGLE_QUOTES;

      }
    }

    Query query = session.createQuery(hqlQuery);
    @SuppressWarnings("unchecked")
    List<CustomerScenarioVO> scenariosList = query.list();

    int size = scenariosList.size();
    return (long) size;
  }

  @Override
  public List getFilteredScenario(final String scenarioName, final Long sourceId, final String sourceType, final Long count) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = null;
    if (Constants.DATASOURCE_TYPE.equals(sourceType)) {
      hibCriteria = session.createCriteria(DataSourceScenarioVO.class);
      if (null != sourceId) {
        hibCriteria.add(Restrictions.eq(Constants.DATASOURCE_SOURCEID, sourceId));
      }
    } else if (Constants.CUSTOMER_TYPE.equals(sourceType)) {
      hibCriteria = session.createCriteria(CustomerScenarioVO.class);
      if (null != sourceId) {
        hibCriteria.add(Restrictions.eq(Constants.CUSTOMERVO_COUSTOMERID, sourceId));
      }
    }
    if (null != scenarioName && !scenarioName.isEmpty()) {
      hibCriteria.add(Restrictions.ilike(Constants.SCENARIONAME, scenarioName, MatchMode.ANYWHERE));
    }

    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    hibCriteria.setFirstResult((int) ((count - 1) * Constants.PAGESIZE));
    hibCriteria.setMaxResults(Constants.PAGESIZE);
    return hibCriteria.list();
  }

  /**
   * Method to save  data
   * 
   * @param object
   */
  @Override
  public void save(final Object entity) {
    getHibernateTemplate().save(entity);
  }

  /**
   * Method to update data in db
   * @param object
   */
  @Override
  public void update(Object entity) {
    getHibernateTemplate().saveOrUpdate(entity);
  }

  @Override
  public void mergeEntity(Object entity) {
    getHibernateTemplate().merge(entity);
  }

  @Override
  public long getDataSourceRequestCount(Long sourceId) {
    Session session = getSessionFactory().getCurrentSession();

    String query = Constants.DATASOURCE_REQUEST_COUNT_QUERY + sourceId;
    return (long) session.createQuery(query).uniqueResult();
  }

  @Override
  public List<CustomersVO> getNoRequestCustomers(Long sourceId) {
    Session session = getSessionFactory().getCurrentSession();
    String query = Constants.NO_REQUEST_CUSTOMER_QUERY_PART1 + sourceId + Constants.CLOSING_BRACES + Constants.CLOSING_BRACES
      + Constants.NO_REQUEST_CUSTOMER_QUERY_PART2 + sourceId;
    return session.createQuery(query).list();
  }

  @Override
  public List<BasicInfoVO> getBasicInfoList(Long sourceId, Long maxrequestperDay, Long status) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(BasicInfoVO.class);
    hibCriteria.add(Restrictions.eq(Constants.SOURCEID, sourceId));
    hibCriteria.add(Restrictions.eq(Constants.STATUS, status));
    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    hibCriteria.setMaxResults(maxrequestperDay.intValue());
    return hibCriteria.list();
  }

  @Override
  public List<CommercialInfoVO> getCommercialInfoList(Long sourceId, Long maxrequestperDay, Long status) {
    Session session = getSessionFactory().getCurrentSession();
    Query query = session.createQuery("from CommercialInfoVO where sourceId=:sourceId and status=:status");
    query.setParameter(Constants.SOURCE_ID, sourceId);
    query.setParameter(Constants.STATUS, status);
    query.setMaxResults(maxrequestperDay.intValue());
    return query.list();
  }

  @Override
  public void insertDataSourceRequest(List<Object> request) {

    DataSourceRequestDataVO datasourceRequestData = null;
    int count = 0;

    for (Object object : request) {

      datasourceRequestData = (DataSourceRequestDataVO) object;
      count++;
      getHibernateTemplate().saveOrUpdate(datasourceRequestData);

      if (count % Constants.BACH_INSERT_COUNT == 0) {
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
      }

    }

  }

  @Override
  public void insertCustomerRequest(List<Object> request) {

    CustomerRequestDataVO customerRequestData = null;
    int count = 0;

    for (Object object : request) {

      customerRequestData = (CustomerRequestDataVO) object;
      count++;
      getHibernateTemplate().saveOrUpdate(customerRequestData);
      if (count % Constants.BACH_INSERT_COUNT == 0) {
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
      }

    }

  }

  @Override
  public List<CustomerScenarioVO> getCustomerScenario(Long customerid) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(CustomerScenarioVO.class);
    hibCriteria.add(Restrictions.eq(Constants.CUSTOMERVO_COUSTOMERID, customerid));
    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    return hibCriteria.list();
  }

  @Override
  public void insertDSScenarioRequestmapping(Long scenarioId, Long requestId) {
    Session session = getSessionFactory().getCurrentSession();
    Query query = session.createSQLQuery(Constants.INSERT_DATASOURCE_SCENARIO_QUERY);
    query.setParameter(Constants.SCENARIOID, scenarioId);
    query.setParameter(Constants.REQUEST_ID, requestId);
    query.executeUpdate();

  }

  @Override
  public void insertCustScenarioRequestmapping(Long scenarioId, Long requestId) {
    Session session = getSessionFactory().getCurrentSession();
    Query query = session.createSQLQuery(Constants.INSERT_CUSTOMER_SCENARIO_QUERY);
    query.setParameter(Constants.SCENARIOID, scenarioId);
    query.setParameter(Constants.REQUEST_ID, requestId);
    query.executeUpdate();

  }

  @Override
  public void updateBasicInfo(List<BasicInfoVO> basicInfos) {

    int count = 0;

    for (BasicInfoVO basicInfoVO : basicInfos) {
      if (basicInfoVO.getStatus() != 1L) {
        basicInfoVO.setStatus(1L);
        count++;
        getHibernateTemplate().saveOrUpdate(basicInfoVO);
        if (count % Constants.BACH_INSERT_COUNT == 0) {
          getHibernateTemplate().flush();
          getHibernateTemplate().clear();
        }

      }

    }

  }

  @Override
  public List<CustomerRequestDataVO> getCustomerRequestDataByCustomerId(Long customerIdId, boolean status, Long recordCount) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(CustomerRequestDataVO.class);
    hibCriteria.add(Restrictions.eq(Constants.CUSTOMERID, customerIdId));
    if (status) {
      hibCriteria.add(Restrictions.eq(Constants.REQ_SEND_STATUS, 0L));
    } else {
      hibCriteria.add(Restrictions.eq(Constants.STATUS, 1L));
      hibCriteria.add(Restrictions.isNotNull(Constants.RESPONSEUPDATEDDATE));
      hibCriteria.addOrder(Order.asc(Constants.RESPONSEUPDATEDDATE));
    }
    hibCriteria.setMaxResults(recordCount.intValue());

    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    return hibCriteria.list();

  }

  @Override
  public List<CustomerScenarioVO> getFilteredScenarioByScenario(String scenarioName, String customerType) {

    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = null;
    if (Constants.CUSTOMER_TYPE.equals(customerType)) {
      hibCriteria = session.createCriteria(CustomerScenarioVO.class);
      if (null != scenarioName && !scenarioName.isEmpty()) {
        hibCriteria.add(Restrictions.ilike(Constants.SCENARIONAME, scenarioName, MatchMode.ANYWHERE));
      }

      hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    }
    hibCriteria.setFirstResult(0);
    hibCriteria.setMaxResults(Constants.PAGESIZE);
    hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

    return hibCriteria.list();
  }

  @Override
  public Set<CustomerRequestDataVO> getCustRequestData(List<Long> requestIds) {
    Session session = getSessionFactory().getCurrentSession();
    Set<CustomerRequestDataVO> requestDataSet = null;

    String queryString = Constants.CUSTOMERREQUESTDATAVO_REQUESTIDLIST_QUERY;
    Query query = session.createQuery(queryString);
    query.setParameterList(Constants.REQUEST_IDS, requestIds);
    query.setLong(Constants.STATUS, 1L);
    query.setLong(Constants.REQ_SEND_STATUS, 1L);

    List<CustomerRequestDataVO> requestDataList = query.list();

    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<CustomerRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }
    return requestDataSet;
  }

  @Override
  public Set<DataSourceRequestDataVO> getDSRequestData(List<Long> requestIds) {
    Session session = getSessionFactory().getCurrentSession();
    Set<DataSourceRequestDataVO> requestDataSet = null;

    StringBuilder sb = new StringBuilder();
    for (Long id : requestIds) {
      sb.append(id + ",");
    }
    String queryString = Constants.DATASOURCEREQUESTDATAVO_REQUESTIDLIST_QUERY;
    Query query = session.createQuery(queryString);
    query.setParameterList(Constants.REQUEST_IDS, requestIds);
    query.setLong(Constants.STATUS, 1L);
    query.setLong(Constants.REQ_SEND_STATUS, 1L);
    List<DataSourceRequestDataVO> requestDataList = query.list();
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<DataSourceRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }
    return requestDataSet;
  }

  @Override
  public void bulkInsert(List<Object> entities) {
    int count = 0;

    for (Object entity : entities) {
      count++;
      getHibernateTemplate().saveOrUpdate(entity);
      if (count % Constants.BACH_INSERT_COUNT == 0) {
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
      }

    }
  }

  @Override
  public List<DataSourceVO> getAllDataSourceByQuery() {
    Session session = getSessionFactory().getCurrentSession();
    String query = Constants.FROM_DATASOURCEVO;
    return session.createQuery(query).list();
  }

  @Override
  public List<CustomerScenarioVO> getFilteredScenarioByPage(String scenarioName, String customerType, Long count) {

    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = null;
    if (Constants.CUSTOMER_TYPE.equals(customerType)) {
      hibCriteria = session.createCriteria(CustomerScenarioVO.class);
      if (null != scenarioName && !scenarioName.isEmpty()) {
        hibCriteria.add(Restrictions.ilike(Constants.SCENARIONAME, scenarioName, MatchMode.ANYWHERE));
      }

      hibCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
    }
    hibCriteria.setFirstResult((int) ((count - 1) * Constants.PAGESIZE));
    hibCriteria.setMaxResults(Constants.PAGESIZE);
    return hibCriteria.list();
  }

  @Override
  public Set<DataSourceRequestDataVO> getDSRequestEntriesForScenario(Long scenarioId, int pageSize) {

    Session session = getSessionFactory().getCurrentSession();
    Set<DataSourceRequestDataVO> requestDataSet = null;

    String queryString = Constants.DATASOURCEREQUESTDATAVO_QUERY + scenarioId + Constants.CLOSING_BRACES;
    Query query = session.createQuery(queryString);
    query.setFirstResult(0);
    query.setMaxResults(pageSize);
    List<DataSourceRequestDataVO> requestDataList = query.list();
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<DataSourceRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }
    return requestDataSet;

  }

  @Override
  public Set<CustomerRequestDataVO> getCustRequestEntriesForScenario(Long scenarioId, int pageSize) {

    Session session = getSessionFactory().getCurrentSession();
    Set<CustomerRequestDataVO> requestDataSet = null;
    String queryString = Constants.CUSTOMERREQUESTDATAVO_QUERY + scenarioId + Constants.CLOSING_BRACES;
    Query query = session.createQuery(queryString);
    query.setFirstResult(0);
    query.setMaxResults(pageSize);
    List<CustomerRequestDataVO> requestDataList = query.list();
    if (null != requestDataList && !requestDataList.isEmpty()) {
      requestDataSet = new HashSet<CustomerRequestDataVO>();
      requestDataSet.addAll(requestDataList);
    }
    return requestDataSet;
  }

  @Override
  public void bulkInsertOfBasicInfo(List<Object> entities) {
    int count = 0;

    for (Object entity : entities) {
      count++;
      getHibernateTemplate().saveOrUpdate(entity);
      if (count % Constants.BACH_INSERT_COUNT == 0) {
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
      }

    }
  }

  @Override
  public DataSourceVO getDataSourceVOById(Long sourceId) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(DataSourceVO.class);
    hibCriteria.add(Restrictions.eq(Constants.SOURCEID, sourceId));
    return (DataSourceVO) hibCriteria.uniqueResult();
  }

  @Override
  public CustomersVO getCustomerVOById(Long customerId) {
    Session session = getSessionFactory().getCurrentSession();
    Criteria hibCriteria = session.createCriteria(CustomersVO.class);
    hibCriteria.add(Restrictions.eq(Constants.CUSTOMER_ID, customerId));
    return (CustomersVO) hibCriteria.uniqueResult();
  }

  /**
   * Method to delete customer scenario and request mapping from database
   * @param scenarioId
   */
  public void deleteCustScenarioMapping(Long scenarioId) {
    Session session = getSessionFactory().getCurrentSession();
    session.createSQLQuery(Constants.DELETE_CUST_MAPPING_QUERY + scenarioId).executeUpdate();
  }

  /**
   * Method to delete datasource scenario and request mapping from database
   * @param scenarioId
   */
  public void deleteDSScenarioMapping(Long scenarioId) {
    Session session = getSessionFactory().getCurrentSession();
    session.createSQLQuery(Constants.DELETE_DS_MAPPING_QUERY + scenarioId).executeUpdate();
  }

  @Override
  public void updateInfo(List basicInfos) {

    int count = 0;
    for (Object object : basicInfos) {
      if (object instanceof BasicInfoVO) {
        BasicInfoVO basicInfoVO = (BasicInfoVO) object;
        if (basicInfoVO.getStatus() != 1L) {
          basicInfoVO.setStatus(1L);
          count++;
          getHibernateTemplate().saveOrUpdate(basicInfoVO);
        }
      } else if (object instanceof CommercialInfoVO) {
        CommercialInfoVO commercialInfoVO = (CommercialInfoVO) object;
        if (commercialInfoVO.getStatus() != 1L) {
          commercialInfoVO.setStatus(1L);
          count++;
          getHibernateTemplate().saveOrUpdate(commercialInfoVO);
        }
      }
      if (count % Constants.BACH_INSERT_COUNT == 0) {
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
      }
    }

  }

  /**
   * Method to delete customer scenario request mapping from database by requestId
   * @param requests
   */
  public void delCustScenarioMapping(List requests) {
    Session session = getSessionFactory().getCurrentSession();
    for (Object req : requests) {
      CustomerRequestDataVO customerRequestDataVO = (CustomerRequestDataVO) req;
      session.createSQLQuery(Constants.DEL_CUST_MAPPING_QUERY + customerRequestDataVO.getRequestId()).executeUpdate();
    }
  }

  /**
   * Method to delete datasource scenario request mapping from database by requestId
   * @param requests
   */
  public void delDSScenarioMapping(List requests) {
    Session session = getSessionFactory().getCurrentSession();
    for (Object object : requests) {
      DataSourceRequestDataVO dataSourceRequestDataVO = (DataSourceRequestDataVO) object;
      session.createSQLQuery(Constants.DEL_DS_MAPPING_QUERY + dataSourceRequestDataVO.getRequestId()).executeUpdate();
    }

  }
  
	/**
	 * Method to save the user-login details
	 * 
	 * @param requests
	 */
	@Override
	public void saveAuditLog(final AuditLogVO auditlog) {
		Session session = getSessionFactory().getCurrentSession();
		session.save(auditlog);
	}

}
