package com.business.world.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.business.world.dao.IDatabaseAccess;
import com.business.world.entity.EmployeeEntity;
import com.business.world.util.ExcelHandler;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IDatabaseAccess daoAccess;

	@Override
	public String createEmployee(EmployeeEntity emp){
		return daoAccess.createEmployee(emp);
	}
	
	@Override
	public String insertFromExcel(String employeeId) throws Exception {
		String searchedId = null;
		List<EmployeeEntity> emp = fetchFromExcel(employeeId);
		// System.out.println("--------singleEmpList----" + singleEmpList);

		if (!(emp.isEmpty())) {
			EmployeeEntity singleEmp = emp.get(0);
			if (singleEmp != null) {
				System.out
						.println("Getting into Database to insert new Record");
				searchedId = daoAccess.createEmployee(singleEmp);
			}
		} else {
			System.out.print("Employee to be created does not exist in excel");
			throw new Exception("Cannot find any record with ID-[ "
					+ employeeId + " ] in Excel");
		}
		return searchedId;
	}

	
	
	public List<EmployeeEntity> insertAllFromExcel(){
		List<EmployeeEntity> emp = ExcelHandler.readExcel();
		return emp;
	}
	
	@Override
	public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception {
		return daoAccess.createEmployee(empList);
	}

	@Override
	public List<EmployeeEntity> fetchFromExcel(String employeeId)
			throws Exception {
		List<EmployeeEntity> emp = ExcelHandler.readRow(employeeId);
		List<EmployeeEntity> singleEmpList = emp.stream()
				.filter(x -> x.getEmployeeId().equalsIgnoreCase(employeeId))
				.collect(Collectors.toList());
		System.out.println("--------singleEmpList----" + emp);

		return singleEmpList;
	}
	@Override
	public List<EmployeeEntity> getEmployeeById(String employeeId) {
		List<EmployeeEntity> empObj = daoAccess.getEmployeeById(employeeId);
		return empObj;
	}
	
	@Override
	public List<EmployeeEntity> getAllEmployees() {
		List<EmployeeEntity> empList = daoAccess.getAllEmployees();
		return empList;
	}
	@Override
	public String deleteEmployee(String employeeId) throws Exception {
		return daoAccess.deleteEmployee(employeeId);

	}

	@Override
	public String updateEmployee(EmployeeEntity emp)
			throws Exception {
		return daoAccess.updateEmployee(emp);
	}

	

	
/*
	

	@Override
	public List<EmployeeEntity> fetchFromExcel(String id) throws Exception {
		List<EmployeeEntity> emp = ExcelHandler.readRow();
		List<EmployeeEntity> singleEmpList = emp.stream()
				.filter(x -> x.getEmployeeId().equalsIgnoreCase(id))
				.collect(Collectors.toList());
		System.out.println("--------singleEmpList----" + singleEmpList);
		return singleEmpList;
	}*/
}
