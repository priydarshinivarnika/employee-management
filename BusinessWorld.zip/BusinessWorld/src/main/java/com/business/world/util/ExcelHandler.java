package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;

public class ExcelHandler {

	public static List<EmployeeEntity> readRow(String employeeId) {
		EmployeeEntity entityList = null;
		ArrayList<EmployeeEntity> employeeList = new ArrayList<EmployeeEntity>();
		try {
			FileInputStream file = new FileInputStream(new File(
					"src/main/resources/EmployeeList.xlsx"));

			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// I've Header and I'm ignoring header for that I've +1 in loop
			for (int i = sheet.getFirstRowNum() + 1; i <= sheet.getLastRowNum(); i++) {
				Row ro = sheet.getRow(i);

				int j = ro.getFirstCellNum();
				if (ro.getCell(j).getStringCellValue().equals(employeeId)) {
					EmployeeEntity e = new EmployeeEntity();
					AddressEntity a = new AddressEntity();
					Cell ce = ro.getCell(j++);
					e.setEmployeeId(ce.getStringCellValue());

					ce = ro.getCell(j++);
					e.setFirstName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					e.setLastName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					e.setSalary((int) ce.getNumericCellValue());
					ce = ro.getCell(j++);
					a.setAddressType(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setCityName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setHouseNumber((int) ce.getNumericCellValue());
					ce = ro.getCell(j++);
					a.setStreetName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setStreetType(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setTelephoneNumber((long) ce.getNumericCellValue());
					ce = ro.getCell(j++);
					a.setZipCode((int) ce.getNumericCellValue());
					
					e.setAddress(a);
					employeeList.add(e);
					break;
					}
				
				
			}file.close();

			// ----Reads all the data in excel---------
			/*
			 * for (EmployeeEntity emp : employeeList) {
			 * System.out.println("ID:" + emp.getEmployeeId() + " firstName:" +
			 * emp.getFirstName() + " lastName:" + emp.getLastName() +
			 * " salary:" + emp.getSalary() + emp.getAddress().toString() +
			 * "\n"); entityList = emp; }
			 */

		} catch (Exception e) {
			System.out.println("Incorrect Datatype for the field");
			e.printStackTrace();
		}
		return employeeList;
	}
	
	/*public static String writeRow(List<EmployeeEntity> empList) {
		// String excelFilePath = "src/main/resources/EmployeeList.xlsx";
		String excelResponse;
		try {
			FileInputStream inputStream = new FileInputStream(new File(
					"src/main/resources/EmployeeList.xlsx"));
			Workbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
			int rowCount = sheet.getLastRowNum();
			for (EmployeeEntity emp : empList) {

				Row row = sheet.createRow(++rowCount);
				int columnCount = 0;
				Cell cell = row.createCell(columnCount);
				cell.setCellValue(rowCount);
				for (Object field : emp) {
					cell = row.createCell(++columnCount);
					if (field instanceof String) {
						cell.setCellValue((String) field);
					} else if (field instanceof Integer) {
						cell.setCellValue((Integer) field);
					}
				}
			}
			inputStream.close();
			FileOutputStream outputStream = new FileOutputStream(
					"src/main/resources/EmployeeList.xlsx");

			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
			excelResponse = "Record inserted successfully in Excel.";
		} catch (Exception e) {
			e.printStackTrace();
			excelResponse = "Record already Exist in excel";

		}
		return excelResponse;
	}*/
	
	public static void removeRow(HSSFSheet sheet, int rowIndex) {
		
		int lastRowNum=sheet.getLastRowNum();
	    if(rowIndex>=0&&rowIndex<lastRowNum){
	        sheet.shiftRows(rowIndex+1,lastRowNum, -1);
	    }
	    if(rowIndex==lastRowNum){
	        HSSFRow removingRow=sheet.getRow(rowIndex);
	        if(removingRow!=null){
	            sheet.removeRow(removingRow);
	        }
	    }
	}
	
	
	public static List<EmployeeEntity> readExcel() {
		ArrayList<EmployeeEntity> employeeList = new ArrayList<EmployeeEntity>();
		try {
			FileInputStream file = new FileInputStream(new File(
					"src/main/resources/EmployeeList.xlsx"));

			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);

			for (int i = sheet.getFirstRowNum() + 1; i <= sheet.getLastRowNum(); i++) {
				EmployeeEntity e = new EmployeeEntity();
				AddressEntity a = new AddressEntity();
				Row ro = sheet.getRow(i);
				for (int j = ro.getFirstCellNum(); j <= ro.getLastCellNum(); j++) {
					Cell ce = ro.getCell(j);
					if (j == 0) {
						((EmployeeEntity) e).setEmployeeId(ce
								.getStringCellValue());
					}
					if (j == 1) {
						((EmployeeEntity) e).setFirstName(ce
								.getStringCellValue());
					}

					if (j == 2) {
						((EmployeeEntity) e).setLastName(ce
								.getStringCellValue());
					}

					if (j == 3) {
						((EmployeeEntity) e).setSalary((int) ce
								.getNumericCellValue());
					}
					if (j == 4) {
						((AddressEntity) a).setAddressType(ce
								.getStringCellValue());
					}
					if (j == 5) {
						((AddressEntity) a)
								.setCityName(ce.getStringCellValue());
					}
					if (j == 6) {
						((AddressEntity) a).setHouseNumber((int) ce
								.getNumericCellValue());
					}
					if (j == 7) {
						((AddressEntity) a).setStreetName(ce
								.getStringCellValue());
					}
					if (j == 8) {
						((AddressEntity) a).setStreetType(ce
								.getStringCellValue());
					}
					if (j == 9) {
						((AddressEntity) a).setTelephoneNumber((long) ce
								.getNumericCellValue());
					}
					if (j == 10) {
						((AddressEntity) a).setZipCode((int) ce
								.getNumericCellValue());
					}
				}
				e.setAddress(a);
				employeeList.add(e);

				file.close();
			}

		} catch (Exception e) {
			System.out.println("Incorrect Datatype for the field");
			e.printStackTrace();
		}
		return employeeList;
	}
	
	    	
}
