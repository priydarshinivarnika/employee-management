package com.business.world.domain;

import java.util.Scanner;

public class ReverseString implements Runnable {
	int count = 0;
	int[] buffer = new int[10];

	public static void main(String[] args) {
		// reverse();
		Runnable test = () -> System.out.println("Hello world!"
				+ Thread.currentThread().isInterrupted());
		Thread t1 = new Thread(test);
		t1.start();
		t1.interrupt();
	}

	public static void reverse() {
		System.out.println("Enter the string to reverse");
		Scanner read = new Scanner(System.in);
		String st = read.nextLine();
		String reverse = "";
		for (int i = st.length() - 1; i >= 0; i--) {
			reverse = reverse + st.charAt(i);
		}
		System.out.println("Reverse string is: " + reverse);
	}

	@Override
	public void run() {
	}

	private Object lock;

	class Producer {
		public void produce() {
			synchronized (lock) {
				while (isFull(buffer)) {
				}
				buffer[count++] = 1;
			}
		}
	}

	private boolean isFull(int[] buffer) {

		return count == buffer.length;
	}

	class Consumer {
		public void consumer() {
			// synchronized (lock) {
			while (isEmpty(buffer)) {
			}
			buffer[--count] = 0;
		}
	}

	private boolean isEmpty(int[] buffer) {

		return count == 0;
	}

}