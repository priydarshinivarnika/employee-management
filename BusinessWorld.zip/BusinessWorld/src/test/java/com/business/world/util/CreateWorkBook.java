package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

public class CreateWorkBook {
	
	private String getFileExtension(String fileName) {
	    String extension = "";
	    int mid = fileName.lastIndexOf(".");
	    extension = fileName.substring(mid + 1, fileName.length());
	    return extension;
	  }
	private Workbook getWorkBook(String fileName, InputStream stream) {
		Workbook workBook = null;
		String fileType = getFileExtension(fileName);
		try {
			if ("xls".equalsIgnoreCase(fileType)) {
				workBook = new HSSFWorkbook(stream);
			} else if ("xlsx".equalsIgnoreCase(fileType)) {
				workBook = new XSSFWorkbook(stream);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return workBook;
	}
	//@Test
	public void createExcel() throws Exception {
		XSSFWorkbook workbook = new XSSFWorkbook();
		/*XSSFSheet spreadsheet = workbook.createSheet(" Employee Info ");*/
		/*
		 * XSSFSheet spreadsheet1 = workbook.createSheet(" Organization Info ");
		 * XSSFSheet spreadSheet2 = workbook.createSheet("Client Info");
		 */

		/*XSSFRow row;
		Map<String, Object[]> empinfo = new TreeMap<String, Object[]>();
		empinfo.put("1", new Object[] { "EMP ID", "EMP NAME", "DESIGNATION" });
		empinfo.put("2", new Object[] { "tp01", "Gopal", "Technical Manager" });
		empinfo.put("3", new Object[] { "tp02", "Manisha", "Proof Reader" });
		empinfo.put("4", new Object[] { "tp03", "Masthan", "Technical Writer" });
		empinfo.put("5", new Object[] { "tp04", "Satish", "Technical Writer" });
		empinfo.put("6", new Object[] { "tp05", "Krishna", "Technical Writer" });

		Set<String> keyid = empinfo.keySet();
		System.out.println("  KeyId " + keyid);
		int rowid = 0;
		for (String key : keyid) {
			row = spreadsheet.createRow(rowid++);
			Object[] objectArr = empinfo.get(key);
			int cellid = 0;
			for (Object obj : objectArr) {
				Cell cell = row.createCell(cellid++);
				cell.setCellValue((String) obj);
			}
		}*/

		FileOutputStream out = new FileOutputStream(new File("Excelsheet.xlsx"));
		workbook.write(out);
		out.close();
		System.out.println("Excelsheet.xlsx written successfully");
	}

	@Test
	public void accessExcel() throws Exception{
		Class.forName("org.postgresql.Driver");
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "admin");
		Statement statement = connect.createStatement();
		ResultSet resultSetEmployee = statement
				.executeQuery("select * from employee");
		File file = new File("Excelsheet.xlsx");

		if (file.isFile() && file.exists()) {
			System.out.println("Excelsheet.xlsx file open successfully.");
		} else {
			System.out.println("File not found within the project exception");
		}
		FileInputStream fIP = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(fIP);
		//XSSFSheet spreadsheet = workbook.createSheet(" Employee DB ");
		XSSFSheet spreadsheet = workbook.getSheetAt(0);
		
		for(int i = spreadsheet.getFirstRowNum(); i<= spreadsheet.getLastRowNum(); i++){
			Row row = spreadsheet.getRow(i);
			for (int j = row.getFirstCellNum(); j<= row.getLastCellNum(); j++){
				XSSFCell cell;
		
		cell = row.createCell(j);
		cell.setCellValue("employee_id");
		cell = row.createCell(2);
		cell.setCellValue("first_name");
		cell = row.createCell(3);
		cell.setCellValue("last_name");
		cell = row.createCell(4);
		cell.setCellValue("salary");
		cell = row.createCell(5);
		cell.setCellValue("address_type");
		cell = row.createCell(6);
		cell.setCellValue("city_name");
		cell = row.createCell(7);
		cell.setCellValue("house_number");
		cell = row.createCell(8);
		cell.setCellValue("street_name");
		cell = row.createCell(9);
		cell.setCellValue("street_type");
		cell = row.createCell(10);
		cell.setCellValue("telephone_number");
		cell = row.createCell(11);
		cell.setCellValue("zip_code");
		int i = 2;}
/*
		while (resultSetEmployee.next()) {
			row = spreadsheet.createRow(i);
			cell = row.createCell(1);
			cell.setCellValue(resultSetEmployee.getString("employee_id"));
			cell = row.createCell(2);
			cell.setCellValue(resultSetEmployee.getString("first_name"));
			cell = row.createCell(3);
			cell.setCellValue(resultSetEmployee.getString("last_name"));
			cell = row.createCell(4);
			cell.setCellValue(resultSetEmployee.getInt("salary"));
			cell = row.createCell(5);
			cell.setCellValue(resultSetEmployee.getString("address_type"));
			cell = row.createCell(6);
			cell.setCellValue(resultSetEmployee.getString("city_name"));
			cell = row.createCell(7);
			cell.setCellValue(resultSetEmployee.getInt("house_number"));
			cell = row.createCell(8);
			cell.setCellValue(resultSetEmployee.getString("street_name"));
			cell = row.createCell(9);
			cell.setCellValue(resultSetEmployee.getString("street_type"));
			cell = row.createCell(10);
			cell.setCellValue(resultSetEmployee.getInt("telephone_number"));
			cell = row.createCell(11);
			cell.setCellValue(resultSetEmployee.getInt("zip_code"));
			i++;
		}*/
}
		FileOutputStream out = new FileOutputStream(new File("Excelsheet.xlsx"));
		workbook.write(out);
		out.close();
		System.out.println("Excelsheet.xlsx written successfully");

		/*
		 * Set < String > keyid = resultSetEmployee.keySet(); int rowid = 0;
		 * 
		 * for (String key : keyid) { row = spreadsheet.createRow(rowid++);
		 * Object [] objectArr = empinfo.get(key); int cellid = 0;
		 * 
		 * for (Object obj : objectArr) { Cell cell = row.createCell(cellid++);
		 * cell.setCellValue((String)obj); } }
		 */
	}
}
