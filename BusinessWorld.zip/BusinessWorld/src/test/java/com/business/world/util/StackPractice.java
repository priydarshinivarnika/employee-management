package com.business.world.util;

public class StackPractice {

	int size;
	int index;
	char[] v;

	boolean isEmpty() {
		return (index < 0);
	}

	StackPractice(int n) {
		index = -1;
		size = n;
		v = new char[size];
	}

	boolean push(char x) {
		if (index >= size) {
			System.out.println("Stack Overflow");
			return false;
		} else {
			v[++index] = x;
			return true;
		}
	}

	char pop() {
		if (index < 0) {
			System.out.println("Stack Underflow");
			return 0;
		} else {
			char x = v[index--];
			return x;
		}
	}

}
