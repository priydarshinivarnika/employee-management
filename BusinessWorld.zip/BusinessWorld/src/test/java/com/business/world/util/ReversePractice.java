package com.business.world.util;

import java.util.Scanner;

public class ReversePractice {

	public static void main(String args[]) {

		System.out.println("Enter your Input: ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		StringBuffer sb = new StringBuffer(input);

		reverseInput(sb);

		// print the reversed string
		System.out.println("Reversed string is [" + sb + "]");
	}

	public static void reverseInput(StringBuffer str) {
		int n = str.length();
		StackPractice obj = new StackPractice(n);
		int i;
		for (i = 0; i < n; i++) {

			obj.push(str.charAt(i));
		}
		for (i = 0; i < n; i++) {
			char ch = obj.pop();
			str.setCharAt(i, ch);
		}

	}

}
