package com.equifax.datoz.controller;

/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.equifax.datoz.constants.Constants;
import com.equifax.datoz.domain.CustomerDetails;
import com.equifax.datoz.domain.Customers;
import com.equifax.datoz.domain.DataSource;
import com.equifax.datoz.domain.DataSourceDetails;
import com.equifax.datoz.domain.RequestData;
import com.equifax.datoz.domain.Scenario;
import com.equifax.datoz.exception.FileUploadException;
import com.equifax.datoz.handler.AdditionalDetailsHandler;
import com.equifax.datoz.handler.ExcelReader;
import com.equifax.datoz.handler.FileHandler;
import com.equifax.datoz.handler.JsonFieldHandler;
import com.equifax.datoz.handler.XmlFieldHandler;
import com.equifax.datoz.scheduler.DataManagementTasklet;
import com.equifax.datoz.service.IDataManagementService;
import com.equifax.datoz.util.ReplaceRequestSchema;
import com.equifax.datoz.view.ExcelReportView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@RestController
public class DataManagementController {

	/**
	 * logger
	 */
	private static final Logger LOGGER = Logger
			.getLogger(DataManagementController.class);

	@Autowired
	private IDataManagementService dataService;

	@Autowired
	private ReplaceRequestSchema replaceSchema;

	/**
	 * Main page
	 * 
	 * @return
	 */
	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public ModelAndView getData() {
		LOGGER.info("Entered DataManagementController.getData()");
		return new ModelAndView("Template");

	}

	/**
	 * 
	 * @param jsonRequest
	 * @param header
	 * @return
	 */

	@RequestMapping(value = "/sendRequest", method = RequestMethod.POST, consumes = "application/vnd.com.equifax.ic.saas.request.v1+json", produces = "application/vnd.com.equifax.ic.saas.response.v1+json")
	public String sendRequest(
			@RequestBody(required = true) final String jsonRequest,
			@RequestHeader final Map<String, String> header) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setAll(header);
		HttpEntity httpEntity = new HttpEntity(jsonRequest, httpHeaders);
		ResponseEntity response = restTemplate
				.exchange(
						"http://dfw-icsaas-client-qa.nonprod.edc.equifax.com/ic-saas-client/api",
						HttpMethod.POST, httpEntity, String.class);
		return response.getBody().toString();
	}

	/**
	 * displaying data sources in scenario list displaying page
	 * 
	 * @return
	 */
	@RequestMapping(value = "/redirectScenario", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE }, headers = "Accept=application/json")
	@ResponseBody
	public ModelAndView redirectScenario() {
		ModelAndView modelandView = new ModelAndView("ScenarioList");

		List<DataSource> dataSources = dataService.getAllDataSource();
		modelandView.addObject(Constants.DATASOURCES, dataSources);

		return modelandView;
	}

	/**
	 * listing all customers
	 * 
	 * @param dataSourceId
	 * @return
	 */
	@RequestMapping(value = "/getCustomerList", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public Map<Long, String> getCustomerList(
			@RequestParam(value = "id") final long dataSourceId) {

		Map<Long, String> customerMap = new HashMap<Long, String>();
		List<Customers> customers = dataService
				.getAllCustomerBySource(dataSourceId);
		if (customers != null) {
			for (Customers cus : customers) {
				customerMap.put(cus.getCustomerid(), cus.getName());

			}
		}
		return customerMap;
	}

	/**
	 * listing all scenarios
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getAllScenario", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE }, headers = "Accept=application/json")
	@ResponseBody
	public List<Scenario> getAllScenario() {
		return dataService.getAllScenario();
	}

	/**
	 * listing all datasources
	 * 
	 * @return
	 */
	@RequestMapping(value = "/navDataSource", method = RequestMethod.GET)
	public ModelAndView navDataSource() {
		ModelAndView modelandView = new ModelAndView("DataSource");
		List<DataSource> dataSourceList = dataService.getAllDataSource();
		modelandView.addObject(Constants.DATASOURCES, dataSourceList);
		return modelandView;
	}

	/**
	 * displaying matched request and responses
	 * 
	 * @param scenarioId
	 * @param sourceId
	 * @param sourceType
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/navRequestData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ModelAndView navRequestData(
			@RequestParam(value = "id") final Long scenarioId,
			@RequestParam(value = "sourceId") final Long sourceId,
			@RequestParam(value = "sourceType") final String sourceType,
			HttpServletRequest request) {
		ModelAndView model;
		Long count = dataService.getResultCountForResponses(
				Long.valueOf(scenarioId), sourceType.trim());
		Set<RequestData> requestDatas = null;
		requestDatas = dataService.getDataForScenario(Long.valueOf(scenarioId),
				Long.valueOf(sourceId), sourceType.trim());
		if (null != requestDatas && !requestDatas.isEmpty()) {
			model = new ModelAndView("MatchedRequest");
			model.addObject(Constants.SCENARIO_ID, scenarioId);
			model.addObject(Constants.REQUEST_DATA_LIST, requestDatas);
			model.addObject(Constants.SOURCE_ID, sourceId);
			model.addObject(Constants.SOURCE_TYPE, sourceType);
			request.getSession().setAttribute(Constants.REQUEST_DATA_LIST,
					requestDatas);
		} else {
			model = new ModelAndView(Constants.SEARCH_SCENARIO_MESSAGE_PAGE);
		}
		model.addObject(Constants.TOTAL_RESULT_COUNT, count);
		return model;
	}

	/**
	 * pagination based on entries
	 * 
	 * @param pageSize
	 * @param scenarioId
	 * @param sourceId
	 * @param sourceType
	 * @return
	 */
	@RequestMapping(value = "/getEntries", method = RequestMethod.GET)
	@ResponseBody
	public Set<RequestData> getEntries(
			@RequestParam(value = "pageSize") final int pageSize,
			@RequestParam(value = "id") final Long scenarioId,
			@RequestParam(value = "sourceId") final Long sourceId,
			@RequestParam(value = "sourceType") final String sourceType) {
		Set<RequestData> requestDatas = null;
		requestDatas = dataService.getEntriesForScenario(pageSize,
				Long.valueOf(scenarioId), Long.valueOf(sourceId),
				sourceType.trim());
		return requestDatas;

	}

	/**
	 * implement pagination
	 */
	@RequestMapping(value = "/getPages", method = RequestMethod.GET)
	@ResponseBody
	public Set<RequestData> getPages(
			@RequestParam(value = "count") final long count,
			@RequestParam(value = "id") final Long scenarioId,
			@RequestParam(value = "sourceId") final Long sourceId,
			@RequestParam(value = "sourceType") final String sourceType,
			@RequestParam(value = "pageSize") final int pageSize,
			HttpServletRequest request) {

		Set<RequestData> requestDatas = null;

		requestDatas = dataService.getDataPagination(Long.valueOf(scenarioId),
				Long.valueOf(sourceId), sourceType.trim(), Long.valueOf(count),
				pageSize);

		request.getSession().setAttribute(Constants.REQUEST_DATA_LIST,
				requestDatas);

		return requestDatas;
	}

	/**
	 * calling model and displaying datasource for search scenario
	 * 
	 * @return
	 */
	@RequestMapping(value = "/navSearchScenario", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ModelAndView navSearchScenario() {
		ModelAndView modelandView = new ModelAndView("SearchScenario");
		List<DataSource> dataSourceList = dataService.getAllDataSource();
		modelandView.addObject(Constants.DATASOURCES, dataSourceList);
		return modelandView;
	}

	/**
	 * method for displaying form fields in data finder
	 */
	@RequestMapping(value = "/getSearchSchema", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ModelAndView getSearchSchema(
			@RequestParam(value = "id") final Long dataSourceId,
			@RequestParam(value = "datasource") final String dataSourceName) {

		DataSource ds = dataService.getDataSourceById(dataSourceId);
		List<Customers> cs = dataService.getAllCustomerBySource(ds
				.getSourceId());
		String schema = ds.getResponseSchema();
		String type = ds.getFormat();
		Set<String> resSchema = null;

		List<DataSource> dataSourceList = dataService.getAllDataSource();
		ModelAndView modelandView = new ModelAndView("SearchScenario");

		if (null != schema && !schema.isEmpty()) {
			if (type.equals(Constants.JSON)) {

				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);
			} else if (type.equals(Constants.XML)) {

				XmlFieldHandler field = new XmlFieldHandler();
				resSchema = field.getXml(schema);

			} else if (type.equals(Constants.FFF)) {
				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);
			}
		}
		modelandView.addObject(Constants.FORMFIELDS, resSchema);
		modelandView.addObject(Constants.DATASOURCES, dataSourceList);
		modelandView.addObject("dsId", dataSourceId);
		modelandView.addObject(Constants.CUSTOMERS, cs);
		modelandView.addObject(Constants.DSNAME, dataSourceName);
		return modelandView;

	}

	/**
	 * method for getting customer schema in search scenario
	 * 
	 * @param customerId
	 * @param dataSourceId
	 * @return
	 */

	@RequestMapping(value = "/getSearchCustomerSchema", method = RequestMethod.GET)
	@ResponseBody
	public Set<String> getSearchCustomerSchema(
			@RequestParam(value = "csid") final long customerId,
			@RequestParam(value = "id") final long dataSourceId) {

		Customers customer = dataService.getCustomerById(customerId);
		String schema = customer.getResponseSchema();
		String type = customer.getFormat();
		Set<String> resSchema = null;
		try {
			if (null != schema && !schema.isEmpty()) {
				if ("JSON".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);
				} else if ("XML".equals(type)) {

					XmlFieldHandler field = new XmlFieldHandler();
					resSchema = field.getXml(schema);

				} else if ("FFF".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);

				}

			} else {
				DataSource dataSource = dataService
						.getDataSourceById(dataSourceId);
				schema = dataSource.getResponseSchema();
				type = dataSource.getFormat();
				if ("JSON".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);
				} else if ("XML".equals(type)) {

					XmlFieldHandler field = new XmlFieldHandler();
					resSchema = field.getXml(schema);
				} else if ("FFF".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);

				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}

		return resSchema;
	}

	/**
	 * method to find matched request and response
	 * 
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "/searchRule", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView searchByRule(HttpServletRequest request) {

		String scenarioRule = request.getParameter("rule");
		String dataSourceId = request.getParameter(Constants.DATASOURCE_ID);
		String customerId = request.getParameter(Constants.CUSTOMERID);
		String description = request.getParameter(Constants.DESCRIPTION);
		String scenarioName = request.getParameter("name");
		Set<RequestData> modelSet = null;
		ModelAndView model = null;
		if (null != scenarioRule && !scenarioRule.isEmpty()
				&& null != dataSourceId && !dataSourceId.isEmpty()) {
			Scenario scenario = null;
			if (null == customerId || customerId.isEmpty()) {
				scenario = new Scenario(scenarioName, description,
						scenarioRule, Long.valueOf(dataSourceId),
						Constants.DATASOURCE_TYPE);
			} else {
				scenario = new Scenario(scenarioName, description,
						scenarioRule, Long.valueOf(customerId),
						Constants.CUSTOMER_TYPE);
			}
			modelSet = dataService.processScenario(scenario);
			if (null != modelSet && !modelSet.isEmpty()) {
				model = new ModelAndView(Constants.REQUEST_PAGE);
				model.addObject(Constants.REQUEST_DATA_LIST, modelSet);
				request.getSession().setAttribute(Constants.REQUEST_DATA_LIST,
						modelSet);
			} else {
				model = new ModelAndView(Constants.SEARCH_SCENARIO_MESSAGE_PAGE);
			}

		}
		return model;

	}

	/**
	 * method to navigate to add scenario page
	 * 
	 * @return
	 */

	@RequestMapping(value = "/navAddScenario", method = RequestMethod.GET)
	public ModelAndView navAddScenario() {

		ModelAndView modelandView = new ModelAndView(Constants.ADDSCENARIO_PAGE);
		List<DataSource> dataSourceList = dataService.getAllDataSource();
		modelandView.addObject(Constants.DATASOURCES, dataSourceList);
		return modelandView;

	}

	/**
	 * method to display form fields in add scenario
	 * 
	 * @param dataSourceId
	 * @param dataSourceName
	 * @return
	 */

	@RequestMapping(value = "/getAddFormField", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ModelAndView getAddFormField(
			@RequestParam(value = "id") final long dataSourceId,
			@RequestParam(value = "datasource") final String dataSourceName) {

		DataSource ds = dataService.getDataSourceById(dataSourceId);
		List<Customers> cs = dataService.getAllCustomerBySource(ds
				.getSourceId());
		String schema = ds.getResponseSchema();
		String type = ds.getFormat();
		ModelAndView modelandView = new ModelAndView(Constants.ADDSCENARIO_PAGE);
		Set<String> resSchema = null;
		List<DataSource> dataSourceList = dataService.getAllDataSource();
		if (null != schema && !schema.isEmpty()) {
			if (type.equals(Constants.JSON)) {

				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);
			} else if (type.equals(Constants.XML)) {
				XmlFieldHandler field = new XmlFieldHandler();
				resSchema = field.getXml(schema);
			} else if (type.equals(Constants.FFF)) {
				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);
			}
		}
		modelandView.addObject(Constants.DATASOURCES, dataSourceList);
		modelandView.addObject(Constants.CUSTOMERS, cs);
		modelandView.addObject(Constants.FORMFIELDS, resSchema);
		modelandView.addObject(Constants.DSNAME, dataSourceName);
		modelandView.addObject("dsId", dataSourceId);
		return modelandView;
	}

	/**
	 * method for getting customer form fields
	 * 
	 * @param customerId
	 * @param dataSourceId
	 * @return
	 */

	@RequestMapping(value = "/getCustomerFormField", method = RequestMethod.GET)
	@ResponseBody
	public Set<String> getCustomerFormField(
			@RequestParam(value = "csid") final long customerId,
			@RequestParam(value = "id") final long dataSourceId) {

		Customers customer = dataService.getCustomerById(customerId);
		String schema = customer.getResponseSchema();
		String type = customer.getFormat();
		Set<String> resSchema = null;
		try {
			if (null != schema && !schema.isEmpty()) {
				if ("JSON".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);
				} else if ("XML".equals(type)) {

					XmlFieldHandler field = new XmlFieldHandler();
					resSchema = field.getXml(schema);
				} else if ("FFF".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);

				}

			} else {
				DataSource dataSource = dataService
						.getDataSourceById(dataSourceId);
				schema = dataSource.getResponseSchema();
				type = dataSource.getFormat();
				if ("JSON".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);
				} else if ("XML".equals(type)) {

					XmlFieldHandler field = new XmlFieldHandler();
					resSchema = field.getXml(schema);
				} else if ("FFF".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);

				}

			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return resSchema;
	}

	/**
	 * Method called for adding scenario
	 * 
	 * @param rule
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/addScenario", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView addScenario(HttpServletRequest request) {
		String scenarioRule = request.getParameter("rule");
		String dataSourceId = request.getParameter(Constants.DATASOURCE_ID);
		String customerId = request.getParameter(Constants.CUSTOMERID);
		String description = request.getParameter(Constants.DESCRIPTION);
		String scenarioName = request.getParameter("name");
		Set modelSet = null;
		ModelAndView model = new ModelAndView(Constants.REQUEST_PAGE);
		Scenario scenario = null;

		if (null != scenarioRule && !scenarioRule.isEmpty()
				&& null != dataSourceId && !dataSourceId.isEmpty()) {
			if (null == customerId || customerId.isEmpty()) {
				scenario = new Scenario(scenarioName, description,
						scenarioRule, Long.valueOf(dataSourceId),
						Constants.DATASOURCE_TYPE);
			} else {
				scenario = new Scenario(scenarioName, description,
						scenarioRule, Long.valueOf(customerId),
						Constants.CUSTOMER_TYPE);
			}
			modelSet = dataService.processScenario(scenario);
			model.addObject(Constants.REQUEST_DATA_LIST, modelSet);
			final Scenario scenarioObject = scenario;
			final Set<RequestData> requestDatas = modelSet;
			new Thread(() -> {
				saveScenarioAsync(scenarioObject, requestDatas);
			}).start();

			request.getSession().setAttribute(Constants.REQUEST_DATA_LIST,
					modelSet);
		}
		return model;

	}

	/**
	 * download excel file
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */

	@RequestMapping(value = "/downloadExcel", method = RequestMethod.GET)
	public ModelAndView downloadExcel(HttpServletRequest request)
			throws IOException {
		Set<RequestData> requestDataSet = (Set<RequestData>) request
				.getSession().getAttribute(Constants.REQUEST_DATA_LIST);

		return new ModelAndView(new ExcelReportView(),
				Constants.REQUEST_DATA_LIST, requestDataSet);
	}

	/**
	 * naviagte to add datasource page
	 * 
	 * @return
	 */

	@RequestMapping(value = "/Add", method = RequestMethod.GET)
	public ModelAndView addSource() {

		return new ModelAndView("AddEditDataSource");

	}

	/**
	 * navigate to edit data source
	 * 
	 * @param dataSourceId
	 * @return
	 */

	@RequestMapping(value = "/Edit", method = RequestMethod.GET)
	public ModelAndView getaddEdit(
			@RequestParam(value = "id") final long dataSourceId) {
		ModelAndView model = new ModelAndView("AddEditDataSource");
		DataSource ds = dataService.getDataSourceById(dataSourceId);
		model.addObject(Constants.DATASOURCE_DATA, ds);
		return model;
	}

	/**
	 * method to add or edit data source
	 * 
	 * @param request
	 * @param file
	 * @return
	 */

	@RequestMapping(value = "/addEditDatasource", method = RequestMethod.POST)
	public ModelAndView addDatasource(HttpServletRequest request,
			@RequestParam("file") MultipartFile[] file) {
		Map<String, String> headerMap = new HashMap<String, String>();

		ModelAndView model = null;
		String[] keys = request.getParameterValues("headerkey");
		String[] values = request.getParameterValues("headervalue");

		if (null != keys && keys.length == values.length) {
			for (int index = 0; index < keys.length; index++) {
				headerMap.put(keys[index], values[index]);
			}
		}
		DataSource addNewsource = getDataSource(request, file, headerMap);
		dataService.saveDataSource(addNewsource);
		String schema = addNewsource.getResponseSchema();
		String type = addNewsource.getFormat();
		Set<String> resSchema = null;

		if (null != schema && !schema.isEmpty()) {
			if (type.equals(Constants.JSON)) {

				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);
			} else if (type.equals(Constants.XML)) {
				XmlFieldHandler field = new XmlFieldHandler();
				resSchema = field.getXml(schema);
			} else if (type.equals(Constants.FFF)) {
				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);

			}
		}
		model = new ModelAndView("addDetailDatasource");
		if (request.getParameter("sourceId") != null) {
			Map<String, String> addDetailMap = new Gson().fromJson(
					addNewsource.getAdditionalDetails(),
					new TypeToken<Map<String, String>>() {
					}.getType());
			model.addObject(Constants.MESSAGE, Constants.EDITED);
			model.addObject("addedDatasource", addNewsource);
			model.addObject(Constants.FORMFIELDS, resSchema);
			model.addObject("additionalDataMap", addDetailMap);

		} else {
			model.addObject(Constants.MESSAGE, "Added");
			model.addObject("addedDatasource", addNewsource);
			model.addObject(Constants.FORMFIELDS, resSchema);
		}
		return model;
	}

	/**
	 * method to set datasource object from request
	 * 
	 * @param request
	 * @param file
	 * @param headerMap
	 * @return
	 */

	private DataSource getDataSource(HttpServletRequest request,
			MultipartFile[] file, Map<String, String> headerMap) {
		String requestSchema = null;
		String responseSchema = null;
		String personalinfoSchema = null;
		String replacedRequestSchema = null;
		FileHandler filehandler = new FileHandler();

		requestSchema = filehandler.fileToString(file[Constants.ZERO]);
		responseSchema = filehandler.fileToString(file[Constants.ONE]);
		personalinfoSchema = filehandler.fileToString(file[Constants.TWO]);
		String format = request.getParameter(Constants.FORMAT).toUpperCase();

		DataSource addEditSource = editDataSource(request);
		addEditSource.setName(request.getParameter("datasourcename"));
		addEditSource.setDescription(request
				.getParameter(Constants.DESCRIPTION));
		addEditSource.setUrl(request.getParameter("url"));
		addEditSource.setFormat(request.getParameter(Constants.FORMAT)
				.toUpperCase());
		addEditSource.setUsername(request.getParameter("username"));
		addEditSource.setPassword(request.getParameter("password"));
		addEditSource.setMaxRequestPerDay(Long.valueOf(request
				.getParameter("maxrequest")));
		addEditSource.setTimeout(Long.valueOf(request.getParameter("timeout")));
		addEditSource.setSslDetails(setSSLDetails(request));
		addEditSource.setDatasourceType(request.getParameter("type"));

		if (null != requestSchema && !requestSchema.isEmpty()) {
			replacedRequestSchema = replaceRequestSchema(requestSchema, format,
					headerMap);
			addEditSource.setRequestSchema(replacedRequestSchema);
		}

		if (null != responseSchema && !responseSchema.isEmpty()) {
			addEditSource.setResponseSchema(responseSchema);
		}

		if (null != personalinfoSchema && !personalinfoSchema.isEmpty()) {
			addEditSource.setPersonalInfoSchema(personalinfoSchema);
		}
		addEditSource.setDataSourceDetails(setDSHeaderDetails(headerMap,
				addEditSource));
		return addEditSource;
	}

	/**
	 * @param request
	 * @param dataSource
	 * @param addEditSource
	 * @return
	 */
	private DataSource editDataSource(HttpServletRequest request) {
		DataSource addEditSource = new DataSource();
		DataSource dataSource = null;
		if (null != request.getParameter(Constants.SOURCE_ID)) {
			dataService.deleteHeaders(Long.valueOf(request
					.getParameter(Constants.SOURCE_ID)));
			addEditSource.setSourceId(Long.valueOf(request
					.getParameter(Constants.SOURCE_ID)));
			dataSource = dataService.getDataSourceById(Long.valueOf(request
					.getParameter(Constants.SOURCE_ID)));
			addEditSource.setAdditionalDetails(dataSource
					.getAdditionalDetails());
			addEditSource.setRequestSchema(dataSource.getRequestSchema());
			addEditSource.setResponseSchema(dataSource.getResponseSchema());
			addEditSource.setPersonalInfoSchema(dataSource
					.getPersonalInfoSchema());
		}
		return addEditSource;
	}

	/**
	 * @param headerMap
	 * @param addEditSource
	 * @return
	 */
	private Set<DataSourceDetails> setDSHeaderDetails(
			Map<String, String> headerMap, DataSource addEditSource) {
		Set<DataSourceDetails> dataSourceDetailsSet = new HashSet<DataSourceDetails>();

		for (Map.Entry entry : headerMap.entrySet()) {
			DataSourceDetails datasourcedetails = new DataSourceDetails();
			datasourcedetails.setDataSource(addEditSource);
			datasourcedetails.setHeaderName(entry.getKey().toString());
			datasourcedetails.setHeaderValue(entry.getValue().toString());
			dataSourceDetailsSet.add(datasourcedetails);

		}
		return dataSourceDetailsSet;
	}

	/**
	 * naviagte to add customer page
	 * 
	 * @return
	 */
	@RequestMapping(value = "/Addcus", method = RequestMethod.GET)
	public ModelAndView addCustomer() {
		ModelAndView model = new ModelAndView(Constants.ADD_EDIT_CUSTOMER_PAGE);
		List<DataSource> dataSourceList = dataService.getAllDataSource();
		model.addObject(Constants.DATASOURCES, dataSourceList);
		return model;
	}

	/**
	 * .......................method to select dataSource.....................
	 * 
	 * @param dataSourceId
	 * @param dataSourceName
	 * @return
	 */
	@RequestMapping(value = "/selectSource", method = RequestMethod.GET)
	public ModelAndView selectDataSource(
			@RequestParam(value = "id") final long dataSourceId,
			@RequestParam(value = "datasource") final String dataSourceName) {
		DataSource ds = dataService.getDataSourceById(dataSourceId);
		List<DataSource> dataSourceList = dataService.getAllDataSource();
		ModelAndView model = new ModelAndView(Constants.ADD_EDIT_CUSTOMER_PAGE);
		model.addObject(Constants.DATASOURCE_DATA, ds);
		model.addObject(Constants.DATASOURCES, dataSourceList);
		model.addObject(Constants.DSNAME, dataSourceName);
		model.addObject("dsId", dataSourceId);
		return model;
	}

	/**
	 * .......................method to edit customer.....................
	 * 
	 * @param customerId
	 * @param dataSourceId
	 * @return
	 */

	@RequestMapping(value = "/Editcus", method = RequestMethod.GET)
	public ModelAndView getaddEditCus(
			@RequestParam(value = "custId") final long customerId,
			@RequestParam(value = "sourceId") final long dataSourceId) {

		ModelAndView model = new ModelAndView(Constants.ADD_EDIT_CUSTOMER_PAGE);
		DataSource ds = dataService.getDataSourceById(dataSourceId);
		model.addObject(Constants.DATASOURCE_DATA, ds);
		Customers cs = dataService.getCustomerById(customerId);

		model.addObject("customerData", cs);
		return model;

	}

	/**
	 * .............................. method to save added and Edited
	 * customer......................
	 * 
	 * @param request
	 * @param file
	 * @return
	 */
	@RequestMapping(value = "/addEditCustomer", method = RequestMethod.POST)
	public ModelAndView addCustomer(HttpServletRequest request,
			@RequestParam("file") MultipartFile[] file) {

		Map<String, String> headerMap = new HashMap<String, String>();

		ModelAndView model = null;
		String[] keys = request.getParameterValues("headerkey");
		String[] values = request.getParameterValues("headervalue");

		if (null != keys && keys.length == values.length) {
			for (int index = 0; index < keys.length; index++) {
				headerMap.put(keys[index], values[index]);
			}
		}
		Customers addNewcustomer = getCustomer(request, file, headerMap);
		dataService.saveCustomer(addNewcustomer);
		String schema = addNewcustomer.getResponseSchema();
		String type = addNewcustomer.getFormat();
		Set<String> resSchema = null;

		if (null != schema && !schema.isEmpty()) {
			if (type.equals(Constants.JSON)) {

				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);
			} else if (type.equals(Constants.XML)) {
				XmlFieldHandler field = new XmlFieldHandler();
				resSchema = field.getXml(schema);
			} else if (type.equals(Constants.FFF)) {
				JsonFieldHandler field = new JsonFieldHandler();
				resSchema = field.getAllFieldNames(schema);
			}
		}
		model = new ModelAndView("addDetailCustomer");
		if (request.getParameter(Constants.CUSTOMERID) != null) {
			model.addObject(Constants.MESSAGE, Constants.EDITED);

			Map<String, String> addDetailMap = new Gson().fromJson(
					addNewcustomer.getAdditionalDetails(),
					new TypeToken<Map<String, String>>() {
					}.getType());
			model.addObject(Constants.MESSAGE, Constants.EDITED);
			model.addObject("addedCustomer", addNewcustomer);
			model.addObject(Constants.FORMFIELDS, resSchema);
			model.addObject("additionalDataMap", addDetailMap);
		} else {
			model.addObject(Constants.MESSAGE, "Added");
			model.addObject("addedCustomer", addNewcustomer);
			model.addObject(Constants.FORMFIELDS, resSchema);
		}
		return model;
	}

	/**
	 * Method to set customer
	 * 
	 * @param request
	 * @param file
	 * @param headerMap
	 * @return
	 */

	private Customers getCustomer(HttpServletRequest request,
			MultipartFile[] file, Map<String, String> headerMap) {

		String requestSchema = null;
		String responseSchema = null;
		String personalinfoSchema = null;
		String replacedRequestSchema = null;
		Customers customer = null;
		FileHandler filehandler = new FileHandler();

		requestSchema = filehandler.fileToString(file[Constants.ZERO]);
		responseSchema = filehandler.fileToString(file[Constants.ONE]);
		personalinfoSchema = filehandler.fileToString(file[Constants.TWO]);

		String format = request.getParameter(Constants.FORMAT).toUpperCase();
		Customers addEditCustomer = new Customers();

		if (null != request.getParameter(Constants.CUSTOMERID)) {

			dataService.deleteCusHeaders(Long.valueOf(request
					.getParameter(Constants.CUSTOMERID)));
			addEditCustomer.setCustomerid(Long.valueOf(request
					.getParameter(Constants.CUSTOMERID)));
			addEditCustomer.setSourceId(Long.valueOf(request
					.getParameter(Constants.SOURCE_ID)));
			customer = dataService.getCustomerById(Long.valueOf(request
					.getParameter(Constants.CUSTOMERID)));
			addEditCustomer.setAdditionalDetails(customer
					.getAdditionalDetails());
			addEditCustomer.setRequestSchema(customer.getRequestSchema());
			addEditCustomer.setResponseSchema(customer.getResponseSchema());
			addEditCustomer.setPersonalInfoSchema(customer
					.getPersonalInfoSchema());
		} else {
			addEditCustomer.setSourceId(Long.valueOf(request
					.getParameter(Constants.SOURCE_ID)));
		}
		addEditCustomer.setName(request.getParameter("customername"));
		addEditCustomer.setDescription(request
				.getParameter(Constants.DESCRIPTION));
		addEditCustomer.setUrl(request.getParameter("url"));
		addEditCustomer.setFormat(request.getParameter(Constants.FORMAT)
				.toUpperCase());
		addEditCustomer.setUsername(request.getParameter("username"));
		addEditCustomer.setPassword(request.getParameter("password"));
		addEditCustomer.setMaxRequestPerDay(Long.valueOf(request
				.getParameter("maxrequest")));
		addEditCustomer
				.setTimeout(Long.valueOf(request.getParameter("timeout")));
		addEditCustomer.setSslDetails(setSSLDetails(request));

		if (null != requestSchema && !requestSchema.isEmpty()) {
			replacedRequestSchema = replaceRequestSchema(requestSchema, format,
					headerMap);
			addEditCustomer.setRequestSchema(replacedRequestSchema);
		}

		if (null != responseSchema && !responseSchema.isEmpty()) {
			addEditCustomer.setResponseSchema(responseSchema);
		}

		if (null != personalinfoSchema && !personalinfoSchema.isEmpty()) {
			addEditCustomer.setPersonalInfoSchema(personalinfoSchema);
		}

		addEditCustomer.setCustomerDetails(setCustomerHeaderDetails(headerMap,
				addEditCustomer));
		return addEditCustomer;
	}

	/**
	 * @param headerMap
	 * @param addEditCustomer
	 * @return
	 */
	private Set<CustomerDetails> setCustomerHeaderDetails(
			Map<String, String> headerMap, Customers addEditCustomer) {
		Set<CustomerDetails> customerDetailsSet = new HashSet<CustomerDetails>();

		for (Map.Entry entry : headerMap.entrySet()) {
			CustomerDetails customerdetails = new CustomerDetails();
			customerdetails.setCustomers(addEditCustomer);
			customerdetails.setHeaderName(entry.getKey().toString());
			customerdetails.setHeaderValue(entry.getValue().toString());
			customerDetailsSet.add(customerdetails);
		}
		return customerDetailsSet;
	}

	/**
	 * @param request
	 * @return
	 */
	private String setSSLDetails(HttpServletRequest request) {
		String isPresent = request.getParameter("ssl");
		String jsonStr = null;
		if ((isPresent != null)
				&& (isPresent.equalsIgnoreCase(Constants.SSLVALUE))) {
			Map<String, String> test = new HashMap<String, String>();
			test.put(Constants.SKIP_HOSTNAME_VALIDATION, "true");
			Gson gsonObject = new Gson();
			jsonStr = gsonObject.toJson(test);

		} else {
			Map<String, String> test = new HashMap<String, String>();
			test.put(Constants.SKIP_HOSTNAME_VALIDATION, "false");
			Gson gsonObject = new Gson();
			jsonStr = gsonObject.toJson(test);

		}
		return jsonStr;
	}

	/**
	 * navigate to scenario page
	 * 
	 * @return
	 */

	@RequestMapping(value = "/navScenario", method = RequestMethod.GET)
	public ModelAndView navScenario() {

		return new ModelAndView("Scenario");
	}

	/**
	 * naviagte to customer page displaying all available customers
	 * 
	 * @return
	 */
	@RequestMapping(value = "/navCustomer", method = RequestMethod.GET)
	public ModelAndView navCustomer() {

		ModelAndView modelandView = new ModelAndView("Customer");
		List<Customers> customerList = dataService.getAllCustomer();
		modelandView.addObject(Constants.CUSTOMERS, customerList);
		return modelandView;
	}

	/**
	 * method to implement search and return corresponding scenarios
	 * 
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "/searchInscenarioList", method = RequestMethod.POST)
	public ModelAndView searchScenario(HttpServletRequest request) {

		ModelAndView modelandView = new ModelAndView("ScenarioList");
		String scenario = request.getParameter("searchName");
		String dataSourceId = request.getParameter("searchDatasource");
		String customerId = request.getParameter("searchCustomer");
		String sourceType = null;
		Long totalResultCount = null;
		if (null != dataSourceId && !dataSourceId.isEmpty()) {
			DataSource ds = dataService.getDataSourceById(Long
					.valueOf(dataSourceId));
			modelandView.addObject("datasource", ds);
			if (customerId.equals(Constants.SELECT) || null == customerId
					|| customerId.isEmpty()) {
				sourceType = Constants.DATASOURCE_TYPE;
				List<Scenario> scenarioList = dataService
						.getAllFilteredScenario(scenario,
								Long.valueOf(dataSourceId),
								Constants.DATASOURCE_TYPE);
				totalResultCount = dataService.getFilteredCountForScenario(
						scenario, Long.valueOf(dataSourceId),
						Constants.DATASOURCE_TYPE);
				List<DataSource> dataSourceList = dataService
						.getAllDataSource();
				modelandView.addObject(Constants.DATASOURCES, dataSourceList);
				modelandView.addObject("scenarioList", scenarioList);
				modelandView.addObject(Constants.TOTAL_RESULT_COUNT,
						totalResultCount);
				modelandView.addObject(Constants.SOURCE_TYPE, sourceType);
				modelandView.addObject("dataSourceId", dataSourceId);
				modelandView.addObject("customerId", customerId);
				modelandView.addObject("scenario", scenario);
			} else {
				sourceType = Constants.CUSTOMER_TYPE;
				List<Scenario> scenarioList = dataService
						.getAllFilteredScenario(scenario,
								Long.valueOf(customerId),
								Constants.CUSTOMER_TYPE);
				totalResultCount = dataService.getFilteredCountForScenario(
						scenario, Long.valueOf(customerId),
						Constants.CUSTOMER_TYPE);
				List<DataSource> dataSourceList = dataService
						.getAllDataSource();
				List<Customers> cs = dataService.getAllCustomerBySource(Long
						.valueOf(dataSourceId));
				Customers selectedCustomer = dataService.getCustomerById(Long
						.valueOf(customerId));
				modelandView.addObject("customers", cs);
				modelandView.addObject("selectedCustomer", selectedCustomer);
				modelandView.addObject(Constants.DATASOURCES, dataSourceList);
				modelandView.addObject("scenarioList", scenarioList);
				modelandView.addObject(Constants.TOTAL_RESULT_COUNT,
						totalResultCount);
				modelandView.addObject(Constants.SOURCE_TYPE, sourceType);
				modelandView.addObject("dataSourceId", dataSourceId);
				modelandView.addObject("customerId", customerId);
				modelandView.addObject("scenario", scenario);
			}
			List<Customers> cs = dataService.getAllCustomerBySource(Long
					.valueOf(dataSourceId));
			modelandView.addObject(Constants.CUSTOMERS, cs);
		}

		modelandView.addObject("scenarioName", scenario);

		return modelandView;
	}

	/**
	 * method for getting filtered scenario in pagination
	 * 
	 * @param count
	 * @param sourceId
	 * @param scenario
	 * @param sourceType
	 * @return
	 */

	@RequestMapping(value = "/getResult", method = RequestMethod.GET)
	@ResponseBody
	public List<Scenario> getResult(
			@RequestParam(value = "count") final Long count,
			@RequestParam(value = "sourceId") final Long sourceId,
			@RequestParam(value = "scenario") final String scenario,
			@RequestParam(value = "sourceType") final String sourceType) {

		List<Scenario> scenarioList = null;

		if (count == 1 && null != sourceId) {

			if (sourceType.equals(Constants.DATASOURCE_TYPE)) {
				scenarioList = dataService.getAllFilteredScenario(scenario,
						Long.valueOf(sourceId), Constants.DATASOURCE_TYPE);
			} else if (sourceType.equals(Constants.CUSTOMER_TYPE)) {
				scenarioList = dataService.getAllFilteredScenario(scenario,
						Long.valueOf(sourceId), Constants.CUSTOMER_TYPE);

			}

		}
		if (count > 1 && null != sourceId) {

			if (sourceType.equals(Constants.DATASOURCE_TYPE)) {
				scenarioList = dataService.getFilteredScenario(scenario,
						Long.valueOf(sourceId), Constants.DATASOURCE_TYPE,
						Long.valueOf(count));

			} else if (sourceType.equals(Constants.CUSTOMER_TYPE)) {
				scenarioList = dataService.getFilteredScenario(scenario,
						Long.valueOf(sourceId), Constants.CUSTOMER_TYPE,
						Long.valueOf(count));

			}

		}

		return scenarioList;
	}

	/**
	 * method to edit scenario
	 * 
	 * @param scenarioId
	 * @param sourceType
	 * @return
	 */

	@RequestMapping(value = "/editScenario", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ModelAndView editScenario(
			@RequestParam(value = "scenarioId") final Long scenarioId,
			@RequestParam(value = "sourceType") final String sourceType) {

		Scenario scenario = dataService.getScenarioById(scenarioId,
				sourceType.trim());
		String schema = scenario.getResponseSchema();
		String type = scenario.getFormat();
		String datasource = scenario.getDataSourceName();
		String customer = scenario.getCustomerName();
		ModelAndView modelandView = new ModelAndView(Constants.ADDSCENARIO_PAGE);
		Set<String> resSchema = null;
		try {
			if (null != schema && !schema.isEmpty()) {
				if ("JSON".equals(type)) {
					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);
				} else if ("XML".equals(type)) {

					XmlFieldHandler field = new XmlFieldHandler();
					resSchema = field.getXml(schema);
				} else if ("FFF".equals(type)) {

					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}

		modelandView.addObject("scenarioData", scenario);
		modelandView.addObject(Constants.FORMFIELDS, resSchema);
		modelandView.addObject(Constants.DSNAME, datasource);
		modelandView.addObject("csName", customer);

		modelandView.addObject(Constants.SCENARIO_ID, scenarioId);
		return modelandView;
	}

	/**
	 * Method called to update scenario in db
	 * 
	 * @param rule
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/saveScenario", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveEditedScenario(HttpServletRequest request) {

		String sourceType = request.getParameter(Constants.SOURCE_TYPE);
		Long scenarioId = Long.valueOf(request.getParameter("scenarioid"));
		String scenarioRule = request.getParameter("rule");
		ModelAndView model = new ModelAndView("Request");
		if (null != scenarioRule && !scenarioRule.isEmpty()
				&& null != sourceType && null != scenarioId) {
			Scenario scenario = dataService.getScenarioById(scenarioId,
					sourceType);
			scenario.setScenarioName(request.getParameter("name"));
			scenario.setDescription(request.getParameter(Constants.DESCRIPTION));
			scenario.setStatus(1L);
			Set<RequestData> requestDatas = null;
			scenario.setScenarioData(scenarioRule);
			requestDatas = dataService.processScenario(scenario);
			final Scenario scenarioObject = scenario;
			final Set<RequestData> requestDataSet = requestDatas;
			new Thread(() -> {
				saveScenarioAsync(scenarioObject, requestDataSet);
			}).start();
			model.addObject(Constants.REQUEST_DATA_LIST, requestDatas);
			request.getSession().setAttribute(Constants.REQUEST_DATA_LIST,
					requestDatas);

			if (null != requestDatas && !requestDatas.isEmpty()) {
				model.addObject(Constants.SCENARIO_ID, scenarioId);
				model.addObject(Constants.REQUEST_DATA_LIST, requestDatas);
				request.getSession().setAttribute(Constants.REQUEST_DATA_LIST,
						requestDatas);
			} else {
				model = new ModelAndView(Constants.SEARCH_SCENARIO_MESSAGE_PAGE);
				model.addObject(Constants.MESSAGE, Constants.EDITED);
			}

		}
		return model;
	}

	/**
	 * get scenario form fields
	 * 
	 * @param sourceId
	 * @param sourceType
	 * @return
	 */

	@RequestMapping(value = "/getScenarioFormFields", method = RequestMethod.GET)
	@ResponseBody
	public Set<String> getScenarioFormFields(
			@RequestParam(value = "sourceId") final Long sourceId,
			@RequestParam(value = "sourceType") final String sourceType) {

		String schema = null;
		String type = null;
		Set<String> resSchema = null;
		try {
			if (Constants.DATASOURCE_TYPE.equals(sourceType.trim())) {
				DataSource dataSource = dataService.getDataSourceById(sourceId);
				schema = dataSource.getResponseSchema();
				type = dataSource.getFormat();
			} else if (Constants.CUSTOMER_TYPE.equals(sourceType.trim())) {
				Customers customer = dataService.getCustomerById(sourceId);
				schema = customer.getResponseSchema();
				type = customer.getFormat();
			}
			if (null != schema && !schema.isEmpty()) {
				if ("JSON".equals(type)) {
					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);
				} else if ("XML".equals(type)) {
					XmlFieldHandler field = new XmlFieldHandler();
					resSchema = field.getXml(schema);

				} else if ("FFF".equals(type)) {
					JsonFieldHandler field = new JsonFieldHandler();
					resSchema = field.getAllFieldNames(schema);

				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return resSchema;
	}

	public void saveScenarioAsync(Scenario scenario, Set requestData) {
		LOGGER.info("Execute method asynchronously. "
				+ Thread.currentThread().getName());
		dataService.saveScenarioMapping(scenario, requestData);
	}

	/**
	 * saving data source additional details
	 * 
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "/saveDatasourceAddDetails", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveDatasourceAddDetails(HttpServletRequest request) {
		String format = request.getParameter(Constants.FORMAT).toUpperCase();
		String dataSourceId = request.getParameter(Constants.SOURCE_ID);
		String requestSchema = request.getParameter("reqSchema");
		String additionalDetails = null;
		DataSource dataSource = dataService.getDataSourceById(Long
				.valueOf(dataSourceId));

		String[] fields = request.getParameterValues("additionalField");
		String[] fieldPath = request.getParameterValues("additionalFieldPath");
		AdditionalDetailsHandler addHandler = new AdditionalDetailsHandler();

		if (null != fields && fields.length == fieldPath.length) {

			if (format.equals(Constants.JSON)) {
				additionalDetails = addHandler.getAdditionalDetailForJson(
						fields, fieldPath);

			} else if (format.equals(Constants.XML)) {
				additionalDetails = addHandler.getAdditionalDetailForXml(
						fields, fieldPath);

			} else if (format.equals(Constants.FFF)) {
				additionalDetails = addHandler.getAdditionalDetailForFff(
						fields, fieldPath, dataSource.getResponseSchema());

			}
		}

		if (null != additionalDetails && !additionalDetails.isEmpty()) {
			dataSource.setAdditionalDetails(additionalDetails);
		}
		if (null != requestSchema && !requestSchema.isEmpty()) {
			dataSource.setRequestSchema(requestSchema);
		}
		dataService.saveDataSource(dataSource);

		ModelAndView modelandView = new ModelAndView("Success");
		modelandView.addObject("entity", "Data Source");

		return modelandView;

	}

	/**
	 * saving customer additional details
	 * 
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "/saveCustomerAddDetails", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveCustomerAddDetails(HttpServletRequest request) {
		String format = request.getParameter(Constants.FORMAT).toUpperCase();
		String customerId = request.getParameter(Constants.CUSTOMERID);
		String requestSchema = request.getParameter("reqSchema");
		String additionalDetails = null;
		Customers customer = dataService.getCustomerById(Long
				.valueOf(customerId));

		String[] fields = request.getParameterValues("additionalField");
		String[] fieldPath = request.getParameterValues("additionalFieldPath");

		AdditionalDetailsHandler addHandler = new AdditionalDetailsHandler();

		if (null != fields && fields.length == fieldPath.length) {

			if (format.equals(Constants.JSON)) {
				additionalDetails = addHandler.getAdditionalDetailForJson(
						fields, fieldPath);

			} else if (format.equals(Constants.XML)) {
				additionalDetails = addHandler.getAdditionalDetailForXml(
						fields, fieldPath);

			} else if (format.equals(Constants.FFF)) {
				additionalDetails = addHandler.getAdditionalDetailForFff(
						fields, fieldPath, customer.getResponseSchema());

			}
		}

		if (null != additionalDetails && !additionalDetails.isEmpty()) {
			customer.setAdditionalDetails(additionalDetails);
		}
		if (null != requestSchema && !requestSchema.isEmpty()) {
			customer.setRequestSchema(requestSchema);
		}

		dataService.saveCustomer(customer);

		ModelAndView modelandView = new ModelAndView("Success");
		modelandView.addObject("entity", "Customer");

		return modelandView;

	}

	/**
	 * replacing request schema
	 * 
	 * @param requestSchema
	 * @param format
	 * @param headerMap
	 * @return
	 */

	private String replaceRequestSchema(String requestSchema, String format,
			Map<String, String> headerMap) {
		String replacedRequestSchema = null;

		if (format.equals(Constants.JSON)) {

			replacedRequestSchema = replaceSchema
					.replaceRequestSchemaForJson(requestSchema);

		} else if (format.equals(Constants.XML)) {

			replacedRequestSchema = replaceSchema.replaceRequestSchemaForXml(
					requestSchema, headerMap);
		} else if (format.equals(Constants.FFF)) {

			replacedRequestSchema = requestSchema;
		}

		return replacedRequestSchema;

	}

	/**
	 * navigate to test data page
	 * 
	 * @return
	 */

	@RequestMapping(value = "/testDataPage", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView getUploadTestDataPage() {

		ModelAndView modelandView = new ModelAndView("UploadTestData");
		List<DataSource> dataSources = dataService.getAllDataSource();
		modelandView.addObject(Constants.DATASOURCES, dataSources);
		return modelandView;
	}

	/**
	 * method to upload test data
	 * 
	 * @param request
	 * @param testDatafile
	 * @return
	 */

	@RequestMapping(value = "/uploadTestData", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView uploadTestData(HttpServletRequest request,
			MultipartFile testDatafile) {

		if (testDatafile.getSize() > 1000000) {
			ModelAndView model = new ModelAndView("UploadTestData");
			model.addObject(Constants.MESSAGE, "File Limit Exceeds");
			return model;
		}

		Long dataSourceId = Long.valueOf(request.getParameter("datasource"));
		DataSource datasource = dataService.getDataSourceById(dataSourceId);
		String datasourceType = datasource.getDatasourceType();

		try {
			ExcelReader excelReader = new ExcelReader();
			List<Object> entities = excelReader.convertExcelTOListOfObjects(testDatafile,
					dataSourceId, datasourceType);

			dataService.bulkInsertOfBasicInfo(entities);
			ModelAndView modelandView = new ModelAndView("SuccessRegister");
			modelandView.addObject(Constants.MESSAGE, "Uploaded");
			return modelandView;
		} catch (FileUploadException e) {
			ModelAndView model = new ModelAndView("UploadTestData");
			model.addObject(
					Constants.MESSAGE,
					"Incorrect format. <a href=\"resources/TestDataTemplate.xlsx\"/>TestDataTemplate</a>");
			return model;
		}
		
	}

	/**
	 * Method to trigger scheduler
	 */

	@RequestMapping(value = "/schedule", method = RequestMethod.POST)
	@ResponseBody
	public void scheduleDataSync() {
		Thread thread = new Thread(new DataManagementTasklet(dataService));
		thread.start();
	}
		

}
