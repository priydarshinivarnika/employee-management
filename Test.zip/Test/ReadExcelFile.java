package com.business.world.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFile {

	private static final String FILE_PATH = "/Users/vxp142/USIS/Exercise/Test.xlsx";

	public static void main(String args[]) {

		List empList = getEmployeeListFromExcel();

		System.out.println("\n" + empList);
	}

	private static List getEmployeeListFromExcel() {

		List empList = new ArrayList();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(FILE_PATH);

			// Using XSSF for xlsx format
			Workbook workbook = new XSSFWorkbook(fis);

			int numberOfSheets = workbook.getNumberOfSheets();

			// looping over each workbook sheet
			for (int i = 0; i < numberOfSheets; i++) {
				Sheet sheet = workbook.getSheetAt(i);
				Iterator rowIterator = sheet.iterator();

				// iterating over each row
				while (rowIterator.hasNext()) {

					Employee emp = new Employee();
					Row row = (Row) rowIterator.next();
					Iterator cellIterator = row.cellIterator();

					// Iterating over each cell (column wise) in a particular
					// row.
					while (cellIterator.hasNext()) {

						Cell cell = (Cell) cellIterator.next();

						if (Cell.CELL_TYPE_STRING == cell.getCellType()) {
							if (cell.getColumnIndex() == 0) {
								emp.setEmpId(cell.getStringCellValue());
							} else if (cell.getColumnIndex() == 1) {
								emp.setFirstname(cell.getStringCellValue());
							}
							// Cell with index 2 contains marks in Science
							else if (cell.getColumnIndex() == 2) {
								emp.setLastname(cell.getStringCellValue());
							}

						}

						else if (Cell.CELL_TYPE_NUMERIC == cell.getCellType()) {

							if (cell.getColumnIndex() == 3) {
								emp.setSalary(String.valueOf(cell
										.getNumericCellValue()));

							}

						}
					}

					// end iterating a row, add all the elements of a row in
					// list
					empList.add(emp);
				}
			}

			fis.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return empList;

	}
}
