package com.business.world.util;

import java.io.File;
import java.io.FileOutputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

public class DatabaseToExcel {

	@Test
	public void getEmployeesListFromDB() throws Exception {
		Class.forName("org.postgresql.Driver");
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres",
				"admin");

		Statement statement = connect.createStatement();
		ResultSet resultSetEmployee = statement.executeQuery("select * from employee");
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet spreadsheet = workbook.createSheet("employe db");

		XSSFRow row = spreadsheet.createRow(1);
		XSSFCell cell;
		cell = row.createCell(1);
		cell.setCellValue("EMPLOYEE_ID");
		cell = row.createCell(2);
		cell.setCellValue("FIRST_NAME");
		cell = row.createCell(3);
		cell.setCellValue("ID");
		cell = row.createCell(4);
		cell.setCellValue("LAST_NAME");
		cell = row.createCell(5);
		cell.setCellValue("SALARY");
		int i = 2;

		while (resultSetEmployee.next()) {
			row = spreadsheet.createRow(i);
			cell = row.createCell(1);
			cell.setCellValue(resultSetEmployee.getInt("employee_id"));
			cell = row.createCell(2);
			cell.setCellValue(resultSetEmployee.getString("first_name"));
			cell = row.createCell(3);
			cell.setCellValue(resultSetEmployee.getString("id"));
			cell = row.createCell(4);
			cell.setCellValue(resultSetEmployee.getString("last_name"));
			cell = row.createCell(5);
			cell.setCellValue(resultSetEmployee.getString("salary"));
			i++;
		}

		FileOutputStream out = new FileOutputStream(new File("exceldatabase.xlsx"));
		workbook.write(out);
		out.close();
		System.out.println("exceldatabase.xlsx written successfully");
	}
}
