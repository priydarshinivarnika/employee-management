package com.ServletProject.operation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String directoryName = "C:/Users/vxp142/DataInFileFormat";
	private String fileName = "servletData";

	public void init() throws ServletException {

	}

	public RegistrationServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String first_name = request.getParameter("first_name");
		String last_name = request.getParameter("last_name");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String address = request.getParameter("address");
		String contact = request.getParameter("contact");

		String userData = first_name + "," + last_name + "," + username + ","
				+ password + "," + address + "," + contact;

		File directory = new File(directoryName);

		if (!directory.exists()) {
			directory.mkdir();
		}

		File file = new File(directoryName + "/" + fileName);
		try {

			FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fileWriter);
			bw.write(userData);
			bw.newLine();
			bw.close();

			RequestDispatcher req = request.getRequestDispatcher("index.jsp");
			req.include(request, response);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
