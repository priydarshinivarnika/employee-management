package com.sample.model;

public class Practice {

	
	public static void main(String [] args){
		Name n = new Name();
		n.add("varnika","sri");
	}
}

class Name{
	
	
	public void add(String s, String p){
		System.out.println("String Class");
	}
	

	public void add(Integer s, Integer p){
		System.out.println("Integer Class");
	}
	

	public void add(Object s, Object p){
		System.out.println("Object Class");
	}
}