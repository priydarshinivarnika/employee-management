package com.sample.services;

import com.sample.model.User;

public interface IUserServices {

	void saveUser(User user);

	void updateUser(User user);

	void deleteUser(User user);

}
