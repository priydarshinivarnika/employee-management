package com.sample.dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.sample.dao.IUserDao;
import com.sample.model.User;

public class UserDao implements IUserDao{
	private String directoryName = "C:/Users/vxp142/DataInFileFormat";
	private String fileName = "userSpringData";

	@Override
	public void saveUser(User user) {
		String userData = user.getFirstname() + "," +user.getLastname() + "," +user.getUsername1() + "," + user.getPassword() + "," + user.getAddress()+ "," + user.getPhone();

		File directory = new File(directoryName);

		if (! directory.exists()){
			directory.mkdir();
		}

		File file = new File(directoryName + "/" + fileName);
		try{

			FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fileWriter);
			bw.write(userData);
			bw.newLine();
			bw.close();
		}
		catch (IOException e){
			e.printStackTrace();
		}
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub

	}



}
