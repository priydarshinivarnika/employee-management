package com.ust.model;

import java.util.Set;

public interface EmployeeServices {

	/* Method to CREATE an employee in the database */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#addEmployee(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	public abstract Integer addEmployee(String email, String firstName,
			String lastName, String department);

	/* Method to READ all the employees */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#listEmployees()
	 */
	public abstract void listEmployees();

	// Method to READ the employee by id
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#fetchEmployeeById(int)
	 */
	public abstract void fetchEmployeeById(int id);

	// Method to READ the employee by department
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ust.model.EmployeeServices#fetchEmployeeByDepartment(java.lang.String)
	 */
	public abstract void fetchEmployeeByDepartment(String department);

	/* Method to UPDATE department for an employee */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#updateEmployee(int, java.lang.String)
	 */
	public abstract void updateEmployee(int id, String department);

	/* Method to DELETE an employee from the records */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#deleteEmployee(java.lang.Integer)
	 */
	public abstract void deleteEmployee(Integer EmployeeID);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ust.model.EmployeeServices#deleteEmployee(java.lang.Integer)
	 */

	/* Method to print total number of records */
	public abstract void countEmployee();

}